package com.isoftbiz.admin.iservice;

import java.util.List;

import com.isoftbiz.admin.model.Role;

public interface IRoleService {
	public Role findById(Long id) throws Exception;

	public List<Role> findAll() throws Exception;
	
	public List<Role> listRole() throws Exception;
}
