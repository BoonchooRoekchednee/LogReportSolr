package com.isoftbiz.admin.iservice;

import java.util.List;

import com.isoftbiz.admin.model.User;

public interface IUserService {
	public User findById(Long userID) throws Exception;

	public User findByUserCode(String userCode) throws Exception;
	
	public List<User> findAll() throws Exception;

	public List<User> findAll(int offset, int pageSize, Integer orderColumn, String orderDirection) throws Exception;
	
	public boolean save(User user) throws Exception;

	public boolean update(User user) throws Exception;

	public boolean delete(User user) throws Exception;
	
	public List<User> listUser() throws Exception;
	
	public List<User> searchUser(String sUserCode, String sFirstName, String sLastName, String sRoleID, String sCompanyID, String sActiveFlag) throws Exception;
	
	public int updatePassword(Long userID, String newPassword) throws Exception;
}
