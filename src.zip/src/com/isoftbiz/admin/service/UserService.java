package com.isoftbiz.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.admin.idao.IUserDAO;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;

@Service
@Transactional
public class UserService implements IUserService {
	@Autowired
	private IUserDAO userDAO;

	@Override
	public User findById(Long userID) throws Exception {
		return userDAO.findById(userID);
	}

	@Override
	public User findByUserCode(String userCode) throws Exception {
		return userDAO.findByUserCode(userCode);
	}
	
	@Override
	public List<User> findAll() throws Exception {
		return userDAO.findAll();
	}

	@Override
	public List<User> findAll(int offset, int pageSize, Integer orderColumn, String orderDirection) throws Exception {
		List<User> user = userDAO.findAll(offset, pageSize, orderColumn, orderDirection);
		return user;
	}
	
	@Override
	public boolean save(User user) throws Exception {
		return userDAO.save(user);
	}

	@Override
	public boolean update(User user) throws Exception {
		return userDAO.update(user);
	}

	@Override
	public boolean delete(User user) throws Exception {
		return userDAO.delete(user);
	}
	
	@Override
	public List<User> listUser() throws Exception {
		return userDAO.listUser();
	}
	
	@Override
	public List<User> searchUser(String sUserCode, String sFirstName, String sLastName, String sRoleID, String sCompanyID, String sActiveFlag) throws Exception {
		return userDAO.searchUser(sUserCode, sFirstName, sLastName, sRoleID, sCompanyID, sActiveFlag);
	}
	
	@Override
	public int updatePassword(Long userID, String newPassword) throws Exception {
		return userDAO.updatePassword(userID, newPassword);
	}
}
