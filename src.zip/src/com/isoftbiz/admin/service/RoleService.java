package com.isoftbiz.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.admin.idao.IRoleDAO;
import com.isoftbiz.admin.iservice.IRoleService;
import com.isoftbiz.admin.model.Role;

@Service
@Transactional
public class RoleService implements IRoleService {
	@Autowired
	private IRoleDAO roleDAO;

	@Override
	public Role findById(Long roleID) throws Exception {
		return roleDAO.findById(roleID);
	}
	
	@Override
	public List<Role> findAll() throws Exception {
		return roleDAO.findAll();
	}
	
	@Override
	public List<Role> listRole() throws Exception {
		return roleDAO.listRole();
	}
}
