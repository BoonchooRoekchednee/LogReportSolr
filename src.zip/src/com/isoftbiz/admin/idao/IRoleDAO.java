package com.isoftbiz.admin.idao;

import java.util.List;

import com.isoftbiz.admin.model.Role;

public interface IRoleDAO {
	public Role findById(Long id) throws Exception;

	public List<Role> findAll() throws Exception;
	
	public List<Role> listRole() throws Exception;
}