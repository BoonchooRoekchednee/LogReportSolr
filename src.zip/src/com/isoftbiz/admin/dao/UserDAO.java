package com.isoftbiz.admin.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.admin.idao.IUserDAO;
import com.isoftbiz.admin.model.User;

@Repository
public class UserDAO extends HibernateDaoSupport implements IUserDAO{
	protected Session session;
	
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public User findById(Long userID) throws Exception {
		User user = this.getHibernateTemplate().get(User.class, userID);
		return user;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public User findByUserCode(String userCode) throws Exception {
		List user = this.getHibernateTemplate().find("from User where UserCode=?", userCode);
		return (User)user.get(0);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> findAll() throws Exception {
		List<User> userList = session.createCriteria(User.class).list();
		session.flush();
		session.clear();
		return userList;
	}

	@SuppressWarnings("unchecked")
	@Override
	 public List<User> findAll(int offset, int pageSize, Integer orderColumn, String orderDirection) {
        Query query = session.createQuery("FROM User");
        query.setFirstResult(offset);
        query.setMaxResults(pageSize);
        List<User> userList = query.list();
        return userList;
    }
	
	@Override
	public boolean save(User user) throws Exception {
		this.getHibernateTemplate().save(user);
		return true;
	}

	@Override
	public boolean update(User user) throws Exception {
		this.getHibernateTemplate().update(user);
		return true;
	}

	@Override
	public boolean delete(User user) throws Exception {
		this.getHibernateTemplate().delete(user);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> listUser() throws Exception {
		List<User> userList = this.getHibernateTemplate().find("select u from User u where u.role.roleMapping <> 'ROLE_ISOFTBIZ' order by u.userCode");
		return userList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> searchUser(String sUserCode, String sFirstName, String sLastName, String sRoleID, String sCompanyID, String sActiveFlag) throws Exception {
		StringBuilder sQuery = new StringBuilder();
		sQuery.append("from User where UserID is not null and RoleID <> 1 ");
		if (sUserCode != null && !sUserCode.isEmpty()) {
			sQuery.append(" and UserCode like '%" + sUserCode + "%' ");
		}
		if (sFirstName != null && !sFirstName.isEmpty()) {
			sQuery.append(" and FirstName like '%" + sFirstName + "%' ");
		}
		if (sLastName != null && !sLastName.isEmpty()) {
			sQuery.append(" and LastName like '%" + sLastName + "%' ");
		}
		if (sRoleID != null && !sRoleID.isEmpty()) {
			sQuery.append(" and RoleID = " + sRoleID);
		}
		if (sCompanyID != null && !sCompanyID.isEmpty()) {
			sQuery.append(" and CompanyID = " + sCompanyID);
		}
		if (sActiveFlag != null && !sActiveFlag.isEmpty() && !sActiveFlag.equalsIgnoreCase("A")) {
			sQuery.append(" and ActiveFlag = '" + sActiveFlag + "' ");
		}
		List<User> userList = this.getHibernateTemplate().find(sQuery.toString());
		return userList;
	}
	
	@Override
	public int updatePassword(Long userID, String newPassword) throws Exception {
		Query query = session.createQuery("update User set UserPassword = '" + newPassword + "' where UserID = " + userID.toString());
		int result = query.executeUpdate();
		return result;
	}
}
