package com.isoftbiz.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.admin.idao.IRoleDAO;
import com.isoftbiz.admin.model.Role;

@Repository
public class RoleDAO extends HibernateDaoSupport implements IRoleDAO {
	
	protected Session session;
	
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Role findById(Long roleID) throws Exception {
		Role role = this.getHibernateTemplate().get(Role.class, roleID);
		return role;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Role> findAll() throws Exception {
		List<Role> roleList = session.createCriteria(Role.class).list();
		session.flush();
		session.clear();
		return roleList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Role> listRole() throws Exception {
		List<Role> roleList = this.getHibernateTemplate().find("from Role where ROLE_MAPPING <> 'ROLE_ISOFTBIZ' order by RoleID asc");
		return roleList;
	}
}
