package com.isoftbiz.admin.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Roles")
public class Role {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RoleID")
	private Long roleID;
	
	@Column(name = "ROLE_MAPPING", length = 32, unique = true, nullable = false)
	private String roleMapping;
	
	@Column(name = "ROLE_NAME", length = 64, unique = true, nullable = false)
	private String roleName;

	@Column(name = "ROLE_TYPE", length = 32)
	private String roleType;

	public Long getRoleID() {
		return roleID;
	}

	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}

	public String getRoleMapping() {
		return roleMapping;
	}

	public void setRoleMapping(String roleMapping) {
		this.roleMapping = roleMapping;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
}
