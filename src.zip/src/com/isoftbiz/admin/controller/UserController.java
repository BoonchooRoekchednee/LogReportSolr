package com.isoftbiz.admin.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IRoleService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.Role;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.config.iservice.ICompanyFreeZoneService;
import com.isoftbiz.config.model.CompanyFreeZone;

@Controller
public class UserController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IRoleService roleService;
	
	@Autowired
	private ICompanyFreeZoneService companyService;
	
	@RequestMapping(value = "/UserAccount.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<User> userList = new HashSet<User>(userService.listUser());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("userList", userList);
			mav.setViewName("UserAccount");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UserNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Role> roleList = new HashSet<Role>(roleService.listRole());
			Set<CompanyFreeZone> companyList = new HashSet<CompanyFreeZone>(companyService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("roleList", roleList);
			mav.addObject("companyList", companyList);
			mav.setViewName("UserNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UserEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Role> roleList = new HashSet<Role>(roleService.listRole());
			Set<CompanyFreeZone> companyList = new HashSet<CompanyFreeZone>(companyService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User user = userService.findById(id);
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("roleList", roleList);
			mav.addObject("companyList", companyList);
			mav.addObject("user", user);
			mav.setViewName("UserEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UserAccountDetail.isoftbiz")
	public ModelAndView userDetail() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Role> roleList = new HashSet<Role>(roleService.findAll());
			Set<CompanyFreeZone> companyList = new HashSet<CompanyFreeZone>(companyService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("roleList", roleList);
			mav.addObject("companyList", companyList);
			mav.setViewName("UserAccountDetail");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UserSave.isoftbiz", method = RequestMethod.POST)
	public String save(User user) {
		try {
			userService.save(user);
			return "redirect:/UserAccount.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/UserUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(User user) {
		try {
			userService.update(user);
			return "redirect:/UserAccount.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/UserDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			User user = userService.findById(id);
			userService.delete(user);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/UserSearch.isoftbiz")
	public ModelAndView search() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<CompanyFreeZone> companyList = new HashSet<CompanyFreeZone>(companyService.findAll());
			Set<Role> roleList = new HashSet<Role>(roleService.listRole());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("roleList", roleList);
			mav.addObject("companyList", companyList);
			mav.setViewName("UserSearch");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/SearchUser.isoftbiz", method = RequestMethod.POST)
	public ModelAndView searchUser(HttpServletRequest request) {
		try {
			String sUserCode = request.getParameter("userCode");
			String sFirstName = request.getParameter("firstName");
			String sLastName = request.getParameter("lastName");
			String sRoleID = request.getParameter("roleID");
			String sCompanyID = request.getParameter("companyID");
			String sActiveFlag = request.getParameter("activeFlag");
			
			Set<User> userList = new HashSet<User>(userService.searchUser(sUserCode, sFirstName, sLastName, sRoleID, sCompanyID, sActiveFlag));
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("userList", userList);
			mav.setViewName("UserAccount");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		Locale lc = new java.util.Locale("en","EN");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", lc);
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
