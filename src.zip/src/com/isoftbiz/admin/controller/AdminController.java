package com.isoftbiz.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;

@Controller
public class AdminController {
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/403.isoftbiz")  
	 public ModelAndView accessDenied() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to view this page.");
			mav.setViewName("403");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	 }
	
	@RequestMapping(value = "/DuplicateData.isoftbiz")  
	 public ModelAndView duplicateData() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("DuplicateData");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	 }
}
