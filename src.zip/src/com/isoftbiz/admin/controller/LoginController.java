package com.isoftbiz.admin.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.model.User;
import com.isoftbiz.admin.iservice.IUserService;

@Controller
public class LoginController {
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/login.isoftbiz", method = RequestMethod.GET)
	public String login(ModelMap model) {
		return "login";
	}
	
	@RequestMapping(value = "/loginfailed.isoftbiz", method = RequestMethod.GET)
	public String loginerror(ModelMap model) {
		model.addAttribute("error", "true");
		return "login";
	}

	@RequestMapping(value = "/logout.isoftbiz", method = RequestMethod.GET)
	public String logout(ModelMap model) {
		return "login";
	}
	
	@RequestMapping(value = "/Welcome.isoftbiz")
	public ModelAndView welcome() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("Welcome");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ChangePassword.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("ChangePassword");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ChangePasswordUpdate.isoftbiz")
	public String changePasswordUpdate(HttpServletRequest request, ModelMap model) {
		try {
			String userID = request.getParameter("userID");
			String currentPassword = request.getParameter("current_password").trim();
			String newPassword = request.getParameter("new_password").trim();
			String confirmPassword = request.getParameter("confirm_password").trim();
			
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			model.addAttribute("userLogin", userLogin);
			
			if (!currentPassword.equalsIgnoreCase(userLogin.getUserPassword())) {
				model.addAttribute("classValue", "alert-warning");
				model.addAttribute("headerValue","Warning!");
				model.addAttribute("message", "Current Password Incorrect.!!!");
			} else if(!newPassword.equalsIgnoreCase(confirmPassword)) {
				model.addAttribute("classValue", "alert-warning");
				model.addAttribute("headerValue","Warning!");
				model.addAttribute("message", "New Password and Confirm Password Mismatch!!!");
			} else {
				int result = userService.updatePassword(Long.parseLong(userID), newPassword);
				System.out.println("Update Password: " + result);
				model.addAttribute("classValue", "alert-info");
				model.addAttribute("headerValue","Info!");
				model.addAttribute("message", "Change Password Successfull.");
			}
			return "Info";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
