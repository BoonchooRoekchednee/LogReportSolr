package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.ICompanyDAO;
import com.isoftbiz.setupdata.model.Company;

@Repository
public class CompanyDAO extends HibernateDaoSupport implements ICompanyDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Company findById(Long companyID) throws Exception {
		Company company = this.getHibernateTemplate().get(Company.class, companyID);
		return company;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Company> findAll() throws Exception {
		List<Company> companyList = session.createCriteria(Company.class).addOrder(Order.asc("companyName")).list();
		session.flush();
		session.clear();
		return companyList;
	}

	@Override
	public boolean save(Company company) throws Exception {
		this.getHibernateTemplate().save(company);
		return true;
	}

	@Override
	public boolean update(Company company) throws Exception {
		this.getHibernateTemplate().update(company);
		return true;
	}

	@Override
	public boolean delete(Company company) throws Exception {
		this.getHibernateTemplate().delete(company);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Company> searchCompany(String sCompanyCode, String sCompanyName,String sActiveFlag) throws Exception {
		StringBuilder sQuery = new StringBuilder();
		sQuery.append("from Company where CompanyID is not null ");
		if (sCompanyCode != null && !sCompanyCode.isEmpty()) {
			sQuery.append(" and CompanyCode like '%" + sCompanyCode + "%' ");
		}
		if (sCompanyName != null && !sCompanyName.isEmpty()) {
			sQuery.append(" and CompanyName like '%" + sCompanyName + "%' ");
		}
		if (sActiveFlag != null && !sActiveFlag.isEmpty() && !sActiveFlag.equalsIgnoreCase("A")) {
			sQuery.append(" and ActiveFlag = '" + sActiveFlag + "' ");
		}
		List<Company> companyList = this.getHibernateTemplate().find(sQuery.toString());
		return companyList;
	}
}
