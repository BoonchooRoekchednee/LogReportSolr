package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.IPositionDAO;
import com.isoftbiz.setupdata.model.Position;

@Repository
public class PositionDAO extends HibernateDaoSupport implements IPositionDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Position findById(Long positionID) throws Exception {
		Position position = this.getHibernateTemplate().get(Position.class, positionID);
		return position;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Position> findAll() throws Exception {
		List<Position> positionList = session.createCriteria(Position.class).addOrder(Order.asc("positionName")).list();
		session.flush();
		session.clear();
		return positionList;
	}

	@Override
	public boolean save(Position position) throws Exception {
		this.getHibernateTemplate().save(position);
		return true;
	}

	@Override
	public boolean update(Position position) throws Exception {
		this.getHibernateTemplate().update(position);
		return true;
	}

	@Override
	public boolean delete(Position position) throws Exception {
		this.getHibernateTemplate().delete(position);
		return true;
	}
}
