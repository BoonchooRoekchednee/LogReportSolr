package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.IDistrictDAO;
import com.isoftbiz.setupdata.model.District;

@Repository
public class DistrictDAO extends HibernateDaoSupport implements IDistrictDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public District findById(Long districtID) throws Exception {
		District district = this.getHibernateTemplate().get(District.class, districtID);
		return district;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<District> findAll() throws Exception {
		List<District> districtList = session.createCriteria(District.class).addOrder(Order.asc("districtName")).list();
		session.flush();
		session.clear();
		return districtList;
	}

	@Override
	public boolean save(District district) throws Exception {
		this.getHibernateTemplate().save(district);
		return true;
	}

	@Override
	public boolean update(District district) throws Exception {
		this.getHibernateTemplate().update(district);
		return true;
	}

	@Override
	public boolean delete(District district) throws Exception {
		this.getHibernateTemplate().delete(district);
		return true;
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<District> searchDistrict(String sDistrictCode, String sDistrictName, String sProvinceID) throws Exception {
		StringBuilder sQuery = new StringBuilder();
		sQuery.append("from District where DistrictID is not null ");
		if (sDistrictCode != null && !sDistrictCode.isEmpty()) {
			sQuery.append(" and DistrictCode like '%" + sDistrictCode + "%' ");
		}
		if (sDistrictName != null && !sDistrictName.isEmpty()) {
			sQuery.append(" and DistrictName like '%" + sDistrictName + "%' ");
		}
		if (sProvinceID != null && !sProvinceID.isEmpty()) {
			sQuery.append(" and ProvinceID = " + sProvinceID);
		}
		sQuery.append(" order by DistrictName asc ");
		List<District> districtList = this.getHibernateTemplate().find(sQuery.toString());
		return districtList;
	}
}
