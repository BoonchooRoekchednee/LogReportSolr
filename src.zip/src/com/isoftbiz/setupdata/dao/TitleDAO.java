package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.ITitleDAO;
import com.isoftbiz.setupdata.model.Title;

@Repository
public class TitleDAO extends HibernateDaoSupport implements ITitleDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Title findById(Long titleID) throws Exception {
		Title title = this.getHibernateTemplate().get(Title.class, titleID);
		return title;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Title> findAll() throws Exception {
		List<Title> titleList = session.createCriteria(Title.class).addOrder(Order.asc("titleName")).list();
		session.flush();
		session.clear();
		return titleList;
	}

	@Override
	public boolean save(Title title) throws Exception {
		this.getHibernateTemplate().save(title);
		return true;
	}

	@Override
	public boolean update(Title title) throws Exception {
		this.getHibernateTemplate().update(title);
		return true;
	}

	@Override
	public boolean delete(Title title) throws Exception {
		this.getHibernateTemplate().delete(title);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Title> listTitle() throws Exception {
		List<Title> titleList = this.getHibernateTemplate().find("from Title order by TitleName asc");
		return titleList;
	 }
}
