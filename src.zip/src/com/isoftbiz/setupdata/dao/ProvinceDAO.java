package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.IProvinceDAO;
import com.isoftbiz.setupdata.model.Province;

@Repository
public class ProvinceDAO extends HibernateDaoSupport implements IProvinceDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Province findById(Long provinceID) throws Exception {
		Province province = this.getHibernateTemplate().get(Province.class, provinceID);
		return province;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Province> findAll() throws Exception {
		List<Province> provinceList = session.createCriteria(Province.class).addOrder(Order.asc("provinceName")).list();
		session.flush();
		session.clear();
		return provinceList;
	}

	@Override
	public boolean save(Province province) throws Exception {
		this.getHibernateTemplate().save(province);
		return true;
	}

	@Override
	public boolean update(Province province) throws Exception {
		this.getHibernateTemplate().update(province);
		return true;
	}

	@Override
	public boolean delete(Province province) throws Exception {
		this.getHibernateTemplate().delete(province);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Province> searchProvince(String sProvinceCode, String sProvinceName, String sCountryID) throws Exception {
		StringBuilder sQuery = new StringBuilder();
		sQuery.append("from Province where ProvinceID is not null ");
		if (sProvinceCode != null && !sProvinceCode.isEmpty()) {
			sQuery.append(" and ProvinceCode like '%" + sProvinceCode + "%' ");
		}
		if (sProvinceName != null && !sProvinceName.isEmpty()) {
			sQuery.append(" and ProvinceName like '%" + sProvinceName + "%' ");
		}
		if (sCountryID != null && !sCountryID.isEmpty()) {
			sQuery.append(" and CountryID = " + sCountryID);
		}
		sQuery.append(" order by ProvinceName asc ");
		List<Province> provinceList = this.getHibernateTemplate().find(sQuery.toString());
		return provinceList;
	}
}
