package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.ICountryDAO;
import com.isoftbiz.setupdata.model.Country;

@Repository
public class CountryDAO extends HibernateDaoSupport implements ICountryDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Country findById(Long countryID) throws Exception {
		Country country = this.getHibernateTemplate().get(Country.class, countryID);
		return country;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Country> findAll() throws Exception {
		List<Country> countryList = session.createCriteria(Country.class).addOrder(Order.asc("countryName")).list();
		session.flush();
		session.clear();
		return countryList;
	}

	@Override
	public boolean save(Country country) throws Exception {
		this.getHibernateTemplate().save(country);
		return true;
	}

	@Override
	public boolean update(Country country) throws Exception {
		this.getHibernateTemplate().update(country);
		return true;
	}

	@Override
	public boolean delete(Country country) throws Exception {
		this.getHibernateTemplate().delete(country);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Country> searchCountry(String sCountryCode, String sCountryName) throws Exception {
		StringBuilder sQuery = new StringBuilder();
		sQuery.append("from Country where CountryID is not null ");
		if (sCountryCode != null && !sCountryCode.isEmpty()) {
			sQuery.append(" and CountryCode like '%" + sCountryCode + "%' ");
		}
		if (sCountryName != null && !sCountryName.isEmpty()) {
			sQuery.append(" and CountryName like '%" + sCountryName + "%' ");
		}
		List<Country> countryList = this.getHibernateTemplate().find(sQuery.toString());
		return countryList;
	}
}
