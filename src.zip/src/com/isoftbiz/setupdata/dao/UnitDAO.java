package com.isoftbiz.setupdata.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.setupdata.idao.IUnitDAO;
import com.isoftbiz.setupdata.model.Unit;

@Repository
public class UnitDAO extends HibernateDaoSupport implements IUnitDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Unit findById(Long unitID) throws Exception {
		Unit unit = this.getHibernateTemplate().get(Unit.class, unitID);
		return unit;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Unit> findAll() throws Exception {
		List<Unit> unitList = session.createCriteria(Unit.class).addOrder(Order.asc("unitName")).list();
		session.flush();
		session.clear();
		return unitList;
	}

	@Override
	public boolean save(Unit unit) throws Exception {
		this.getHibernateTemplate().save(unit);
		return true;
	}

	@Override
	public boolean update(Unit unit) throws Exception {
		this.getHibernateTemplate().update(unit);
		return true;
	}

	@Override
	public boolean delete(Unit unit) throws Exception {
		this.getHibernateTemplate().delete(unit);
		return true;
	}
}
