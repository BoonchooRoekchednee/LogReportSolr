package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.IDistrictDAO;
import com.isoftbiz.setupdata.iservice.IDistrictService;
import com.isoftbiz.setupdata.model.District;

@Service
@Transactional
public class DistrictService implements IDistrictService {
	@Autowired
	private IDistrictDAO districtDAO;

	@Override
	public District findById(Long districtID) throws Exception {
		return districtDAO.findById(districtID);
	}
	
	@Override
	public List<District> findAll() throws Exception {
		return districtDAO.findAll();
	}

	@Override
	public boolean save(District district) throws Exception {
		return districtDAO.save(district);
	}

	@Override
	public boolean update(District district) throws Exception {
		return districtDAO.update(district);
	}

	@Override
	public boolean delete(District district) throws Exception {
		return districtDAO.delete(district);
	}
	
	@Override
	public List<District> searchDistrict(String sDistrictCode, String sDistrictName, String sProvinceID) throws Exception {
		return districtDAO.searchDistrict(sDistrictCode, sDistrictName, sProvinceID);
	}
}
