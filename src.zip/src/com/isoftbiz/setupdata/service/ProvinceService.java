package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.IProvinceDAO;
import com.isoftbiz.setupdata.iservice.IProvinceService;
import com.isoftbiz.setupdata.model.Province;

@Service
@Transactional
public class ProvinceService implements IProvinceService {
	@Autowired
	private IProvinceDAO provinceDAO;

	@Override
	public Province findById(Long provinceID) throws Exception {
		return provinceDAO.findById(provinceID);
	}
	
	@Override
	public List<Province> findAll() throws Exception {
		return provinceDAO.findAll();
	}

	@Override
	public boolean save(Province province) throws Exception {
		return provinceDAO.save(province);
	}

	@Override
	public boolean update(Province province) throws Exception {
		return provinceDAO.update(province);
	}

	@Override
	public boolean delete(Province province) throws Exception {
		return provinceDAO.delete(province);
	}
	
	@Override
	public List<Province> searchProvince(String sProvinceCode, String sProvinceName, String sCountryID) throws Exception {
		return provinceDAO.searchProvince(sProvinceCode, sProvinceName, sCountryID);
	}
}
