package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.ICompanyDAO;
import com.isoftbiz.setupdata.iservice.ICompanyService;
import com.isoftbiz.setupdata.model.Company;

@Service
@Transactional
public class CompanyService implements ICompanyService {
	@Autowired
	private ICompanyDAO companyDAO;

	@Override
	public Company findById(Long companyID) throws Exception {
		return companyDAO.findById(companyID);
	}
	
	@Override
	public List<Company> findAll() throws Exception {
		return companyDAO.findAll();
	}

	@Override
	public boolean save(Company company) throws Exception {
		return companyDAO.save(company);
	}

	@Override
	public boolean update(Company company) throws Exception {
		return companyDAO.update(company);
	}

	@Override
	public boolean delete(Company company) throws Exception {
		return companyDAO.delete(company);
	}
	
	@Override
	public List<Company> searchCompany(String sCompanyCode, String sCompanyName,String sActiveFlag) throws Exception {
		return companyDAO.searchCompany(sCompanyCode, sCompanyName, sActiveFlag);
	}
}
