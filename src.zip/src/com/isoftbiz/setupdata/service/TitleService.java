package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.ITitleDAO;
import com.isoftbiz.setupdata.iservice.ITitleService;
import com.isoftbiz.setupdata.model.Title;

@Service
@Transactional
public class TitleService implements ITitleService {
	@Autowired
	private ITitleDAO titleDAO;

	@Override
	public Title findById(Long titleID) throws Exception {
		return titleDAO.findById(titleID);
	}
	
	@Override
	public List<Title> findAll() throws Exception {
		return titleDAO.findAll();
	}

	@Override
	public boolean save(Title title) throws Exception {
		return titleDAO.save(title);
	}

	@Override
	public boolean update(Title title) throws Exception {
		return titleDAO.update(title);
	}

	@Override
	public boolean delete(Title title) throws Exception {
		return titleDAO.delete(title);
	}
	
	@Override
	public List<Title> listTitle() throws Exception {
		return titleDAO.listTitle();
	}
}
