package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.ICountryDAO;
import com.isoftbiz.setupdata.iservice.ICountryService;
import com.isoftbiz.setupdata.model.Country;

@Service
@Transactional
public class CountryService implements ICountryService {
	@Autowired
	private ICountryDAO countryDAO;

	@Override
	public Country findById(Long countryID) throws Exception {
		return countryDAO.findById(countryID);
	}
	
	@Override
	public List<Country> findAll() throws Exception {
		return countryDAO.findAll();
	}

	@Override
	public boolean save(Country country) throws Exception {
		return countryDAO.save(country);
	}

	@Override
	public boolean update(Country country) throws Exception {
		return countryDAO.update(country);
	}

	@Override
	public boolean delete(Country country) throws Exception {
		return countryDAO.delete(country);
	}
	
	@Override
	public List<Country> searchCountry(String sCountryCode, String sCountryName) throws Exception {
		return countryDAO.searchCountry(sCountryCode, sCountryName);
	}
}
