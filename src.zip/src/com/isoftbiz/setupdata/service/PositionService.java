package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.IPositionDAO;
import com.isoftbiz.setupdata.iservice.IPositionService;
import com.isoftbiz.setupdata.model.Position;

@Service
@Transactional
public class PositionService implements IPositionService {
	@Autowired
	private IPositionDAO positionDAO;

	@Override
	public Position findById(Long positionID) throws Exception {
		return positionDAO.findById(positionID);
	}
	
	@Override
	public List<Position> findAll() throws Exception {
		return positionDAO.findAll();
	}

	@Override
	public boolean save(Position position) throws Exception {
		return positionDAO.save(position);
	}

	@Override
	public boolean update(Position position) throws Exception {
		return positionDAO.update(position);
	}

	@Override
	public boolean delete(Position position) throws Exception {
		return positionDAO.delete(position);
	}
}
