package com.isoftbiz.setupdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.setupdata.idao.IUnitDAO;
import com.isoftbiz.setupdata.iservice.IUnitService;
import com.isoftbiz.setupdata.model.Unit;

@Service
@Transactional
public class UnitService implements IUnitService {
	@Autowired
	private IUnitDAO unitDAO;

	@Override
	public Unit findById(Long unitID) throws Exception {
		return unitDAO.findById(unitID);
	}
	
	@Override
	public List<Unit> findAll() throws Exception {
		return unitDAO.findAll();
	}

	@Override
	public boolean save(Unit unit) throws Exception {
		return unitDAO.save(unit);
	}

	@Override
	public boolean update(Unit unit) throws Exception {
		return unitDAO.update(unit);
	}

	@Override
	public boolean delete(Unit unit) throws Exception {
		return unitDAO.delete(unit);
	}
}
