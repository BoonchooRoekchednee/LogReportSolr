package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.ICountryService;
import com.isoftbiz.setupdata.iservice.IProvinceService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Country;
import com.isoftbiz.setupdata.model.Province;
import com.isoftbiz.admin.model.User;

@Controller
public class ProvinceController {
	@Autowired
	private IProvinceService provinceService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private ICountryService countryService;
	
	@RequestMapping(value = "/Province.isoftbiz")
	public ModelAndView index() {
		try {
			Set<Province> provinceList = new HashSet<Province>(provinceService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("provinceList", provinceList);
			mav.setViewName("Province");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ProvinceNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("ProvinceNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ProvinceEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			Province province = provinceService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("province", province);
			mav.addObject("countryList", countryList);
			mav.setViewName("ProvinceEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ProvinceSave.isoftbiz", method = RequestMethod.POST)
	public String save(Province province) {
		try {
			provinceService.save(province);
			return "redirect:/Province.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/ProvinceUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Province province) {
		try {
			provinceService.update(province);
			return "redirect:/Province.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/ProvinceDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Province province = provinceService.findById(id);
			provinceService.delete(province);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/ProvinceSearch.isoftbiz")
	public ModelAndView searchForm() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("ProvinceSearch");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/SearchProvince.isoftbiz", method = RequestMethod.POST)
	public ModelAndView searchProvince(HttpServletRequest request) {
		try {
			String sProvinceCode = request.getParameter("provinceCode");
			String sProvinceName = request.getParameter("provinceName");
			String sCountryID = request.getParameter("countryID");
			
			Set<Province> provinceList = new HashSet<Province>(provinceService.searchProvince(sProvinceCode, sProvinceName, sCountryID));
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("provinceList", provinceList);
			mav.setViewName("Province");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
