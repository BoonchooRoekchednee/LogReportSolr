package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.IPositionService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Position;
import com.isoftbiz.admin.model.User;

@Controller
public class PositionController {
	@Autowired
	private IPositionService positionService;
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/Position.isoftbiz")
	public ModelAndView index() {
		try {
			Set<Position> positionList = new HashSet<Position>(positionService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("positionList", positionList);
			mav.setViewName("Position");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PositionNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("PositionNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PositionEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Position position = positionService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("position", position);
			mav.setViewName("PositionEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PositionSave.isoftbiz", method = RequestMethod.POST)
	public String save(Position position) {
		try {
			positionService.save(position);
			return "redirect:/Position.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/PositionUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Position position) {
		try {
			positionService.update(position);
			return "redirect:/Position.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/PositionDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Position position = positionService.findById(id);
			positionService.delete(position);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
}
