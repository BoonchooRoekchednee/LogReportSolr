package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.IProvinceService;
import com.isoftbiz.setupdata.iservice.IDistrictService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Province;
import com.isoftbiz.setupdata.model.District;
import com.isoftbiz.admin.model.User;

@Controller
public class DistrictController {
	@Autowired
	private IDistrictService districtService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IProvinceService provinceService;
	
	@RequestMapping(value = "/District.isoftbiz")
	public ModelAndView index() {
		try {
			Set<District> districtList = new HashSet<District>(districtService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("districtList", districtList);
			mav.setViewName("District");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/DistrictNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Province> provinceList = new HashSet<Province>(provinceService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("provinceList", provinceList);
			mav.setViewName("DistrictNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/DistrictEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Province> provinceList = new HashSet<Province>(provinceService.findAll());
			District district = districtService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("district", district);
			mav.addObject("provinceList", provinceList);
			mav.setViewName("DistrictEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/DistrictSave.isoftbiz", method = RequestMethod.POST)
	public String save(District district) {
		try {
			districtService.save(district);
			return "redirect:/District.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/DistrictUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(District district) {
		try {
			districtService.update(district);
			return "redirect:/District.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/DistrictDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			District district = districtService.findById(id);
			districtService.delete(district);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/DistrictSearch.isoftbiz")
	public ModelAndView searchForm() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Province> provinceList = new HashSet<Province>(provinceService.findAll());
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("provinceList", provinceList);
			mav.setViewName("DistrictSearch");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	

	@RequestMapping(value = "/SearchDistrict.isoftbiz", method = RequestMethod.POST)
	public ModelAndView searchDistrict(HttpServletRequest request) {
		try {
			String sDistrictCode = request.getParameter("districtCode");
			String sDistrictName = request.getParameter("districtName");
			String sProvinceID = request.getParameter("provinceID");
			
			Set<District> districtList = new HashSet<District>(districtService.searchDistrict(sDistrictCode, sDistrictName, sProvinceID));
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("districtList", districtList);
			mav.setViewName("District");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
