package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.ICompanyService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Company;
import com.isoftbiz.admin.model.User;

@Controller
public class CompanyController {
	@Autowired
	private ICompanyService companyService;
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/Company.isoftbiz")
	public ModelAndView index() {
		try {
			Set<Company> companyList = new HashSet<Company>(companyService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("companyList", companyList);
			mav.setViewName("Company");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CompanyNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("CompanyNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CompanyEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Company company = companyService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("company", company);
			mav.setViewName("CompanyEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CompanySave.isoftbiz", method = RequestMethod.POST)
	public String save(Company company) {
		try {
			companyService.save(company);
			return "redirect:/Company.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/CompanyUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Company company) {
		try {
			companyService.update(company);
			return "redirect:/Company.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/CompanyDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Company company = companyService.findById(id);
			companyService.delete(company);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/CompanySearch.isoftbiz")
	public ModelAndView searchForm() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("CompanySearch");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/SearchCompany.isoftbiz", method = RequestMethod.POST)
	public ModelAndView searchCompany(HttpServletRequest request) {
		try {
			String sCompanyCode = request.getParameter("companyCode");
			String sCompanyName = request.getParameter("companyName");
			String sActiveFlag = request.getParameter("activeFlag");
			
			Set<Company> companyList = new HashSet<Company>(companyService.searchCompany(sCompanyCode, sCompanyName, sActiveFlag));
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("companyList", companyList);
			mav.setViewName("Company");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
