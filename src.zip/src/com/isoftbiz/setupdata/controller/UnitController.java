package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.IUnitService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Unit;
import com.isoftbiz.admin.model.User;

@Controller
public class UnitController {
	@Autowired
	private IUnitService unitService;
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/Unit.isoftbiz")
	public ModelAndView index() {
		try {
			Set<Unit> unitList = new HashSet<Unit>(unitService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("unitList", unitList);
			mav.setViewName("Unit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UnitNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("UnitNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UnitEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Unit unit = unitService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("unit", unit);
			mav.setViewName("UnitEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/UnitSave.isoftbiz", method = RequestMethod.POST)
	public String save(Unit unit) {
		try {
			unitService.save(unit);
			return "redirect:/Unit.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/UnitUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Unit unit) {
		try {
			unitService.update(unit);
			return "redirect:/Unit.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/UnitDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Unit unit = unitService.findById(id);
			unitService.delete(unit);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
}
