package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.ICountryService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Country;
import com.isoftbiz.admin.model.User;

@Controller
public class CountryController {
	@Autowired
	private ICountryService countryService;
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/Country.isoftbiz")
	public ModelAndView index() {
		try {
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("Country");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CountryNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("CountryNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CountryEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Country country = countryService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("country", country);
			mav.setViewName("CountryEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CountrySave.isoftbiz", method = RequestMethod.POST)
	public String save(Country country) {
		try {
			countryService.save(country);
			return "redirect:/Country.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/CountryUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Country country) {
		try {
			countryService.update(country);
			return "redirect:/Country.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/CountryDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Country country = countryService.findById(id);
			countryService.delete(country);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/CountrySearch.isoftbiz")
	public ModelAndView searchForm() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("CountrySearch");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/SearchCountry.isoftbiz", method = RequestMethod.POST)
	public ModelAndView searchUser(HttpServletRequest request) {
		try {
			String sCountryCode = request.getParameter("countryCode");
			String sCountryName = request.getParameter("countryName");
			
			Set<Country> countryList = new HashSet<Country>(countryService.searchCountry(sCountryCode, sCountryName));
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("Country");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
