package com.isoftbiz.setupdata.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.setupdata.iservice.ITitleService;
import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.setupdata.model.Title;
import com.isoftbiz.admin.model.User;

@Controller
public class TitleController {
	@Autowired
	private ITitleService titleService;
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/Title.isoftbiz")
	public ModelAndView index() {
		try {
			Set<Title> titleList = new HashSet<Title>(titleService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("titleList", titleList);
			mav.setViewName("Title");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/TitleNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("TitleNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/TitleEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Title title = titleService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("title", title);
			mav.setViewName("TitleEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/TitleSave.isoftbiz", method = RequestMethod.POST)
	public String save(Title title) {
		try {
			titleService.save(title);
			return "redirect:/Title.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/TitleUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Title title) {
		try {
			titleService.update(title);
			return "redirect:/Title.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/TitleDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Title title = titleService.findById(id);
			titleService.delete(title);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
}
