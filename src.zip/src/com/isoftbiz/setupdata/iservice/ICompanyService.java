package com.isoftbiz.setupdata.iservice;

import java.util.List;

import com.isoftbiz.setupdata.model.Company;

public interface ICompanyService {
	public Company findById(Long companyID) throws Exception;

	public List<Company> findAll() throws Exception;

	public boolean save(Company company) throws Exception;

	public boolean update(Company company) throws Exception;

	public boolean delete(Company company) throws Exception;
	
	public List<Company> searchCompany(String sCompanyCode, String sCompanyName,String sActiveFlag) throws Exception;
}
