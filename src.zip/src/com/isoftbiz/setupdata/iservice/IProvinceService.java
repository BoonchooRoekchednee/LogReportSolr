package com.isoftbiz.setupdata.iservice;

import java.util.List;

import com.isoftbiz.setupdata.model.Province;

public interface IProvinceService {
	public Province findById(Long provinceID) throws Exception;

	public List<Province> findAll() throws Exception;

	public boolean save(Province province) throws Exception;

	public boolean update(Province province) throws Exception;

	public boolean delete(Province province) throws Exception;
	
	public List<Province> searchProvince(String sProvinceCode, String sProvinceName, String sCountryID) throws Exception;
}
