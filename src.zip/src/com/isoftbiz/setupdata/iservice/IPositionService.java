package com.isoftbiz.setupdata.iservice;

import java.util.List;

import com.isoftbiz.setupdata.model.Position;

public interface IPositionService {
	public Position findById(Long positionID) throws Exception;

	public List<Position> findAll() throws Exception;

	public boolean save(Position position) throws Exception;

	public boolean update(Position position) throws Exception;

	public boolean delete(Position position) throws Exception;
}
