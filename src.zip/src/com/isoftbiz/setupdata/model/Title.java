package com.isoftbiz.setupdata.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "Title")
public class Title {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TitleID")
	private Long titleID;
	
	@Column(name = "TitleCode", length = 32, unique = true, nullable = false)
	private String titleCode;
	
	@Column(name = "TitleName", length = 64, unique = true, nullable = false)
	private String titleName;
	
	@Column(name = "TitleNameAbbr", length = 32)
	private String titleNameAbbr;
	
	@Column(name = "TitleNameEN", length = 64)
	private String titleNameEN;
	
	@Column(name = "TitleNameAbbrEN", length = 32)
	private String titleNameAbbrEN;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getTitleID() {
		return titleID;
	}

	public void setTitleID(Long titleID) {
		this.titleID = titleID;
	}

	public String getTitleCode() {
		return titleCode;
	}

	public void setTitleCode(String titleCode) {
		this.titleCode = titleCode;
	}

	public String getTitleName() {
		return titleName;
	}

	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}

	public String getTitleNameAbbr() {
		return titleNameAbbr;
	}

	public void setTitleNameAbbr(String titleNameAbbr) {
		this.titleNameAbbr = titleNameAbbr;
	}

	public String getTitleNameEN() {
		return titleNameEN;
	}

	public void setTitleNameEN(String titleNameEN) {
		this.titleNameEN = titleNameEN;
	}

	public String getTitleNameAbbrEN() {
		return titleNameAbbrEN;
	}

	public void setTitleNameAbbrEN(String titleNameAbbrEN) {
		this.titleNameAbbrEN = titleNameAbbrEN;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
