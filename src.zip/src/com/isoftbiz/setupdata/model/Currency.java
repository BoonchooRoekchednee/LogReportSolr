package com.isoftbiz.setupdata.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Currency")
public class Currency {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CurrencyID")
	private Long currencyID;
	
	@Column(name = "CurrencyForeign", length = 32, nullable = false)
	private String currencyForeign;

	@Column(name = "Description", length = 128, nullable = true)
	private String description;
	
	@Column(name = "RateForeign", columnDefinition = "Decimal(12,4)")
	private Double rateForeign;
	
	@Column(name = "RateLocal", columnDefinition = "Decimal(12,4)")
	private Double rateLocal;

	public Long getCurrencyID() {
		return currencyID;
	}

	public void setCurrencyID(Long currencyID) {
		this.currencyID = currencyID;
	}

	public String getCurrencyForeign() {
		return currencyForeign;
	}

	public void setCurrencyForeign(String currencyForeign) {
		this.currencyForeign = currencyForeign;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getRateForeign() {
		return rateForeign;
	}

	public void setRateForeign(Double rateForeign) {
		this.rateForeign = rateForeign;
	}

	public Double getRateLocal() {
		return rateLocal;
	}

	public void setRateLocal(Double rateLocal) {
		this.rateLocal = rateLocal;
	}
}
