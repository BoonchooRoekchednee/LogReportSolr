package com.isoftbiz.setupdata.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "Province")
public class Province {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProvinceID")
	private Long provinceID;
	
	@Column(name = "ProvinceCode", length = 32, unique = true, nullable = false)
	private String provinceCode;
	
	@Column(name = "ProvinceName", length = 128, unique = true, nullable = false)
	private String provinceName;
	
	@Column(name = "ProvinceNameAbbr", length = 64)
	private String provinceNameAbbr;
	
	@Column(name = "ProvinceNameEN", length = 128)
	private String provinceNameEN;
	
	@Column(name = "ProvinceNameAbbrEN", length = 64)
	private String provinceNameAbbrEN;
	
	@ManyToOne
	@JoinColumn(name = "CountryID", nullable = true)
	private Country country;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getProvinceID() {
		return provinceID;
	}

	public void setProvinceID(Long provinceID) {
		this.provinceID = provinceID;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getProvinceNameAbbr() {
		return provinceNameAbbr;
	}

	public void setProvinceNameAbbr(String provinceNameAbbr) {
		this.provinceNameAbbr = provinceNameAbbr;
	}

	public String getProvinceNameEN() {
		return provinceNameEN;
	}

	public void setProvinceNameEN(String provinceNameEN) {
		this.provinceNameEN = provinceNameEN;
	}

	public String getProvinceNameAbbrEN() {
		return provinceNameAbbrEN;
	}

	public void setProvinceNameAbbrEN(String provinceNameAbbrEN) {
		this.provinceNameAbbrEN = provinceNameAbbrEN;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
