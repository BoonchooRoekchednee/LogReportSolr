package com.isoftbiz.setupdata.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "Country")
public class Country {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CountryID")
	private Long countryID;
	
	@Column(name = "CountryCode", length = 32, unique = true, nullable = false)
	private String countryCode;
	
	@Column(name = "CountryName", length = 128, unique = true, nullable = false)
	private String countryName;
	
	@Column(name = "CountryNameAbbr", length = 32)
	private String countryNameAbbr;
	
	@Column(name = "CountryNameEN", length = 128)
	private String countryNameEN;
	
	@Column(name = "CountryNameAbbrEN", length = 32)
	private String countryNameAbbrEN;
	
	@Column(name = "CountryFlag", length = 32)
	private String countryFlag;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getCountryID() {
		return countryID;
	}

	public void setCountryID(Long countryID) {
		this.countryID = countryID;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCountryNameAbbr() {
		return countryNameAbbr;
	}

	public void setCountryNameAbbr(String countryNameAbbr) {
		this.countryNameAbbr = countryNameAbbr;
	}

	public String getCountryNameEN() {
		return countryNameEN;
	}

	public void setCountryNameEN(String countryNameEN) {
		this.countryNameEN = countryNameEN;
	}

	public String getCountryNameAbbrEN() {
		return countryNameAbbrEN;
	}

	public void setCountryNameAbbrEN(String countryNameAbbrEN) {
		this.countryNameAbbrEN = countryNameAbbrEN;
	}

	public String getCountryFlag() {
		return countryFlag;
	}

	public void setCountryFlag(String countryFlag) {
		this.countryFlag = countryFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
