package com.isoftbiz.setupdata.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "Position")
public class Position {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PositionID")
	private Long positionID;
	
	@Column(name = "PositionCode", length = 32, unique = true, nullable = false)
	private String positionCode;
	
	@Column(name = "PositionName", length = 128, unique = true, nullable = false)
	private String positionName;
	
	@Column(name = "PositionNameAbbr", length = 64)
	private String positionNameAbbr;
	
	@Column(name = "PositionNameEN", length = 128)
	private String positionNameEN;
	
	@Column(name = "PositionNameAbbrEN", length = 64)
	private String positionNameAbbrEN;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getPositionID() {
		return positionID;
	}

	public void setPositionID(Long positionID) {
		this.positionID = positionID;
	}

	public String getPositionCode() {
		return positionCode;
	}

	public void setPositionCode(String positionCode) {
		this.positionCode = positionCode;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public String getPositionNameAbbr() {
		return positionNameAbbr;
	}

	public void setPositionNameAbbr(String positionNameAbbr) {
		this.positionNameAbbr = positionNameAbbr;
	}

	public String getPositionNameEN() {
		return positionNameEN;
	}

	public void setPositionNameEN(String positionNameEN) {
		this.positionNameEN = positionNameEN;
	}

	public String getPositionNameAbbrEN() {
		return positionNameAbbrEN;
	}

	public void setPositionNameAbbrEN(String positionNameAbbrEN) {
		this.positionNameAbbrEN = positionNameAbbrEN;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
