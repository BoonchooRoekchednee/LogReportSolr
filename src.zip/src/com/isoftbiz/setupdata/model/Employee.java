package com.isoftbiz.setupdata.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.isoftbiz.setupdata.model.Country;
import com.isoftbiz.setupdata.model.Position;
import com.isoftbiz.setupdata.model.Title;

@Entity
@Table(name = "Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EmpID")
	private Long empID;
	
	@Column(name = "EmpCode", length = 32, unique = true, nullable = false)
	private String empCode;
	
	@Column(name = "RegisterDate")
	@Type(type = "date")
	private Date registerDate;
	
	@ManyToOne
	@JoinColumn(name = "TitleID", nullable = true)
	private Title title;
	
	@Column(name = "FirstName", length = 64, nullable = false)
	private String firstName;
	
	@Column(name = "MiddleName", length = 64)
	private String middleName;
	
	@Column(name = "LastName", length = 64, nullable = false)
	private String lastName;
	
	@Column(name = "Gender", length = 1)
	private String gender;
	
	@Column(name = "MaritalStauts", length = 1)
	private  String maritalStatus;
	
	@Column(name = "DateOfBirth")
	@Type(type = "date")
	private Date dateOfBirth;
	
	@Column(name = "Nationality", length = 128)
	private String nationality;
	
	@ManyToOne
	@JoinColumn(name = "PositionID", nullable = true)
	private Position position;
	
	@Column(name = "Address", length = 255)
	private String address;
	
	@ManyToOne
	@JoinColumn(name = "CountryID", nullable = true)
	private Country country;
	
	@ManyToOne
	@JoinColumn(name = "ProvinceID", nullable = true)
	private Province province;
	
	@ManyToOne
	@JoinColumn(name = "DistrictID", nullable = true)
	private District district;
	
	@Column(name = "Zip", length = 10)
	private String zip;
	
	@Column(name = "Email", length = 128)
	private String email;
	
	@Column(name = "PhoneNumber", length = 64)
	private String phoneNumber;
	
	@Column(name = "MobileNumber", length = 32)
	private String mobileNumber;
	
	@Column(name = "FaxNumber", length = 32)
	private String faxNumber;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	@Column(name = "ActiveFlag", length = 1)
	private String activeFlag;
	
	@Column(name = "PictureFile", length = 64)
	private String pictureFile;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private Company company;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getEmpID() {
		return empID;
	}

	public void setEmpID(Long empID) {
		this.empID = empID;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public Date getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Province getProvince() {
		return province;
	}

	public void setProvince(Province province) {
		this.province = province;
	}

	public District getDistrict() {
		return district;
	}

	public void setDistrict(District district) {
		this.district = district;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getPictureFile() {
		return pictureFile;
	}

	public void setPictureFile(String pictureFile) {
		this.pictureFile = pictureFile;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
