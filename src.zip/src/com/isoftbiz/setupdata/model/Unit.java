package com.isoftbiz.setupdata.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Unit")
public class Unit {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "UnitID")
	private Long unitID;
	
	@Column(name = "UnitCode", length = 32, unique = true, nullable = false)
	private String unitCode;
	
	@Column(name = "UnitName", length = 128, unique = true, nullable = false)
	private String unitName;

	@Column(name = "UnitCodeCustoms", length = 32, unique = false)
	private String unitCodeCustoms;
	
	@Column(name = "UnitCodeBOI", length = 32, unique = false)
	private String unitCodeBOI;
	
	@Column(name = "UnitCodePublic", length = 32, unique = false)
	private String unitCodePbulic;
	
	public Long getUnitID() {
		return unitID;
	}

	public void setUnitID(Long unitID) {
		this.unitID = unitID;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getUnitCodeCustoms() {
		return unitCodeCustoms;
	}

	public void setUnitCodeCustoms(String unitCodeCustoms) {
		this.unitCodeCustoms = unitCodeCustoms;
	}

	public String getUnitCodeBOI() {
		return unitCodeBOI;
	}

	public void setUnitCodeBOI(String unitCodeBOI) {
		this.unitCodeBOI = unitCodeBOI;
	}

	public String getUnitCodePbulic() {
		return unitCodePbulic;
	}

	public void setUnitCodePbulic(String unitCodePbulic) {
		this.unitCodePbulic = unitCodePbulic;
	}
}
