package com.isoftbiz.setupdata.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "District")
public class District {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DistrictID")
	private Long districtID;
	
	@Column(name = "DistrictCode", length = 32, unique = true, nullable = false)
	private String districtCode;
	
	@Column(name = "DistrictName", length = 128, unique = true, nullable = false)
	private String districtName;
	
	@Column(name = "DistrictNameAbbr", length = 64)
	private String districtNameAbbr;
	
	@Column(name = "DistrictNameEN", length = 128)
	private String districtNameEN;
	
	@Column(name = "DistrictNameAbbrEN", length = 64)
	private String districtNameAbbrEN;
	
	@ManyToOne
	@JoinColumn(name = "ProvinceID", nullable = true)
	private Province province;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getDistrictID() {
		return districtID;
	}

	public void setDistrictID(Long districtID) {
		this.districtID = districtID;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getDistrictNameAbbr() {
		return districtNameAbbr;
	}

	public void setDistrictNameAbbr(String districtNameAbbr) {
		this.districtNameAbbr = districtNameAbbr;
	}

	public String getDistrictNameEN() {
		return districtNameEN;
	}

	public void setDistrictNameEN(String districtNameEN) {
		this.districtNameEN = districtNameEN;
	}

	public String getDistrictNameAbbrEN() {
		return districtNameAbbrEN;
	}

	public void setDistrictNameAbbrEN(String districtNameAbbrEN) {
		this.districtNameAbbrEN = districtNameAbbrEN;
	}

	public Province getProvince() {
		return province;
	}

	public void setProvince(Province province) {
		this.province = province;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
