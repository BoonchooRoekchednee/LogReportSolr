package com.isoftbiz.setupdata.idao;

import java.util.List;

import com.isoftbiz.setupdata.model.Country;

public interface ICountryDAO {
	public Country findById(Long countryID) throws Exception;

	public List<Country> findAll() throws Exception;

	public boolean save(Country country) throws Exception;

	public boolean update(Country country) throws Exception;

	public boolean delete(Country country) throws Exception;
	
	public List<Country> searchCountry(String sCountryCode, String sCountryName) throws Exception;
}
