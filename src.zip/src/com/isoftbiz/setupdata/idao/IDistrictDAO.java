package com.isoftbiz.setupdata.idao;

import java.util.List;

import com.isoftbiz.setupdata.model.District;

public interface IDistrictDAO {
	public District findById(Long districtID) throws Exception;

	public List<District> findAll() throws Exception;

	public boolean save(District district) throws Exception;

	public boolean update(District district) throws Exception;

	public boolean delete(District district) throws Exception;
	
	public List<District> searchDistrict(String sDistrictCode, String sDistrictName, String sProvinceID) throws Exception;
}
