package com.isoftbiz.setupdata.idao;

import java.util.List;

import com.isoftbiz.setupdata.model.Title;

public interface ITitleDAO {
	public Title findById(Long titleID) throws Exception;

	public List<Title> findAll() throws Exception;

	public boolean save(Title title) throws Exception;

	public boolean update(Title title) throws Exception;

	public boolean delete(Title title) throws Exception;

	public List<Title> listTitle() throws Exception;
}
