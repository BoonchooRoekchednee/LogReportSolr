package com.isoftbiz.setupdata.idao;

import java.util.List;

import com.isoftbiz.setupdata.model.Unit;

public interface IUnitDAO {
	public Unit findById(Long unitID) throws Exception;

	public List<Unit> findAll() throws Exception;

	public boolean save(Unit unit) throws Exception;

	public boolean update(Unit unit) throws Exception;

	public boolean delete(Unit unit) throws Exception;
}
