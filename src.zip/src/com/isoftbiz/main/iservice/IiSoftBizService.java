package com.isoftbiz.main.iservice;

import com.isoftbiz.main.model.iSoftBiz;

public interface IiSoftBizService {
	public iSoftBiz findById(Long iSoftBizID) throws Exception;
	
	public iSoftBiz findByCode(String iSoftBizCode) throws Exception;

	public boolean update(iSoftBiz isoftbiz) throws Exception;
}
