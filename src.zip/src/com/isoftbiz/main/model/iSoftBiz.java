package com.isoftbiz.main.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "iSoftBiz")
public class iSoftBiz {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "iSoftBizID")
	private Long iSoftBizID;
	
	@Column(name = "iSoftBizCode", length = 64, unique = true, nullable = false)
	private String iSoftBizCode;
	
	@Column(name = "Contact", length = 128)
	private String contact;
	
	@Column(name = "Email", length = 128)
	private String email;
	
	@Column(name = "MobileNumber", length = 32)
	private String mobileNumber;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	public Long getiSoftBizID() {
		return iSoftBizID;
	}

	public void setiSoftBizID(Long iSoftBizID) {
		this.iSoftBizID = iSoftBizID;
	}

	public String getiSoftBizCode() {
		return iSoftBizCode;
	}

	public void setiSoftBizCode(String iSoftBizCode) {
		this.iSoftBizCode = iSoftBizCode;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
