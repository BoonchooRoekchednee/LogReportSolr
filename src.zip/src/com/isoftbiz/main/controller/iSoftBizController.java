package com.isoftbiz.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.main.iservice.IiSoftBizService;
import com.isoftbiz.main.model.iSoftBiz;

@Controller
public class iSoftBizController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IiSoftBizService isoftbizService;
	
	@RequestMapping(value = "/iSoftBiz.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			iSoftBiz isoftbiz = isoftbizService.findById((long) 1);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("isoftbiz", isoftbiz);
			mav.setViewName("iSoftBiz");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/iSoftBizUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(iSoftBiz isoftbiz) {
		try {
			isoftbizService.update(isoftbiz);
			return "redirect:/iSoftBiz.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
