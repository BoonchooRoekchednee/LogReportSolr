package com.isoftbiz.main.util;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;

@SuppressWarnings("deprecation")
public class ReportPrint {
	public static void printReport(HttpServletRequest request, HttpServletResponse response, String sReport, String sRptName, String sSQL, String sRptType) throws SQLException, JRException, IOException, ServletException {
		Connection conn = dbConfig.getConnectionWithFile(request.getSession().getServletContext().getRealPath("/WEB-INF/classes/META-INF/database.properties"));
		Statement stmt = conn.createStatement();
		ResultSet myResult = stmt.executeQuery(sSQL);
		Map<String,Object> parameterMap = new HashMap<String,Object>();
		if (sRptName.equalsIgnoreCase("ReportImportItem")
				|| sRptName.equalsIgnoreCase("ReportMovementItem")) {
	    	String sStartDate = request.getParameter("receiveDateFrom");
	    	String sEndDate = request.getParameter("receiveDateTo");
	    	
	    	String sdate[] = sStartDate.split("\\-");
	        String edate[] = sEndDate.split("\\-");
	        parameterMap.put("startdate", sdate[2] + "/" + sdate[1] + "/" + sdate[0]);
	        parameterMap.put("enddate", edate[2] + "/" + edate[1] + "/" + edate[0]);
	        parameterMap.put("requesttype", request.getParameter("requestType"));
	        parameterMap.put("countryname", request.getParameter("countryName"));
	        parameterMap.put("importtype", request.getParameter("importType"));
	        parameterMap.put("industrytype", request.getParameter("industryType"));
	    } else if (sRptName.equalsIgnoreCase("ReportExportItem")) {
	    	String sStartDate = request.getParameter("receiveDateFrom");
	    	String sEndDate = request.getParameter("receiveDateTo");
	    	
	    	String sdate[] = sStartDate.split("\\-");
	        String edate[] = sEndDate.split("\\-");
	        parameterMap.put("startdate", sdate[2] + "/" + sdate[1] + "/" + sdate[0]);
	        parameterMap.put("enddate", edate[2] + "/" + edate[1] + "/" + edate[0]);
	        parameterMap.put("requesttype", request.getParameter("requestType"));
	        parameterMap.put("countryname", request.getParameter("countryName"));
	        parameterMap.put("exporttype", request.getParameter("exportType"));
	        parameterMap.put("industrytype", request.getParameter("industryType"));
	    }
		
		JRResultSetDataSource resultSetDataSource = new JRResultSetDataSource(myResult);
		JasperPrint jasperPrint = JasperFillManager.fillReport(sReport, parameterMap, resultSetDataSource);
	    OutputStream ouputStream = response.getOutputStream();
	    @SuppressWarnings("rawtypes")
		JRExporter exporter = null;
	    
	    if( "pdf".equalsIgnoreCase(sRptType) ){
	        response.setContentType("application/pdf");
	        exporter = new JRPdfExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    } else if( "rtf".equalsIgnoreCase(sRptType) ){
	        response.setContentType("application/rtf");
	        response.setHeader("Content-Disposition", "inline; filename=\"" + sRptName + ".rtf\"");
	        exporter = new JRRtfExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    } else if( "html".equalsIgnoreCase(sRptType) ) {
	        response.setContentType("text/html; charset=UTF-8");
	        exporter = new JRHtmlExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    } else if( "xls".equalsIgnoreCase(sRptType) ) {
	        response.setContentType("application/xls");
	        response.setHeader("Content-Disposition", "inline; filename=\"" + sRptName + ".xls\"");
	        exporter = new JRXlsExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    } else if( "xlsx".equalsIgnoreCase(sRptType) ) {
	        response.setContentType("application/xls");
	        response.setHeader("Content-Disposition", "inline; filename=\"" + sRptName + ".xlsx\"");
	        exporter = new JRXlsxExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    } else if( "csv".equalsIgnoreCase(sRptType) ) {
	        response.setContentType("application/csv");
	        response.setHeader("Content-Disposition", "inline; filename=\"" + sRptName + ".csv\"");
	        exporter = new JRCsvExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    } else if ("docx".equalsIgnoreCase(sRptType)) {
	    	response.setContentType("application/docx");
	        response.setHeader("Content-Disposition", "inline; filename=\"" + sRptName + ".docx\"");
	        exporter = new JRDocxExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, ouputStream);
	    }
	    try {
	        exporter.exportReport();
	    } catch (JRException e) {
	        throw new ServletException(e);
	    } finally {
	        if (ouputStream != null){
	            try {
	                ouputStream.close();
	            } catch (IOException ex) {
	                System.out.println(ex);
	            }
	        }
	    }
	    myResult.close();
	    stmt.close();
        conn.close(); 
	}
}
