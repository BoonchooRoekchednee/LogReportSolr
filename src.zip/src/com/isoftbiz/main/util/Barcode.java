package com.isoftbiz.main.util;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
 
import javax.imageio.ImageIO;
 
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.oned.Code128Writer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import java.io.FileOutputStream;

import com.lowagie.text.pdf.Barcode128;

public class Barcode {

	public static void createQRCodePNG(String filePath, String qrCodeText, int width, int height) {
		try {
			Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<EncodeHintType, ErrorCorrectionLevel>();
			hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
			QRCodeWriter qrCodeWriter = new QRCodeWriter();
			BitMatrix byteMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, width, height, hintMap);
			int matrixWidth = byteMatrix.getWidth();
			BufferedImage image = new BufferedImage(matrixWidth, matrixWidth, BufferedImage.TYPE_INT_RGB);
			image.createGraphics();
			Graphics2D graphics = (Graphics2D) image.getGraphics();
			graphics.setColor(Color.WHITE);
			graphics.fillRect(0, 0, matrixWidth, matrixWidth);
			graphics.setColor(Color.BLACK);
			for (int i = 0; i < matrixWidth; i++) {
				for (int j = 0; j < matrixWidth; j++) {
					if (byteMatrix.get(i, j)) {
						graphics.fillRect(i, j, 1, 1);
					}
				}
			}
			String fileType = "png";
	        File qrFile = new File(filePath + "/QRCode/" + qrCodeText + ".png");
			ImageIO.write(image, fileType, qrFile);
		} catch (WriterException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public static void createBarcode128(String filePath, String sBarcodeText, int width, int height) {
		BitMatrix bitMatrix;
		try {
			bitMatrix = new Code128Writer().encode(sBarcodeText, BarcodeFormat.CODE_128, width, height);
            MatrixToImageWriter.writeToStream(bitMatrix, "png", new FileOutputStream(new File(filePath + "/Barcode/" + sBarcodeText + ".png")));
		} catch (WriterException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public static void iTextBarcode128() {
		/*
		 * iText Barcode
		BarcodeEAN codeEAN = new BarcodeEAN();
		codeEAN.setCodeType(codeEAN.EAN13);
		codeEAN.setCode("9780201615883");
		Image imageEAN = codeEAN.createImageWithBarcode(cb, null, null);
		*/
		Barcode128 code128 = new Barcode128();
		code128.setCodeType(com.lowagie.text.pdf.Barcode.CODE128);
		code128.setCode("0123456789");
		//Image image128 = code128.createImageWithBarcode(cb, null, null);
		
	}
}
