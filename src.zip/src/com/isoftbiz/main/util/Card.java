package com.isoftbiz.main.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.MediaPrintableArea;
import javax.servlet.http.HttpServletRequest;
import javax.swing.ImageIcon;

import com.isoftbiz.main.util.Barcode;

public class Card {
	public static String createNameCard(HttpServletRequest request, int width, int height) {
		try {
			//Get parameter
			String sCode = request.getParameter("code");
			String sFirstName = request.getParameter("firstname");
			String sLastName = request.getParameter("lastname");
			String sCompany = request.getParameter("company");
			
			//Create QR Code
			//Barcode.createQRCodePNG(request.getSession().getServletContext().getRealPath(""), sCode, 58, 58);
			Barcode.createBarcode128(request.getSession().getServletContext().getRealPath(""), sCode, 58, 58);
			//Create Name Card
			BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d = bufferedImage.createGraphics();
			g2d.setColor(Color.WHITE);
			g2d.fillRect(0, 0, width, height);
			g2d.setColor(Color.BLACK);
			g2d.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			g2d.drawString(sFirstName + " " + sLastName, 65, 96);
			g2d.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
			g2d.drawString(sCompany, 65, 118);
			Image imgQRCode = new ImageIcon(request.getSession().getServletContext().getRealPath("/QRCode/" + sCode + ".png")).getImage();
			g2d.drawImage(imgQRCode, 260, 142, null);
			g2d.dispose();
			String filePath = request.getSession().getServletContext().getRealPath("/AttendeesCard/" + sCode + ".png");
			String fileType = "png";
			File cardFile = new File(filePath);
			ImageIO.write(bufferedImage, fileType, cardFile);
			
			//Return File Name
			return sCode + ".png";
		} catch (IOException e) {
            e.printStackTrace();
        }
		return null;
	}
	
	public static String createNameCardPNG(String sPath, String sCode, String sFirstName, String sLastName, String sCompany, int width, int height) {
		try {
			//Create QR Code
			Barcode.createQRCodePNG(sPath, sCode, 58, 58);
			
			//Create Name Card
			BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d = bufferedImage.createGraphics();
			g2d.setColor(Color.WHITE);
			g2d.fillRect(0, 0, width, height);
			g2d.setColor(Color.BLACK);
			g2d.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			g2d.drawString(sFirstName + " " + sLastName, 65, 96);
			g2d.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
			g2d.drawString(sCompany, 65, 118);
			Image imgQRCode = new ImageIcon(sPath + "/QRCode/" + sCode + ".png").getImage();
			g2d.drawImage(imgQRCode, 260, 142, null);
			g2d.dispose();
			String filePath = sPath + "/AttendeesCard/" + sCode + ".png";
			String fileType = "png";
			File cardFile = new File(filePath);
			ImageIO.write(bufferedImage, fileType, cardFile);
			
			//Return File Name
			return sCode + ".png";
		} catch (IOException e) {
            e.printStackTrace();
        }
		return null;
	}
	
	public static void printCard(HttpServletRequest request) throws Exception {
		String sFile = request.getSession().getServletContext().getRealPath("/AttendeesCard/" + request.getParameter("cardfile"));
		PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
	    DocFlavor flavor = DocFlavor.INPUT_STREAM.PNG;
	    //PrintService printService[] = PrintServiceLookup.lookupPrintServices(flavor, pras);
	    //PrintService defaultService = PrintServiceLookup.lookupDefaultPrintService();
	    //PrintService service = ServiceUI.printDialog(null, 200, 200, printService, defaultService, flavor, pras);
	    PrintService service = PrintServiceLookup.lookupDefaultPrintService();
	    if (service != null) {
			DocPrintJob job = service.createPrintJob();
			FileInputStream fis = new FileInputStream(sFile);
			DocAttributeSet das = new HashDocAttributeSet();
			das.add(new MediaPrintableArea(0, 0, 55, 85, MediaPrintableArea.MM));
			Doc doc = new SimpleDoc(fis, flavor, das);
			job.print(doc, pras);
	    }
	    
	}
	
	public static String getPrinter(String sFile) {
		String sPrinterName = "";
		File file = new File(sFile);
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			sPrinterName = br.readLine();
			br.close();
			return sPrinterName;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}
}
