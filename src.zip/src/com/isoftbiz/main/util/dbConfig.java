package com.isoftbiz.main.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;

public class dbConfig {
	public static Connection getConnectionWithFile(String sFile) {
		Connection connect = null;
		String sDriver = "", sURL = "", sUserName = "", sPassword = "";
		File file = new File(sFile);
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			sDriver = br.readLine().replace("database.driverClassName=", "").trim();
			sURL = br.readLine().replace("database.url=", "").trim();
			sUserName = br.readLine().replace("database.username=", "").trim();
			sPassword = br.readLine().replace("database.password=", "").trim();
			br.close();
			Class.forName(sDriver);
			connect =  DriverManager.getConnection(sURL + "?user=" + sUserName + "&password=" + sPassword);
			if (connect != null) {
				System.out.println("Database Connect Successful.");
				return connect;
			} else {
				System.out.println("Database Connect Failed.");
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
