package com.isoftbiz.main.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.MediaPrintableArea;
import javax.servlet.http.HttpServletRequest;
import javax.swing.ImageIcon;

public class LabelReceive {
	public static String labelReceive(HttpServletRequest request, int width, int height) {
		try {
			String sRequestID = (String) request.getAttribute("requestid");
			String sRequestCode = (String) request.getAttribute("requestcode");
			String sRequestType = (String) request.getAttribute("requesttype");
			String sCountry = (String) request.getAttribute("country");
			String sBarcode = (String) request.getAttribute("barcode");
			String sItemCode = (String) request.getAttribute("itemcode");
			String sItemName = (String) request.getAttribute("itemname");
			String sInvoice = (String) request.getAttribute("invoice");
			String sQuantity = (String) request.getAttribute("quantity");
			String sUnit = (String) request.getAttribute("unit");
			String sWeight = (String) request.getAttribute("weight");
			String sAmount = (String) request.getAttribute("amount");
			
			
			Barcode.createBarcode128(request.getSession().getServletContext().getRealPath(""), sBarcode, 200, 40);
			
			BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g2d = bufferedImage.createGraphics();
			g2d.setColor(Color.WHITE);
			g2d.fillRect(0, 0, width, height);
			g2d.setColor(Color.BLACK);
			g2d.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
			Image imgLogo = new ImageIcon(request.getSession().getServletContext().getRealPath("/img/bgaclogo.png")).getImage();
			g2d.drawImage(imgLogo, 390, 10, null);
			g2d.drawString("Request ID#: " + sRequestID, 10, 50);
			g2d.drawString("Code: " + sRequestCode, 200, 50);
			g2d.drawString("Oversea/Domestic: " + sRequestType, 10, 80);
			g2d.drawString("Country: " + sCountry, 200, 80);
			g2d.drawString("Item Code: " + sItemCode, 10, 110);
			g2d.drawString("Item: " + sItemName, 10, 140);
			g2d.drawString("Invoice: " + sInvoice, 10, 170);
			g2d.drawString("Quantity: " + sQuantity + " " + sUnit, 200, 170);
			g2d.drawString("Weight: " + sWeight + " KG.", 10, 200);
			g2d.drawString("Amount: " + sAmount, 200, 200);
			Image imgBarcode = new ImageIcon(request.getSession().getServletContext().getRealPath("/Barcode/" + sBarcode + ".png")).getImage();
			g2d.drawImage(imgBarcode, 50, 220, null);
			g2d.drawString(sBarcode, 80, 285);
			g2d.dispose();
			String filePath = request.getSession().getServletContext().getRealPath("/Label/" + sBarcode + ".png");
			String fileType = "png";
			File receiveFile = new File(filePath);
			ImageIO.write(bufferedImage, fileType, receiveFile);
			
			return sBarcode + ".png";
		} catch (IOException e) {
            e.printStackTrace();
        }
		return null;
	}
	
	public static void printLabel(HttpServletRequest request) throws Exception {
		String sFile = request.getSession().getServletContext().getRealPath("/Label/" + request.getParameter("labelfile"));
		PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
	    DocFlavor flavor = DocFlavor.INPUT_STREAM.PNG;
	    //PrintService printService[] = PrintServiceLookup.lookupPrintServices(flavor, pras);
	    //PrintService defaultService = PrintServiceLookup.lookupDefaultPrintService();
	    //PrintService service = ServiceUI.printDialog(null, 200, 200, printService, defaultService, flavor, pras);
	    PrintService service = PrintServiceLookup.lookupDefaultPrintService();
	    if (service != null) {
			DocPrintJob job = service.createPrintJob();
			FileInputStream fis = new FileInputStream(sFile);
			DocAttributeSet das = new HashDocAttributeSet();
			das.add(new MediaPrintableArea(0, 0, 100, 90, MediaPrintableArea.MM));
			Doc doc = new SimpleDoc(fis, flavor, das);
			job.print(doc, pras);
	    }
	    
	}
	
	public static String getPrinter(String sFile) {
		String sPrinterName = "";
		File file = new File(sFile);
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			sPrinterName = br.readLine();
			br.close();
			return sPrinterName;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}
}
