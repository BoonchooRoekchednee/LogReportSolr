package com.isoftbiz.main.idao;

import com.isoftbiz.main.model.iSoftBiz;

public interface IiSoftBizDAO {
	public iSoftBiz findById(Long iSoftBizID) throws Exception;
	
	public iSoftBiz findByCode(String iSoftBizCode) throws Exception;

	public boolean update(iSoftBiz isoftbiz) throws Exception;
}
