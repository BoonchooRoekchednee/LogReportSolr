package com.isoftbiz.main.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.main.model.iSoftBiz;
import com.isoftbiz.main.idao.IiSoftBizDAO;

@Repository
public class iSoftBizDAO extends HibernateDaoSupport implements IiSoftBizDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public iSoftBiz findById(Long iSoftBizID) throws Exception {
		iSoftBiz isoftbiz = this.getHibernateTemplate().get(iSoftBiz.class, iSoftBizID);
		return isoftbiz;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public iSoftBiz findByCode(String iSoftBizCode) throws Exception {
		List isoftbiz = this.getHibernateTemplate().find("from iSoftBiz where iSoftBizCode=?",iSoftBizCode);
		return (iSoftBiz)isoftbiz.get(0);
	}

	@Override
	public boolean update(iSoftBiz isoftbiz) throws Exception {
		this.getHibernateTemplate().update(isoftbiz);
		return true;
	}
}
