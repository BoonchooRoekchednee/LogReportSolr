package com.isoftbiz.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.main.idao.IiSoftBizDAO;
import com.isoftbiz.main.iservice.IiSoftBizService;
import com.isoftbiz.main.model.iSoftBiz;

@Service
@Transactional
public class iSoftBizService implements IiSoftBizService {
	@Autowired
	private IiSoftBizDAO iSoftBizDAO;
	
	@Override
	public iSoftBiz findById(Long iSoftBizID) throws Exception {
		return iSoftBizDAO.findById(iSoftBizID);
	}

	@Override
	public iSoftBiz findByCode(String iSoftBizCode) throws Exception {
		return iSoftBizDAO.findByCode(iSoftBizCode);
	}
	
	@Override
	public boolean update(iSoftBiz isoftbiz) throws Exception {
		return iSoftBizDAO.update(isoftbiz);
	}
}
