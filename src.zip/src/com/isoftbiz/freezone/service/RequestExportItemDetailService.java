package com.isoftbiz.freezone.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IRequestExportItemDetailDAO;
import com.isoftbiz.freezone.iservice.IRequestExportItemDetailService;
import com.isoftbiz.freezone.model.RequestExportItemDetail;

@Service
@Transactional
public class RequestExportItemDetailService implements IRequestExportItemDetailService {
	@Autowired
	private IRequestExportItemDetailDAO requestExportItemDetailDAO;
	
	@Override
	public RequestExportItemDetail findById(Long requestDetailID) throws Exception {
		return requestExportItemDetailDAO.findById(requestDetailID);
	}

	@Override
	public List<RequestExportItemDetail> findAll(Long requestID) throws Exception {
		return requestExportItemDetailDAO.findAll(requestID);
	}

	@Override
	public boolean save(RequestExportItemDetail requestExportItemDetail) throws Exception {
		return requestExportItemDetailDAO.save(requestExportItemDetail);
	}

	@Override
	public boolean update(RequestExportItemDetail requestExportItemDetail) throws Exception {
		return requestExportItemDetailDAO.update(requestExportItemDetail);
	}

	@Override
	public boolean delete(RequestExportItemDetail requestExportItemDetail) throws Exception {
		return requestExportItemDetailDAO.delete(requestExportItemDetail);
	}
	
	@Override
	public int saveReceiveItemDetail(HttpServletRequest request) throws Exception {
		return requestExportItemDetailDAO.saveReceiveItemDetail(request);
	}
	
	@Override
	public int saveReceiveItemDetailByCompany(HttpServletRequest request) throws Exception {
		return requestExportItemDetailDAO.saveReceiveItemDetailByCompany(request);
	}
}
