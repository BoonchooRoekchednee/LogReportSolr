package com.isoftbiz.freezone.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IRequestImportItemDAO;
import com.isoftbiz.freezone.model.RequestImportItem;
import com.isoftbiz.freezone.iservice.IRequestImportItemService;

@Service
@Transactional
public class RequestImportItemService implements IRequestImportItemService {
	@Autowired
	private IRequestImportItemDAO requestImportItemDAO;

	@Override
	public RequestImportItem findById(Long requestID) throws Exception {
		return requestImportItemDAO.findById(requestID);
	}
	
	@Override
	public RequestImportItem findByRequestCode(String requestCode) throws Exception {
		return requestImportItemDAO.findByRequestCode(requestCode);
	}
	
	@Override
	public RequestImportItem findByRequestCodeCompany(String requestCode, Long companyID) throws Exception {
		return requestImportItemDAO.findByRequestCodeCompany(requestCode, companyID);
	}
	
	@Override
	public List<RequestImportItem> findAll() throws Exception {
		return requestImportItemDAO.findAll();
	}
	
	@Override
	public List<RequestImportItem> listOfFreeZone() throws Exception {
		return requestImportItemDAO.listOfFreeZone();
	}
	
	@Override
	public List<RequestImportItem> listOfCompany() throws Exception {
		return requestImportItemDAO.listOfCompany();
	}
	
	@Override
	public List<RequestImportItem> listOfCompany(Long companyID) throws Exception {
		return requestImportItemDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(RequestImportItem requestImportItem) throws Exception {
		return requestImportItemDAO.save(requestImportItem);
	}

	@Override
	public boolean update(RequestImportItem requestImportItem) throws Exception {
		return requestImportItemDAO.update(requestImportItem);
	}

	@Override
	public boolean delete(RequestImportItem requestImportItem) throws Exception {
		return requestImportItemDAO.delete(requestImportItem);
	}
	
	@Override
	public int updateReceiveStatus(Long requestID, String status) throws Exception {
		return requestImportItemDAO.updateReceiveStatus(requestID, status);
	}
	
	@Override
	public int updateRecordStatus(Long requestID, String status) throws Exception {
		return requestImportItemDAO.updateRecordStatus(requestID, status);
	}
	
	@Override
	public int saveReceiveItem(HttpServletRequest request) throws Exception {
		return requestImportItemDAO.saveReceiveItem(request);
	}
	
	@Override
	public int transferItem(Long requestID) throws Exception {
		return requestImportItemDAO.transferItem(requestID);
	}
	
	@Override
	public List<RequestImportItem> searchByReceiveDate(String sStartDate, String sEndDate) throws Exception {
		return requestImportItemDAO.searchByReceiveDate(sStartDate, sEndDate);
	}
	
	@Override
	public List<RequestImportItem> searchByTransferDate(String sStartDate, String sEndDate) throws Exception {
		return requestImportItemDAO.searchByTransferDate(sStartDate, sEndDate);
	}
	
	@Override
	public List<RequestImportItem> searchReport(HttpServletRequest request) throws Exception {
		return requestImportItemDAO.searchReport(request);
	}
}
