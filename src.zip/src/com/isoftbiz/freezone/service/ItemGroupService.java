package com.isoftbiz.freezone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IItemGroupDAO;
import com.isoftbiz.freezone.model.ItemGroup;
import com.isoftbiz.freezone.iservice.IItemGroupService;

@Service
@Transactional
public class ItemGroupService implements IItemGroupService {
	@Autowired
	private IItemGroupDAO itemGroupDAO;

	@Override
	public ItemGroup findById(Long itemGroupID) throws Exception {
		return itemGroupDAO.findById(itemGroupID);
	}
	
	@Override
	public ItemGroup findByItemGroupCode(String itemGroupCode) throws Exception {
		return itemGroupDAO.findByItemGroupCode(itemGroupCode);
	}
	
	@Override
	public ItemGroup findByItemGroupCodeCompany(String itemGroupCode, Long companyID) throws Exception {
		return itemGroupDAO.findByItemGroupCodeCompany(itemGroupCode, companyID);
	}
	
	@Override
	public List<ItemGroup> findAll() throws Exception {
		return itemGroupDAO.findAll();
	}
	
	@Override
	public List<ItemGroup> listOfFreeZone() throws Exception {
		return itemGroupDAO.listOfFreeZone();
	}
	
	@Override
	public List<ItemGroup> listOfCompany(Long companyID) throws Exception {
		return itemGroupDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(ItemGroup itemGroup) throws Exception {
		return itemGroupDAO.save(itemGroup);
	}

	@Override
	public boolean update(ItemGroup itemGroup) throws Exception {
		return itemGroupDAO.update(itemGroup);
	}

	@Override
	public boolean delete(ItemGroup itemGroup) throws Exception {
		return itemGroupDAO.delete(itemGroup);
	}
}
