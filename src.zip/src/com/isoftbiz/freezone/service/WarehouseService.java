package com.isoftbiz.freezone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IWarehouseDAO;
import com.isoftbiz.freezone.model.Warehouse;
import com.isoftbiz.freezone.iservice.IWarehouseService;

@Service
@Transactional
public class WarehouseService implements IWarehouseService {
	@Autowired
	private IWarehouseDAO warehouseDAO;

	@Override
	public Warehouse findById(Long warehouseID) throws Exception {
		return warehouseDAO.findById(warehouseID);
	}
	
	@Override
	public Warehouse findByWarehouseCode(String warehouseCode) throws Exception {
		return warehouseDAO.findByWarehouseCode(warehouseCode);
	}
	
	@Override
	public Warehouse findByWarehouseCodeCompany(String warehouseCode, Long companyID) throws Exception {
		return warehouseDAO.findByWarehouseCodeCompany(warehouseCode, companyID);
	}
	
	@Override
	public List<Warehouse> findAll() throws Exception {
		return warehouseDAO.findAll();
	}
	
	@Override
	public List<Warehouse> listOfFreeZone() throws Exception {
		return warehouseDAO.listOfFreeZone();
	}
	
	@Override
	public List<Warehouse> listOfCompany(Long companyID) throws Exception {
		return warehouseDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(Warehouse warehouse) throws Exception {
		return warehouseDAO.save(warehouse);
	}

	@Override
	public boolean update(Warehouse warehouse) throws Exception {
		return warehouseDAO.update(warehouse);
	}

	@Override
	public boolean delete(Warehouse warehouse) throws Exception {
		return warehouseDAO.delete(warehouse);
	}
}
