package com.isoftbiz.freezone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IItemMasterDAO;
import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.freezone.iservice.IItemMasterService;

@Service
@Transactional
public class ItemMasterService implements IItemMasterService {
	@Autowired
	private IItemMasterDAO itemMasterDAO;

	@Override
	public ItemMaster findById(Long itemID) throws Exception {
		return itemMasterDAO.findById(itemID);
	}
	
	@Override
	public ItemMaster findByItemCode(String itemCode) throws Exception {
		return itemMasterDAO.findByItemCode(itemCode);
	}
	
	@Override
	public ItemMaster findByItemCodeCompany(String itemCode, Long companyID) throws Exception {
		return itemMasterDAO.findByItemCodeCompany(itemCode, companyID);
	}
	
	@Override
	public List<ItemMaster> findAll() throws Exception {
		return itemMasterDAO.findAll();
	}
	
	@Override
	public List<ItemMaster> listOfFreeZone() throws Exception {
		return itemMasterDAO.listOfFreeZone();
	}
	
	@Override
	public List<ItemMaster> listOfCompany(Long companyID) throws Exception {
		return itemMasterDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(ItemMaster itemMaster) throws Exception {
		return itemMasterDAO.save(itemMaster);
	}

	@Override
	public boolean update(ItemMaster itemMaster) throws Exception {
		return itemMasterDAO.update(itemMaster);
	}

	@Override
	public boolean delete(ItemMaster itemMaster) throws Exception {
		return itemMasterDAO.delete(itemMaster);
	}
}
