package com.isoftbiz.freezone.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IRequestExportItemDAO;
import com.isoftbiz.freezone.model.RequestExportItem;
import com.isoftbiz.freezone.iservice.IRequestExportItemService;

@Service
@Transactional
public class RequestExportItemService implements IRequestExportItemService {
	@Autowired
	private IRequestExportItemDAO requestExportItemDAO;

	@Override
	public RequestExportItem findById(Long requestID) throws Exception {
		return requestExportItemDAO.findById(requestID);
	}
	
	@Override
	public RequestExportItem findByRequestCode(String requestCode) throws Exception {
		return requestExportItemDAO.findByRequestCode(requestCode);
	}
	
	@Override
	public RequestExportItem findByRequestCodeCompany(String requestCode, Long companyID) throws Exception {
		return requestExportItemDAO.findByRequestCodeCompany(requestCode, companyID);
	}
	
	@Override
	public List<RequestExportItem> findAll() throws Exception {
		return requestExportItemDAO.findAll();
	}
	
	@Override
	public List<RequestExportItem> listOfFreeZone() throws Exception {
		return requestExportItemDAO.listOfFreeZone();
	}
	
	@Override
	public List<RequestExportItem> listOfCompany() throws Exception {
		return requestExportItemDAO.listOfCompany();
	}
	
	@Override
	public List<RequestExportItem> listOfCompany(Long companyID) throws Exception {
		return requestExportItemDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(RequestExportItem requestExportItem) throws Exception {
		return requestExportItemDAO.save(requestExportItem);
	}

	@Override
	public boolean update(RequestExportItem requestExportItem) throws Exception {
		return requestExportItemDAO.update(requestExportItem);
	}

	@Override
	public boolean delete(RequestExportItem requestExportItem) throws Exception {
		return requestExportItemDAO.delete(requestExportItem);
	}
	
	@Override
	public int updateReceiveStatus(Long requestID, String status) throws Exception {
		return requestExportItemDAO.updateReceiveStatus(requestID, status);
	}
	
	@Override
	public int updateRecordStatus(Long requestID, String status) throws Exception {
		return requestExportItemDAO.updateRecordStatus(requestID, status);
	}
	
	@Override
	public int saveReceiveItem(HttpServletRequest request) throws Exception {
		return requestExportItemDAO.saveReceiveItem(request);
	}
	
	@Override
	public int transferItem(Long requestID) throws Exception {
		return requestExportItemDAO.transferItem(requestID);
	}
	
	@Override
	public List<RequestExportItem> searchByReceiveDate(String sStartDate, String sEndDate) throws Exception {
		return requestExportItemDAO.searchByReceiveDate(sStartDate, sEndDate);
	}
	
	@Override
	public List<RequestExportItem> searchReport(HttpServletRequest request) throws Exception {
		return requestExportItemDAO.searchReport(request);
	}
}
