package com.isoftbiz.freezone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.ILocationDAO;
import com.isoftbiz.freezone.model.Location;
import com.isoftbiz.freezone.iservice.ILocationService;

@Service
@Transactional
public class LocationService implements ILocationService {
	@Autowired
	private ILocationDAO locationDAO;

	@Override
	public Location findById(Long locationID) throws Exception {
		return locationDAO.findById(locationID);
	}
	
	@Override
	public Location findByLocationCode(String locationCode) throws Exception {
		return locationDAO.findByLocationCode(locationCode);
	}
	
	@Override
	public Location findByLocationCodeCompany(String locationCode, Long companyID) throws Exception {
		return locationDAO.findByLocationCodeCompany(locationCode, companyID);
	}
	
	@Override
	public List<Location> findAll() throws Exception {
		return locationDAO.findAll();
	}
	
	@Override
	public List<Location> listOfFreeZone() throws Exception {
		return locationDAO.listOfFreeZone();
	}
	
	@Override
	public List<Location> listOfCompany(Long companyID) throws Exception {
		return locationDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(Location location) throws Exception {
		return locationDAO.save(location);
	}

	@Override
	public boolean update(Location location) throws Exception {
		return locationDAO.update(location);
	}

	@Override
	public boolean delete(Location location) throws Exception {
		return locationDAO.delete(location);
	}
}
