package com.isoftbiz.freezone.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IRequestImportItemDetailDAO;
import com.isoftbiz.freezone.iservice.IRequestImportItemDetailService;
import com.isoftbiz.freezone.model.RequestImportItemDetail;

@Service
@Transactional
public class RequestImportItemDetailService implements IRequestImportItemDetailService {
	@Autowired
	private IRequestImportItemDetailDAO requestImportItemDetailDAO;
	
	@Override
	public RequestImportItemDetail findById(Long requestDetailID) throws Exception {
		return requestImportItemDetailDAO.findById(requestDetailID);
	}

	@Override
	public List<RequestImportItemDetail> findAll(Long requestID) throws Exception {
		return requestImportItemDetailDAO.findAll(requestID);
	}

	@Override
	public boolean save(RequestImportItemDetail requestImportItemDetail) throws Exception {
		return requestImportItemDetailDAO.save(requestImportItemDetail);
	}

	@Override
	public boolean update(RequestImportItemDetail requestImportItemDetail) throws Exception {
		return requestImportItemDetailDAO.update(requestImportItemDetail);
	}

	@Override
	public boolean delete(RequestImportItemDetail requestImportItemDetail) throws Exception {
		return requestImportItemDetailDAO.delete(requestImportItemDetail);
	}
	
	@Override
	public int saveReceiveItemDetail(HttpServletRequest request) throws Exception {
		return requestImportItemDetailDAO.saveReceiveItemDetail(request);
	}
	
	@Override
	public int saveReceiveItemDetailByCompany(HttpServletRequest request) throws Exception {
		return requestImportItemDetailDAO.saveReceiveItemDetailByCompany(request);
	}
}
