package com.isoftbiz.freezone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.freezone.idao.IItemTypeDAO;
import com.isoftbiz.freezone.model.ItemType;
import com.isoftbiz.freezone.iservice.IItemTypeService;

@Service
@Transactional
public class ItemTypeService implements IItemTypeService {
	@Autowired
	private IItemTypeDAO itemTypeDAO;

	@Override
	public ItemType findById(Long itemTypeID) throws Exception {
		return itemTypeDAO.findById(itemTypeID);
	}

	@Override
	public ItemType findByItemTypeCode(String itemTypeCode) throws Exception {
		return itemTypeDAO.findByItemTypeCode(itemTypeCode);
	}
	
	@Override
	public List<ItemType> findAll() throws Exception {
		return itemTypeDAO.findAll();
	}
	
	@Override
	public boolean save(ItemType itemType) throws Exception {
		return itemTypeDAO.save(itemType);
	}

	@Override
	public boolean update(ItemType itemType) throws Exception {
		return itemTypeDAO.update(itemType);
	}

	@Override
	public boolean delete(ItemType itemType) throws Exception {
		return itemTypeDAO.delete(itemType);
	}
}
