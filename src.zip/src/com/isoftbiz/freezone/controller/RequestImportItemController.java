package com.isoftbiz.freezone.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IRequestImportItemDetailService;
import com.isoftbiz.freezone.iservice.IRequestImportItemService;
import com.isoftbiz.freezone.model.RequestImportItem;
import com.isoftbiz.freezone.model.RequestImportItemDetail;
import com.isoftbiz.main.util.LabelReceive;
import com.isoftbiz.main.util.ReportPrint;
import com.isoftbiz.setupdata.iservice.ICompanyService;
import com.isoftbiz.setupdata.iservice.ICountryService;
import com.isoftbiz.setupdata.model.Company;
import com.isoftbiz.setupdata.model.Country;

import net.sf.jasperreports.engine.JRException;

@Controller
public class RequestImportItemController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private ICountryService countryService;
	
	@Autowired
	private IRequestImportItemService requestImportItemService;
	
	@Autowired
	private IRequestImportItemDetailService requestImportItemDetailService;
	
	@Autowired
	private ICompanyService companyService;
	
	@RequestMapping(value = "/RequestImportItem.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<RequestImportItem> requestImportItemList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.listOfCompany());
			} else {
				requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("requestImportItemList", requestImportItemList);
			mav.addObject("titleShow", "Request Import Item List From Company In Free Zone");
			mav.setViewName("RequestImportItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemByFreeZone.isoftbiz")
	public ModelAndView indexByFreeZone() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<RequestImportItem> requestImportItemList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.listOfFreeZone());
			} else {
				requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("requestImportItemList", requestImportItemList);
			mav.addObject("titleShow", "Request Import Item List Of Free Zone");
			mav.setViewName("RequestImportItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("185")) {
				mav.addObject("OwnerFreeZone", "N");
			} else {
				mav.addObject("OwnerFreeZone", "Y");
			}
			mav.setViewName("RequestImportItemNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			RequestImportItem requestImportItem = requestImportItemService.findById(id);
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184") && (requestImportItem.getOwnerFreeZone().equalsIgnoreCase("Y")))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					if (sRole.equalsIgnoreCase("185") && !(requestImportItem.getRecordStatus().equalsIgnoreCase("New"))) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Please wait receive item by free zone.");
						mav.setViewName("Info");
					} else {
						mav.addObject("requestImportItem", requestImportItem);
						Set<RequestImportItemDetail> requestImportItemDetailList = new HashSet<RequestImportItemDetail>(requestImportItemDetailService.findAll(id));
						mav.addObject("requestImportItemDetailList", requestImportItemDetailList);
						mav.setViewName("RequestImportItemEdit");
					}
				} else if ((sRole.equalsIgnoreCase("184")) && (requestImportItem.getOwnerFreeZone().equalsIgnoreCase("N"))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemSave.isoftbiz", method = RequestMethod.POST)
	public String save(RequestImportItem requestImportItem, ModelMap model) {
		try {
			RequestImportItem requestImportItemCheck = requestImportItemService.findByRequestCodeCompany(requestImportItem.getRequestCode(), requestImportItem.getCompany().getCompanyID());
			if (requestImportItemCheck == null) {
				requestImportItemService.save(requestImportItem);
				return "redirect:/RequestImportItemEdit.isoftbiz?id=" + requestImportItem.getRequestID();
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/RequestImportItemSaveReceiveStatus.isoftbiz")
	public ModelAndView updateReceiveStatus(HttpServletRequest request) {
		try {
			String requestID = request.getParameter("requestid");
			String status = request.getParameter("status").trim();
			int result = 0;
			
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			
			RequestImportItem requestImportItem = requestImportItemService.findById(Long.parseLong(requestID));
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					result = requestImportItemService.updateReceiveStatus(Long.parseLong(requestID), status);
					mav.addObject("classValue", "alert-info");
					mav.addObject("headerValue","Update Success!");
					if (sRole.equalsIgnoreCase("185")) {
						mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/ReceiveImportItemByCompany.isoftbiz?requestid=" + requestID + "'><strong><u>" + requestID + "</u></strong></a> Receive Status: " + status);
					} else {
						mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/ReceiveImportItem.isoftbiz?requestid=" + requestID + "'><strong><u>" + requestID + "</u></strong></a> Receive Status: " + status);
					}
					mav.setViewName("Info");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			System.out.println("Update Receive Status: " + result);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemSaveRecordStatus.isoftbiz")
	public ModelAndView updateRecordStatus(HttpServletRequest request) {
		try {
			String requestID = request.getParameter("requestid");
			String status = request.getParameter("status").trim();
			int result = 0;
			
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			
			RequestImportItem requestImportItem = requestImportItemService.findById(Long.parseLong(requestID));
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					result = requestImportItemService.updateRecordStatus(Long.parseLong(requestID), status);
					mav.addObject("classValue", "alert-info");
					mav.addObject("headerValue","Update Success!");
					mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/RequestImportItemView/" + requestID + ".isoftbiz'><strong><u>" + requestID + "</u></strong></a> Record Status: " + status);
					mav.setViewName("Info");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			System.out.println("Update Record Status: " + result);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(RequestImportItem requestImportItem) {
		try {
			requestImportItemService.update(requestImportItem);
			return "redirect:/RequestImportItemEdit.isoftbiz?id=" + requestImportItem.getRequestID();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/RequestImportItemDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			RequestImportItem requestImportItem = requestImportItemService.findById(id);
			requestImportItemService.delete(requestImportItem);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/RequestImportItemView/{id}.isoftbiz", method = RequestMethod.GET)
	public ModelAndView show(@PathVariable(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			RequestImportItem requestImportItem = requestImportItemService.findById(id);
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					mav.addObject("requestImportItem", requestImportItem);
					Set<RequestImportItemDetail> requestImportItemDetailList = new HashSet<RequestImportItemDetail>(requestImportItemDetailService.findAll(id));
					mav.addObject("requestImportItemDetailList", requestImportItemDetailList);
					mav.setViewName("RequestImportItemView");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestImportItemDetailPrintBarcodeAll.isoftbiz", method = RequestMethod.GET)
	public void printLabelReceiveAll(HttpServletRequest request, HttpServletResponse response) throws SQLException, JRException, IOException, ServletException{
		String sSQL = "", sRptType = "", sReport = "";
		
		sRptType = "pdf";
		sReport = request.getSession().getServletContext().getRealPath("/WEB-INF/jsp/freezone/report/LabelImportItem.jasper");
		String sRequestID = request.getParameter("requestid");
		
		if (sRequestID == null) sRequestID = "";
		
		sSQL = "SELECT RequestImportItem.RequestID As RequestID "
			+ ", RequestImportItem.RequestCode As RequestCode "
			+ ", RequestImportItemDetail.InvoiceNo As InvoiceNo "
			+ ", RequestImportItem.RequestType As RequestType "
			+ ", RequestImportItem.CountryName As CountryName "
			+ ", RequestImportItem.ImportType As ImportType "
			+ ", RequestImportItem.IndustryType As IndustryType "
			+ ", ItemMaster.ItemCode As ItemCode "
			+ ", ItemMaster.ItemName As ItemName "
			+ ", RequestImportItemDetail.Quantity As Quantity "
			+ ", Unit.UnitName As UnitName "
			+ ", RequestImportItemDetail.Amount As Amount "
			+ ", RequestImportItemDetail.Weight As Weight "
			+ ", RequestImportItemDetail.Barcode As Barcode " 
			+ ", CompanyFreeZone.CompanyName As CompanyName "
			+ " FROM RequestImportItem, RequestImportItemDetail, CompanyFreeZone, ItemMaster, Unit "
			+ " WHERE RequestImportItem.RequestID = RequestImportItemDetail.RequestID "
			+ " AND RequestImportItem.CompanyID = CompanyFreeZone.CompanyID "
			+ " AND RequestImportItemDetail.ItemID = ItemMaster.ItemID "
			+ " AND RequestImportItemDetail.UnitID = Unit.UnitID "
			+ " AND RequestImportItem.RequestID = " + sRequestID
			+ " ORDER BY RequestImportItem.RequestID ASC, RequestImportItemDetail.RequestDetailID ASC ";
		
		ReportPrint.printReport(request, response, sReport, "LabelImportItem", sSQL, sRptType);
	}
	
	@RequestMapping(value = "/RequestImportItemDetailPrintBarcodeOne.isoftbiz", method = RequestMethod.GET)
	public void printLabelReceiveOne(HttpServletRequest request, HttpServletResponse response) throws SQLException, JRException, IOException, ServletException{
		String sSQL = "", sRptType = "", sReport = "";
		
		sRptType = "pdf";
		sReport = request.getSession().getServletContext().getRealPath("/WEB-INF/jsp/freezone/report/LabelImportItem.jasper");
		String sID = request.getParameter("id");
		
		if (sID == null) sID = "";
		
		sSQL = "SELECT RequestImportItem.RequestID As RequestID "
			+ ", RequestImportItem.RequestCode As RequestCode "
			+ ", RequestImportItemDetail.InvoiceNo As InvoiceNo "
			+ ", RequestImportItem.RequestType As RequestType "
			+ ", RequestImportItem.CountryName As CountryName "
			+ ", RequestImportItem.ImportType As ImportType "
			+ ", RequestImportItem.IndustryType As IndustryType "
			+ ", ItemMaster.ItemCode As ItemCode "
			+ ", ItemMaster.ItemName As ItemName "
			+ ", RequestImportItemDetail.Quantity As Quantity "
			+ ", Unit.UnitName As UnitName "
			+ ", RequestImportItemDetail.Amount As Amount "
			+ ", RequestImportItemDetail.Weight As Weight "
			+ ", RequestImportItemDetail.Barcode As Barcode " 
			+ ", CompanyFreeZone.CompanyName As CompanyName "
			+ " FROM RequestImportItem, RequestImportItemDetail, CompanyFreeZone, ItemMaster, Unit "
			+ " WHERE RequestImportItem.RequestID = RequestImportItemDetail.RequestID "
			+ " AND RequestImportItem.CompanyID = CompanyFreeZone.CompanyID "
			+ " AND RequestImportItemDetail.ItemID = ItemMaster.ItemID "
			+ " AND RequestImportItemDetail.UnitID = Unit.UnitID "
			+ " AND RequestImportItemDetail.RequestDetailID = " + sID ;
		
		ReportPrint.printReport(request, response, sReport, "LabelImportItem", sSQL, sRptType);
	}
	
	@RequestMapping(value = "/PrintLabelReceive.isoftbiz", method = RequestMethod.GET)
	public ModelAndView printLabel(HttpServletRequest request) {
		try {
			LabelReceive.printLabel(request);
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("filename", request.getParameter("labelfile"));
			mav.setViewName("LabelReceiveShow");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReceiveImportItem.isoftbiz", method = RequestMethod.GET)
	public ModelAndView receive(@RequestParam(value = "requestid") Long requestID) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			RequestImportItem requestImportItem = requestImportItemService.findById(requestID);
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					if (requestImportItem.getRecordStatus().equalsIgnoreCase("Completed")) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not receive because this record is completed.");
						mav.setViewName("Info");
					} else {
						mav.addObject("requestImportItem", requestImportItem);
						Set<RequestImportItemDetail> requestImportItemDetailList = new HashSet<RequestImportItemDetail>(requestImportItemDetailService.findAll(requestID));
						mav.addObject("requestImportItemDetailList", requestImportItemDetailList);
						Set<Company> companyList = new HashSet<Company>(companyService.findAll());
						mav.addObject("companyList", companyList);
						mav.setViewName("ReceiveImportItem");
					}
				} else if ((sRole.equalsIgnoreCase("184")) && (requestImportItem.getOwnerFreeZone().equalsIgnoreCase("N"))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReceiveImportItemSave.isoftbiz", method = RequestMethod.POST)
	public String saveReceive(HttpServletRequest request) {
		try {
			requestImportItemService.saveReceiveItem(request);
			return "redirect:/ReceiveImportItem.isoftbiz?requestid=" + request.getParameter("requestID");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/TransferImportItem.isoftbiz", method = RequestMethod.GET)
	public ModelAndView transferItem(@RequestParam(value = "requestid") Long requestID) {
		try {
			int result = 0;
			
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			
			RequestImportItem requestImportItem = requestImportItemService.findById(requestID);
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					result = requestImportItemService.transferItem(requestID);
					mav.addObject("classValue", "alert-info");
					mav.addObject("headerValue","Transfer Item Success!");
					mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/ReceiveImportItem.isoftbiz?requestid=" + requestID + "'><strong><u>" + requestID + "</u></strong></a> Transfer Receive Item Completed.");
					mav.setViewName("Info");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			System.out.println("Update Receive Status: " + result);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReceiveImportItemByCompany.isoftbiz", method = RequestMethod.GET)
	public ModelAndView receiveByCompany(@RequestParam(value = "requestid") Long requestID) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			RequestImportItem requestImportItem = requestImportItemService.findById(requestID);
			if (requestImportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestImportItem.getCompany().getCompanyID())))) {
					if (sRole.equalsIgnoreCase("185") && requestImportItem.getRecordStatus().equalsIgnoreCase("Completed")) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not receive because this record is completed.");
						mav.setViewName("Info");
					} else if (sRole.equalsIgnoreCase("185") && requestImportItem.getRecordStatus().equalsIgnoreCase("Completed By Free Zone")) {
						mav.addObject("requestImportItem", requestImportItem);
						Set<RequestImportItemDetail> requestImportItemDetailList = new HashSet<RequestImportItemDetail>(requestImportItemDetailService.findAll(requestID));
						mav.addObject("requestImportItemDetailList", requestImportItemDetailList);
						Set<Company> companyList = new HashSet<Company>(companyService.findAll());
						mav.addObject("companyList", companyList);
						mav.setViewName("ReceiveImportItemByCompany");

					} else {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Please wait receive item by free zone.");
						mav.setViewName("Info");
					}
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		Locale lc = new java.util.Locale("en","EN");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", lc);
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
