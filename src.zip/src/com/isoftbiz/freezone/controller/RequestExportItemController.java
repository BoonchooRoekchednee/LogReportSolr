package com.isoftbiz.freezone.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IRequestExportItemDetailService;
import com.isoftbiz.freezone.iservice.IRequestExportItemService;
import com.isoftbiz.freezone.model.RequestExportItem;
import com.isoftbiz.freezone.model.RequestExportItemDetail;
import com.isoftbiz.setupdata.iservice.ICompanyService;
import com.isoftbiz.setupdata.iservice.ICountryService;
import com.isoftbiz.setupdata.model.Company;
import com.isoftbiz.setupdata.model.Country;

@Controller
public class RequestExportItemController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private ICountryService countryService;
	
	@Autowired
	private IRequestExportItemService requestExportItemService;
	
	@Autowired
	private IRequestExportItemDetailService requestExportItemDetailService;
	
	@Autowired
	private ICompanyService companyService;
	
	@RequestMapping(value = "/RequestExportItem.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<RequestExportItem> requestExportItemList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.listOfCompany());
			} else {
				requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("requestExportItemList", requestExportItemList);
			mav.addObject("titleShow", "Request Export Item List From Company In Free Zone");
			mav.setViewName("RequestExportItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemByFreeZone.isoftbiz")
	public ModelAndView indexByFreeZone() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<RequestExportItem> requestExportItemList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.listOfFreeZone());
			} else {
				requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("requestExportItemList", requestExportItemList);
			mav.addObject("titleShow", "Request Export Item List Of Free Zone");
			mav.setViewName("RequestExportItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("185")) {
				mav.addObject("OwnerFreeZone", "N");
			} else {
				mav.addObject("OwnerFreeZone", "Y");
			}
			mav.setViewName("RequestExportItemNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			RequestExportItem requestExportItem = requestExportItemService.findById(id);
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184") && (requestExportItem.getOwnerFreeZone().equalsIgnoreCase("Y")))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					if (sRole.equalsIgnoreCase("185") && !(requestExportItem.getRecordStatus().equalsIgnoreCase("New"))) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not edit data.");
						mav.setViewName("Info");
					} else {
						mav.addObject("requestExportItem", requestExportItem);
						Set<RequestExportItemDetail> requestExportItemDetailList = new HashSet<RequestExportItemDetail>(requestExportItemDetailService.findAll(id));
						mav.addObject("requestExportItemDetailList", requestExportItemDetailList);
						mav.setViewName("RequestExportItemEdit");
					}
				} else if ((sRole.equalsIgnoreCase("184")) && (requestExportItem.getOwnerFreeZone().equalsIgnoreCase("N"))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemSave.isoftbiz", method = RequestMethod.POST)
	public String save(RequestExportItem requestExportItem, ModelMap model) {
		try {
			RequestExportItem requestExportItemCheck = requestExportItemService.findByRequestCodeCompany(requestExportItem.getRequestCode(), requestExportItem.getCompany().getCompanyID());
			if (requestExportItemCheck == null) {
				requestExportItemService.save(requestExportItem);
				return "redirect:/RequestExportItemEdit.isoftbiz?id=" + requestExportItem.getRequestID();
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/RequestExportItemSaveReceiveStatus.isoftbiz")
	public ModelAndView updateReceiveStatus(HttpServletRequest request) {
		try {
			String requestID = request.getParameter("requestid");
			String status = request.getParameter("status").trim();
			int result = 0;
			
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			
			RequestExportItem requestExportItem = requestExportItemService.findById(Long.parseLong(requestID));
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					result = requestExportItemService.updateReceiveStatus(Long.parseLong(requestID), status);
					mav.addObject("classValue", "alert-info");
					mav.addObject("headerValue","Update Success!");
					mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/CheckExportItem.isoftbiz?requestid=" + requestID + "'><strong><u>" + requestID + "</u></strong></a> Receive Status: " + status);
					mav.setViewName("Info");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			System.out.println("Update Receive Status: " + result);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemSaveRecordStatus.isoftbiz")
	public ModelAndView updateRecordStatus(HttpServletRequest request) {
		try {
			String requestID = request.getParameter("requestid");
			String status = request.getParameter("status").trim();
			int result = 0;
			
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			
			RequestExportItem requestExportItem = requestExportItemService.findById(Long.parseLong(requestID));
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					result = requestExportItemService.updateRecordStatus(Long.parseLong(requestID), status);
					mav.addObject("classValue", "alert-info");
					mav.addObject("headerValue","Update Success!");
					mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/RequestExportItemView/" + requestID + ".isoftbiz'><strong><u>" + requestID + "</u></strong></a> Record Status: " + status);
					mav.setViewName("Info");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			System.out.println("Update Record Status: " + result);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(RequestExportItem requestExportItem) {
		try {
			requestExportItemService.update(requestExportItem);
			return "redirect:/RequestExportItemEdit.isoftbiz?id=" + requestExportItem.getRequestID();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/RequestExportItemDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			RequestExportItem requestExportItem = requestExportItemService.findById(id);
			requestExportItemService.delete(requestExportItem);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/RequestExportItemView/{id}.isoftbiz", method = RequestMethod.GET)
	public ModelAndView show(@PathVariable(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			RequestExportItem requestExportItem = requestExportItemService.findById(id);
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					mav.addObject("requestExportItem", requestExportItem);
					Set<RequestExportItemDetail> requestExportItemDetailList = new HashSet<RequestExportItemDetail>(requestExportItemDetailService.findAll(id));
					mav.addObject("requestExportItemDetailList", requestExportItemDetailList);
					mav.setViewName("RequestExportItemView");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CheckExportItem.isoftbiz", method = RequestMethod.GET)
	public ModelAndView receive(@RequestParam(value = "requestid") Long requestID) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			RequestExportItem requestExportItem = requestExportItemService.findById(requestID);
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					if (requestExportItem.getRecordStatus().equalsIgnoreCase("Completed")) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not edit data because this record is completed.");
						mav.setViewName("Info");
					} else {
						mav.addObject("requestExportItem", requestExportItem);
						Set<RequestExportItemDetail> requestExportItemDetailList = new HashSet<RequestExportItemDetail>(requestExportItemDetailService.findAll(requestID));
						mav.addObject("requestExportItemDetailList", requestExportItemDetailList);
						Set<Company> companyList = new HashSet<Company>(companyService.findAll());
						mav.addObject("companyList", companyList);
						mav.setViewName("CheckExportItem");
					}
				} else if ((sRole.equalsIgnoreCase("184")) && (requestExportItem.getOwnerFreeZone().equalsIgnoreCase("N"))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CheckExportItemSave.isoftbiz", method = RequestMethod.POST)
	public String saveReceive(HttpServletRequest request) {
		try {
			requestExportItemService.saveReceiveItem(request);
			return "redirect:/CheckExportItem.isoftbiz?requestid=" + request.getParameter("requestID");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/TransferExportItem.isoftbiz", method = RequestMethod.GET)
	public ModelAndView transferItem(@RequestParam(value = "requestid") Long requestID) {
		try {
			int result = 0;
			
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			
			RequestExportItem requestExportItem = requestExportItemService.findById(requestID);
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					if (requestExportItem.getRecordStatus().equalsIgnoreCase("Completed")) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not edit data because this record is completed.");
						mav.setViewName("Info");
					} else {
						result = requestExportItemService.transferItem(requestID);
						mav.addObject("classValue", "alert-info");
						mav.addObject("headerValue","Transfer Item Success!");
						mav.addObject("message", "Request ID#: <a href='/WarehouseFreeZone/RequestExportItemView/" + requestID +".isoftbiz'>" + requestID + "</a> Transfer Receive Item Completed.");
						mav.setViewName("Info");
					}
				} else if ((sRole.equalsIgnoreCase("185")) && !(userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID()))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			System.out.println("Update Receive Status: " + result);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		Locale lc = new java.util.Locale("en","EN");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", lc);
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
