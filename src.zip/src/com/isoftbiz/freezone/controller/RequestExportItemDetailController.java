package com.isoftbiz.freezone.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IRequestExportItemDetailService;
import com.isoftbiz.freezone.iservice.IRequestExportItemService;
import com.isoftbiz.freezone.iservice.IWarehouseService;
import com.isoftbiz.freezone.iservice.IItemMasterService;
import com.isoftbiz.freezone.model.RequestExportItem;
import com.isoftbiz.freezone.model.RequestExportItemDetail;
import com.isoftbiz.freezone.model.Warehouse;
import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.setupdata.iservice.IUnitService;
import com.isoftbiz.setupdata.model.Unit;

@Controller
public class RequestExportItemDetailController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IRequestExportItemService requestExportItemService;
	
	@Autowired
	private IRequestExportItemDetailService requestExportItemDetailService;
	
	@Autowired
	private IItemMasterService itemMasterService;
	
	@Autowired
	private IUnitService unitService;
	
	@Autowired
	private IWarehouseService warehouseService;
	
	@RequestMapping(value = "/RequestExportItemDetailNew.isoftbiz")
	public ModelAndView create(@RequestParam(value = "requestid") Long requestID) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			Set<ItemMaster> itemMasterList;
			RequestExportItem requestExportItem = requestExportItemService.findById(requestID);
			if (requestExportItem == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					if (sRole.equalsIgnoreCase("185") && !(requestExportItem.getRecordStatus().equalsIgnoreCase("New"))) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not create new export item because operation by free zone.");
						mav.setViewName("Info");
					} else {
						if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
							itemMasterList = new HashSet<ItemMaster>(itemMasterService.findAll());
						} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
							itemMasterList = new HashSet<ItemMaster>(itemMasterService.listOfFreeZone());
						} else {
							itemMasterList = new HashSet<ItemMaster>(itemMasterService.listOfCompany(userLogin.getCompany().getCompanyID()));
						}
						Set<Unit> unitList = new HashSet<Unit>(unitService.findAll());
						mav.addObject("requestExportItem", requestExportItem);
						mav.addObject("itemMasterList", itemMasterList);
						mav.addObject("unitList", unitList); 
						mav.setViewName("RequestExportItemDetailNew");
					}
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemDetailEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			RequestExportItemDetail requestExportItemDetail = requestExportItemDetailService.findById(id);
			if (requestExportItemDetail == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				RequestExportItem requestExportItem = requestExportItemService.findById(requestExportItemDetail.getRequestExportItem().getRequestID());
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(requestExportItem.getCompany().getCompanyID())))) {
					if (sRole.equalsIgnoreCase("185") && !(requestExportItem.getRecordStatus().equalsIgnoreCase("New"))) {
						mav.addObject("classValue", "alert-warning");
						mav.addObject("headerValue","Information!");
						mav.addObject("message", "Can not edit data.");
						mav.setViewName("Info");
					} else {
						Set<ItemMaster> itemMasterList;
						if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
							itemMasterList = new HashSet<ItemMaster>(itemMasterService.findAll());
						} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
							itemMasterList = new HashSet<ItemMaster>(itemMasterService.listOfFreeZone());
						} else {
							itemMasterList = new HashSet<ItemMaster>(itemMasterService.listOfCompany(userLogin.getCompany().getCompanyID()));
						}
						Set<Unit> unitList = new HashSet<Unit>(unitService.findAll());
						mav.addObject("requestExportItem", requestExportItem);
						mav.addObject("itemMasterList", itemMasterList);
						mav.addObject("unitList", unitList); 
						mav.addObject("requestExportItemDetail", requestExportItemDetail);
						mav.setViewName("RequestExportItemDetailEdit");
					}
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/RequestExportItemDetailSave.isoftbiz", method = RequestMethod.POST)
	public String save(RequestExportItemDetail requestExportItemDetail) {
		try {
			requestExportItemDetailService.save(requestExportItemDetail);
			String sUrl;
			sUrl = "redirect:/RequestExportItemEdit.isoftbiz?id=" + requestExportItemDetail.getRequestExportItem().getRequestID();
			return sUrl;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/RequestExportItemDetailUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(RequestExportItemDetail requestExportItemDetail) {
		try {
			requestExportItemDetailService.update(requestExportItemDetail);
			String sUrl;
			sUrl = "redirect:/RequestExportItemEdit.isoftbiz?id=" + requestExportItemDetail.getRequestExportItem().getRequestID();
			return sUrl;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/RequestExportItemDetailDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			RequestExportItemDetail requestExportItemDetail = requestExportItemDetailService.findById(id);
			requestExportItemDetailService.delete(requestExportItemDetail);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/CheckExportItemDetail.isoftbiz", method = RequestMethod.GET)
	public ModelAndView checkDetail(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			RequestExportItemDetail requestExportItemDetail = requestExportItemDetailService.findById(id);
			if (requestExportItemDetail == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				RequestExportItem requestExportItem = requestExportItemService.findById(requestExportItemDetail.getRequestExportItem().getRequestID());
				Set<Warehouse> warehouseList = new HashSet<Warehouse>(warehouseService.listOfFreeZone());
				mav.addObject("requestExportItem", requestExportItem);
				mav.addObject("requestExportItemDetail", requestExportItemDetail);
				mav.addObject("warehouseList", warehouseList);
				mav.setViewName("CheckExportItemDetail");
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CheckExportItemDetailSave.isoftbiz", method = RequestMethod.POST)
	public String saveCheckItemDetail(HttpServletRequest request) {
		try {
			requestExportItemDetailService.saveReceiveItemDetail(request);
			return "redirect:/CheckExportItem.isoftbiz?requestid=" + request.getParameter("requestID");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		Locale lc = new java.util.Locale("en","EN");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", lc);
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
