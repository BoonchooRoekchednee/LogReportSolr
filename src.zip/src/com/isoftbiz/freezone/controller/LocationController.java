package com.isoftbiz.freezone.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.ILocationService;
import com.isoftbiz.freezone.iservice.IWarehouseService;
import com.isoftbiz.freezone.model.Location;
import com.isoftbiz.freezone.model.Warehouse;

@Controller
public class LocationController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private ILocationService locationService;
	
	@Autowired
	private IWarehouseService warehouseService;
	
	@RequestMapping(value = "/Location.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Location> locationList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				locationList = new HashSet<Location>(locationService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				locationList = new HashSet<Location>(locationService.listOfFreeZone());
			} else {
				locationList = new HashSet<Location>(locationService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("locationList", locationList);
			mav.setViewName("Location");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/LocationNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Warehouse> warehouseList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				warehouseList = new HashSet<Warehouse>(warehouseService.findAll());
				mav.addObject("OwnerFreeZone", "Y");
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				warehouseList = new HashSet<Warehouse>(warehouseService.listOfFreeZone());
				mav.addObject("OwnerFreeZone", "Y");
			} else {
				warehouseList = new HashSet<Warehouse>(warehouseService.listOfCompany(userLogin.getCompany().getCompanyID()));
				mav.addObject("OwnerFreeZone", "N");
			}
			mav.addObject("warehouseList", warehouseList);
			mav.setViewName("LocationNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/LocationEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Warehouse> warehouseList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			Location location = locationService.findById(id);
			if (location == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL")) 
						|| (sRole.equalsIgnoreCase("184") && (location.getOwnerFreeZone().equalsIgnoreCase("Y")))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(location.getCompany().getCompanyID())))) {
					mav.addObject("location", location);
					mav.setViewName("LocationEdit");
				} else if ((sRole.equalsIgnoreCase("184") && (location.getOwnerFreeZone().equalsIgnoreCase("N")))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185") && !(userLogin.getCompany().getCompanyID().equals(location.getCompany().getCompanyID())))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
					mav.setViewName("403");
				}
			}
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				warehouseList = new HashSet<Warehouse>(warehouseService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				warehouseList = new HashSet<Warehouse>(warehouseService.listOfFreeZone());
			} else {
				warehouseList = new HashSet<Warehouse>(warehouseService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("warehouseList", warehouseList);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/LocationSave.isoftbiz", method = RequestMethod.POST)
	public String save(Location location, ModelMap model) {
		try {
			Location locationCheck =locationService.findByLocationCodeCompany(location.getLocationCode(), location.getCompany().getCompanyID());
			if (locationCheck == null) {
				locationService.save(location);
				return "redirect:/Location.isoftbiz";
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/LocationUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Location location) {
		try {
			locationService.update(location);
			return "redirect:/Location.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/LocationDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Location location = locationService.findById(id);
			locationService.delete(location);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
