package com.isoftbiz.freezone.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IItemTypeService;
import com.isoftbiz.freezone.model.ItemType;

@Controller
public class ItemTypeController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IItemTypeService itemTypeService;
	
	@RequestMapping(value = "/ItemType.isoftbiz")
	public ModelAndView index() {
		try {
			Set<ItemType> itemTypeList = new HashSet<ItemType>(itemTypeService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("itemTypeList", itemTypeList);
			mav.setViewName("ItemType");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemTypeNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("ItemTypeNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemTypeEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			ItemType itemType = itemTypeService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("itemType", itemType);
			mav.setViewName("ItemTypeEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemTypeSave.isoftbiz", method = RequestMethod.POST)
	public String save(ItemType itemType) {
		try {
			itemTypeService.save(itemType);
			return "redirect:/ItemType.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/ItemTypeUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(ItemType itemType) {
		try {
			itemTypeService.update(itemType);
			return "redirect:/ItemType.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/ItemTypeDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			ItemType itemType = itemTypeService.findById(id);
			itemTypeService.delete(itemType);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
