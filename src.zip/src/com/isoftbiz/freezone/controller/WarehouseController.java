package com.isoftbiz.freezone.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IWarehouseService;
import com.isoftbiz.freezone.model.Warehouse;

@Controller
public class WarehouseController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IWarehouseService warehouseService;
	
	@RequestMapping(value = "/Warehouse.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<Warehouse> warehouseList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				warehouseList = new HashSet<Warehouse>(warehouseService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				warehouseList = new HashSet<Warehouse>(warehouseService.listOfFreeZone());
			} else {
				warehouseList = new HashSet<Warehouse>(warehouseService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("warehouseList", warehouseList);
			mav.setViewName("Warehouse");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/WarehouseNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("185")) {
				mav.addObject("OwnerFreeZone", "N");
			} else {
				mav.addObject("OwnerFreeZone", "Y");
			}
			mav.setViewName("WarehouseNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/WarehouseEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			Warehouse warehouse = warehouseService.findById(id);
			if (warehouse == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL"))
						|| (sRole.equalsIgnoreCase("184") && (warehouse.getOwnerFreeZone().equalsIgnoreCase("Y")))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(warehouse.getCompany().getCompanyID())))) {
					mav.addObject("warehouse", warehouse);
					mav.setViewName("WarehouseEdit");
				} else if ((sRole.equalsIgnoreCase("184") && (warehouse.getOwnerFreeZone().equalsIgnoreCase("N")))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185") && !(userLogin.getCompany().getCompanyID().equals(warehouse.getCompany().getCompanyID())))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/WarehouseSave.isoftbiz", method = RequestMethod.POST)
	public String save(Warehouse warehouse, ModelMap model) {
		try {
			Warehouse warehouseCheck = warehouseService.findByWarehouseCodeCompany(warehouse.getWarehouseCode(), warehouse.getCompany().getCompanyID());
			if (warehouseCheck == null) {
				warehouseService.save(warehouse);
				return "redirect:/Warehouse.isoftbiz";
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/WarehouseUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(Warehouse warehouse) {
		try {
			warehouseService.update(warehouse);
			return "redirect:/Warehouse.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/WarehouseDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			Warehouse warehouse = warehouseService.findById(id);
			warehouseService.delete(warehouse);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
