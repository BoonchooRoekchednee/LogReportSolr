package com.isoftbiz.freezone.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IItemMasterService;
import com.isoftbiz.freezone.iservice.IItemTypeService;
import com.isoftbiz.freezone.iservice.IItemGroupService;
import com.isoftbiz.freezone.model.ItemGroup;
import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.freezone.model.ItemType;
import com.isoftbiz.setupdata.iservice.IUnitService;
import com.isoftbiz.setupdata.model.Unit;

@Controller
public class ItemMasterController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IItemMasterService itemMasterService;
	
	@Autowired
	private IItemTypeService itemTypeService;
	
	@Autowired
	private IItemGroupService itemGroupService;
	
	@Autowired
	private IUnitService unitService;
	
	@RequestMapping(value = "/ItemMaster.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<ItemMaster> itemMasterList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				itemMasterList = new HashSet<ItemMaster>(itemMasterService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				itemMasterList = new HashSet<ItemMaster>(itemMasterService.listOfFreeZone());
			} else {
				itemMasterList = new HashSet<ItemMaster>(itemMasterService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("itemMasterList", itemMasterList);
			mav.setViewName("ItemMaster");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemMasterNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<ItemGroup> itemGroupList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<ItemType> itemTypeList = new HashSet<ItemType>(itemTypeService.findAll());
			Set<Unit> unitList = new HashSet<Unit>(unitService.findAll());
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.findAll());
				mav.addObject("OwnerFreeZone", "Y");
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.listOfFreeZone());
				mav.addObject("OwnerFreeZone", "Y");
			} else {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.listOfCompany(userLogin.getCompany().getCompanyID()));
				mav.addObject("OwnerFreeZone", "N");
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("itemTypeList", itemTypeList);
			mav.addObject("unitList", unitList);
			mav.addObject("itemGroupList", itemGroupList);
			mav.setViewName("ItemMasterNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemMasterEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Set<ItemGroup> itemGroupList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<ItemType> itemTypeList = new HashSet<ItemType>(itemTypeService.findAll());
			Set<Unit> unitList = new HashSet<Unit>(unitService.findAll());
			mav.addObject("userLogin", userLogin);
			ItemMaster itemMaster = itemMasterService.findById(id);
			if (itemMaster == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL")) 
						|| (sRole.equalsIgnoreCase("184") && (itemMaster.getOwnerFreeZone().equalsIgnoreCase("Y")))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(itemMaster.getCompany().getCompanyID())))) {
					mav.addObject("itemMaster", itemMaster);
					mav.setViewName("ItemMasterEdit");
				} else if ((sRole.equalsIgnoreCase("184") && (itemMaster.getOwnerFreeZone().equalsIgnoreCase("N")))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185") && !(userLogin.getCompany().getCompanyID().equals(itemMaster.getCompany().getCompanyID())))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
					mav.setViewName("403");
				}
			}
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.listOfFreeZone());
			} else {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("itemTypeList", itemTypeList);
			mav.addObject("unitList", unitList);
			mav.addObject("itemGroupList", itemGroupList);
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemMasterSave.isoftbiz", method = RequestMethod.POST)
	public String save(ItemMaster itemMaster, ModelMap model) {
		try {
			ItemMaster itemMasterCheck = itemMasterService.findByItemCodeCompany(itemMaster.getItemCode(), itemMaster.getCompany().getCompanyID());
			if (itemMasterCheck == null) {
				itemMasterService.save(itemMaster);
				return "redirect:/ItemMaster.isoftbiz";
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/ItemMasterUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(ItemMaster itemMaster) {
		try {
			itemMasterService.update(itemMaster);
			return "redirect:/ItemMaster.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/ItemMasterDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			ItemMaster itemMaster = itemMasterService.findById(id);
			itemMasterService.delete(itemMaster);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
