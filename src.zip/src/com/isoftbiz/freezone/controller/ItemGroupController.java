package com.isoftbiz.freezone.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IItemGroupService;
import com.isoftbiz.freezone.model.ItemGroup;

@Controller
public class ItemGroupController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IItemGroupService itemGroupService;
	
	@RequestMapping(value = "/ItemGroup.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<ItemGroup> itemGroupList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.listOfFreeZone());
			} else {
				itemGroupList = new HashSet<ItemGroup>(itemGroupService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("itemGroupList", itemGroupList);
			mav.setViewName("ItemGroup");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemGroupNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("185")) {
				mav.addObject("OwnerFreeZone", "N");
			} else {
				mav.addObject("OwnerFreeZone", "Y");
			}
			mav.setViewName("ItemGroupNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemGroupEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			ItemGroup itemGroup = itemGroupService.findById(id);
			if (itemGroup == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL")) 
						|| (sRole.equalsIgnoreCase("184") && (itemGroup.getOwnerFreeZone().equalsIgnoreCase("Y")))
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(itemGroup.getCompany().getCompanyID())))) {
					mav.addObject("itemGroup", itemGroup);
					mav.setViewName("ItemGroupEdit");
				} else if ((sRole.equalsIgnoreCase("184") && (itemGroup.getOwnerFreeZone().equalsIgnoreCase("N")))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else if ((sRole.equalsIgnoreCase("185") && !(userLogin.getCompany().getCompanyID().equals(itemGroup.getCompany().getCompanyID())))) {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this data.");
					mav.setViewName("403");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ItemGroupSave.isoftbiz", method = RequestMethod.POST)
	public String save(ItemGroup itemGroup, ModelMap model) {
		try {
			ItemGroup itemGroupCheck = itemGroupService.findByItemGroupCodeCompany(itemGroup.getItemGroupCode(), itemGroup.getCompany().getCompanyID());
			if (itemGroupCheck == null) {
				itemGroupService.save(itemGroup);
				return "redirect:/ItemGroup.isoftbiz";
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/ItemGroupUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(ItemGroup itemGroup) {
		try {
			itemGroupService.update(itemGroup);
			return "redirect:/ItemGroup.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/ItemGroupDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			ItemGroup itemGroup = itemGroupService.findById(id);
			itemGroupService.delete(itemGroup);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
