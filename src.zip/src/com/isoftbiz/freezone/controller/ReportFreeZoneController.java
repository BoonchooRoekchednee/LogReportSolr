package com.isoftbiz.freezone.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.freezone.iservice.IRequestExportItemService;
import com.isoftbiz.freezone.iservice.IRequestImportItemService;
import com.isoftbiz.freezone.model.RequestExportItem;
import com.isoftbiz.freezone.model.RequestImportItem;
import com.isoftbiz.main.util.ReportPrint;
import com.isoftbiz.setupdata.iservice.ICountryService;
import com.isoftbiz.setupdata.model.Country;

import net.sf.jasperreports.engine.JRException;

@Controller
public class ReportFreeZoneController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private ICountryService countryService;
	
	@Autowired
	private IRequestImportItemService requestImportItemService;
	
	@Autowired
	private IRequestExportItemService requestExportItemService;
	
	@RequestMapping(value = "/ReportImportItem.isoftbiz")
	public ModelAndView reportImportItem() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("ReportImportItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReportImportItemSearch.isoftbiz")
	public ModelAndView reportImportItemSearch(HttpServletRequest request) {
		try {
			String sStartDate = request.getParameter("receiveDateFrom");
			String sEndDate = request.getParameter("receiveDateTo");
			String sRequestType = request.getParameter("requestType");
			String sCountryName = request.getParameter("countryName");
			String sImportType = request.getParameter("importType");
			String sIndustryType = request.getParameter("industryType");
			String sParameters = "";
			
			if (sStartDate == null) sStartDate = "";
			sParameters += "&receiveDateFrom=" + sStartDate;
			if (sEndDate == null) sEndDate = "";
			sParameters += "&receiveDateTo=" + sEndDate;
			if (sRequestType == null) sRequestType = "";
			sParameters += "&requestType=" + sRequestType;
			if (sCountryName == null) sCountryName = "";
			sParameters += "&countryName=" + sCountryName;
			if (sImportType == null) sImportType = "";
			sParameters += "&importType=" + sImportType;
			if (sIndustryType == null) sIndustryType = "";
			sParameters += "&industryType=" + sIndustryType;

			ModelAndView mav = new ModelAndView();
			Set<RequestImportItem> requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.searchReport(request));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("receiveDateFrom", sStartDate);
			mav.addObject("receiveDateTo", sEndDate);
			mav.addObject("requestType", sRequestType);
			mav.addObject("countryName", sCountryName);
			mav.addObject("importType", sImportType);
			mav.addObject("industryType", sIndustryType);
			mav.addObject("parameters", sParameters);
			mav.addObject("requestImportItemList", requestImportItemList);
			mav.setViewName("ReportImportItemPrint");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PrintReportImportItem.isoftbiz", method = RequestMethod.GET)
	public void printReportImportItem(HttpServletRequest request, HttpServletResponse response) throws SQLException, JRException, IOException, ServletException{
		String sSQL = "", sRptType = "", sReport = "";
		
		sRptType = request.getParameter("rpttype");
		sReport = request.getSession().getServletContext().getRealPath("/WEB-INF/jsp/freezone/report/ReportImportItem.jasper");
		String sStartDate = request.getParameter("receiveDateFrom");
		String sEndDate = request.getParameter("receiveDateTo");
		String sRequestType = request.getParameter("requestType");
		String sCountryName = request.getParameter("countryName");
		String sImportType = request.getParameter("importType");
		String sIndustryType = request.getParameter("industryType");
		
		if (sStartDate == null) sStartDate = "";
		if (sEndDate == null) sEndDate = "";
		if (sRequestType == null) sRequestType = "";
		if (sCountryName == null) sCountryName = "";
		if (sImportType == null) sImportType = "";
		if (sIndustryType == null) sIndustryType = "";
		
		sSQL = "SELECT RequestImportItem.RequestCode As RequestCode "
				+ ", RequestImportItem.RequestDate As RequestDate "
				+ ", RequestImportItem.Barcode As Barcode "
				+ ", RequestImportItem.ReceiveNo As ReceiveNo "
				+ ", RequestImportItem.ReceiveDate As ReceiveDate "
				+ ", RequestImportItem.ShippingNo As ShippingNo "
				+ ", RequestImportItem.ShippingDate As ShippingDate "
				+ ", Company.CompanyName As ShippingBy "
				+ ", RequestImportItemDetail.InvoiceNo As InvoiceNo "
				+ ", RequestImportItem.RequestType As RequestType "
				+ ", RequestImportItem.CountryName As CountryName "
				+ ", CompanyFreeZone.CompanyName As CompanyName "
				+ ", RequestImportItem.TaxImport As TaxImport "
				+ ", RequestImportItem.VatAmount As VatAmount "
				+ ", RequestImportItem.TaxExcise As TaxExcise "
				+ ", ItemMaster.ItemCode As ItemCode "
				+ ", ItemMaster.ItemName As ItemName "
				+ ", RequestImportItemDetail.QuantityReceiveFreeZone As Quantity "
				+ ", Unit.UnitName As UnitName "
				+ ", RequestImportItemDetail.Amount As Amount "
				+ ", RequestImportItemDetail.Weight As Weight "
				+ ", RequestImportItem.ImportType As ImportType "
				+ ", RequestImportItem.IndustryType As IndustryType "
				+ " FROM {oj requestimportitem LEFT OUTER JOIN company ON requestimportitem.ShippingID = company.CompanyID} "
				+ " , RequestImportItemDetail, CompanyFreeZone, ItemMaster, Unit "
				+ " WHERE RequestImportItem.RequestID = RequestImportItemDetail.RequestID "
				+ " AND RequestImportItem.CompanyID = CompanyFreeZone.CompanyID "
				+ " AND RequestImportItemDetail.ItemID = ItemMaster.ItemID "
				+ " AND RequestImportItemDetail.UnitID = Unit.UnitID ";
		if (!sStartDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.ReceiveDate >= '" + sStartDate + "' ";
		}
		if (!sEndDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.ReceiveDate <= '" + sEndDate + "' ";
		}
		if (!sRequestType.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.RequestType = '" + sRequestType + "' ";
		}
		if (!sCountryName.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.CountryName = '" + sCountryName + "' ";
		}
		if (!sImportType.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.ImportType = '" + sImportType + "' ";
		}
		if (!sIndustryType.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.IndustryType = '" + sIndustryType + "' ";
		}
		sSQL	+= " ORDER BY RequestImportItem.RequestID ASC, RequestImportItemDetail.RequestDetailID ASC ";
		ReportPrint.printReport(request, response, sReport, "ReportImportItem", sSQL, sRptType);
	}
	
	@RequestMapping(value = "/ReportExportItem.isoftbiz")
	public ModelAndView reportExportItem() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("ReportExportItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReportExportItemSearch.isoftbiz")
	public ModelAndView reportExportItemSearch(HttpServletRequest request) {
		try {
			String sStartDate = request.getParameter("receiveDateFrom");
			String sEndDate = request.getParameter("receiveDateTo");
			String sRequestType = request.getParameter("requestType");
			String sCountryName = request.getParameter("countryName");
			String sExportType = request.getParameter("exportType");
			String sIndustryType = request.getParameter("industryType");
			String sParameters = "";
			
			if (sStartDate == null) sStartDate = "";
			sParameters += "&receiveDateFrom=" + sStartDate;
			if (sEndDate == null) sEndDate = "";
			sParameters += "&receiveDateTo=" + sEndDate;
			if (sRequestType == null) sRequestType = "";
			sParameters += "&requestType=" + sRequestType;
			if (sCountryName == null) sCountryName = "";
			sParameters += "&countryName=" + sCountryName;
			if (sExportType == null) sExportType = "";
			sParameters += "&exportType=" + sExportType;
			if (sIndustryType == null) sIndustryType = "";
			sParameters += "&industryType=" + sIndustryType;

			ModelAndView mav = new ModelAndView();
			Set<RequestExportItem> requestExportItemList = new HashSet<RequestExportItem>(requestExportItemService.searchReport(request));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("receiveDateFrom", sStartDate);
			mav.addObject("receiveDateTo", sEndDate);
			mav.addObject("requestType", sRequestType);
			mav.addObject("countryName", sCountryName);
			mav.addObject("exportType", sExportType);
			mav.addObject("industryType", sIndustryType);
			mav.addObject("parameters", sParameters);
			mav.addObject("requestExportItemList", requestExportItemList);
			mav.setViewName("ReportExportItemPrint");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PrintReportExportItem.isoftbiz", method = RequestMethod.GET)
	public void printReportExportItem(HttpServletRequest request, HttpServletResponse response) throws SQLException, JRException, IOException, ServletException{
		String sSQL = "", sRptType = "", sReport = "";
		
		sRptType = request.getParameter("rpttype");
		sReport = request.getSession().getServletContext().getRealPath("/WEB-INF/jsp/freezone/report/ReportExportItem.jasper");
		String sStartDate = request.getParameter("receiveDateFrom");
		String sEndDate = request.getParameter("receiveDateTo");
		String sRequestType = request.getParameter("requestType");
		String sCountryName = request.getParameter("countryName");
		String sExportType = request.getParameter("exportType");
		String sIndustryType = request.getParameter("industryType");
		
		if (sStartDate == null) sStartDate = "";
		if (sEndDate == null) sEndDate = "";
		if (sRequestType == null) sRequestType = "";
		if (sCountryName == null) sCountryName = "";
		if (sExportType == null) sExportType = "";
		if (sIndustryType == null) sIndustryType = "";
		
		sSQL = "SELECT RequestExportItem.RequestCode As RequestCode "
				+ ", RequestExportItem.RequestDate As RequestDate "
				+ ", RequestExportItem.Barcode As Barcode "
				+ ", RequestExportItem.ReceiveNo As ReceiveNo "
				+ ", RequestExportItem.ReceiveDate As ReceiveDate "
				+ ", RequestExportItem.ShippingNo As ShippingNo "
				+ ", RequestExportItem.ShippingDate As ShippingDate "
				+ ", Company.CompanyName As ShippingBy "
				+ ", RequestExportItemDetail.InvoiceNo As InvoiceNo "
				+ ", RequestExportItem.RequestType As RequestType "
				+ ", RequestExportItem.CountryName As CountryName "
				+ ", CompanyFreeZone.CompanyName As CompanyName "
				+ ", RequestExportItem.TaxExport As TaxExport "
				+ ", RequestExportItem.VatAmount As VatAmount "
				+ ", RequestExportItem.TaxExcise As TaxExcise "
				+ ", ItemMaster.ItemCode As ItemCode "
				+ ", ItemMaster.ItemName As ItemName "
				+ ", RequestExportItemDetail.QuantityReceiveFreeZone As Quantity "
				+ ", Unit.UnitName As UnitName "
				+ ", RequestExportItemDetail.Amount As Amount "
				+ ", RequestExportItemDetail.Weight As Weight "
				+ ", RequestExportItem.ExportType As ExportType "
				+ ", RequestExportItem.IndustryType As IndustryType "
				+ " FROM {oj requestexportitem LEFT OUTER JOIN company ON requestexportitem.ShippingID = company.CompanyID} "
				+ " , RequestExportItemDetail, CompanyFreeZone, ItemMaster, Unit "
				+ " WHERE RequestExportItem.RequestID = RequestExportItemDetail.RequestID "
				+ " AND RequestExportItem.CompanyID = CompanyFreeZone.CompanyID "
				+ " AND RequestExportItemDetail.ItemID = ItemMaster.ItemID "
				+ " AND RequestExportItemDetail.UnitID = Unit.UnitID ";
		if (!sStartDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestExportItem.ReceiveDate >= '" + sStartDate + "' ";
		}
		if (!sEndDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestExportItem.ReceiveDate <= '" + sEndDate + "' ";
		}
		if (!sRequestType.equalsIgnoreCase("")) {
			sSQL += " AND RequestExportItem.RequestType = '" + sRequestType + "' ";
		}
		if (!sCountryName.equalsIgnoreCase("")) {
			sSQL += " AND RequestExportItem.CountryName = '" + sCountryName + "' ";
		}
		if (!sExportType.equalsIgnoreCase("")) {
			sSQL += " AND RequestExportItem.ExportType = '" + sExportType + "' ";
		}
		if (!sIndustryType.equalsIgnoreCase("")) {
			sSQL += " AND RequestExportItem.IndustryType = '" + sIndustryType + "' ";
		}
		sSQL	+= " ORDER BY RequestExportItem.RequestID ASC, RequestExportItemDetail.RequestDetailID ASC ";
		ReportPrint.printReport(request, response, sReport, "ReportExportItem", sSQL, sRptType);
	}
	
	@RequestMapping(value = "/ReportTransferItem.isoftbiz")
	public ModelAndView reportTransferItem() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("ReportTransferItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReportTransferItemSearch.isoftbiz")
	public ModelAndView reportTransferItemSearch(HttpServletRequest request) {
		try {
			String sStartDate = request.getParameter("transferDateFrom");
			String sEndDate = request.getParameter("transferDateTo");
			
			if (sStartDate == null) {
				sStartDate = "";
			}
			if (sEndDate == null) {
				sEndDate = "";
			}

			ModelAndView mav = new ModelAndView();
			Set<RequestImportItem> requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.searchByTransferDate(sStartDate, sEndDate));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("startdate", sStartDate);
			mav.addObject("enddate", sEndDate);
			mav.addObject("requestImportItemList", requestImportItemList);
			mav.setViewName("ReportTransferItemPrint");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PrintReportTransferItem.isoftbiz", method = RequestMethod.GET)
	public void printReportTransferItem(HttpServletRequest request, HttpServletResponse response) throws SQLException, JRException, IOException, ServletException{
		String sSQL = "", sRptType = "", sReport = "";
		
		sRptType = request.getParameter("rpttype");
		sReport = request.getSession().getServletContext().getRealPath("/WEB-INF/jsp/freezone/report/ReportTransferItem.jasper");
		String sStartDate = request.getParameter("startdate");
		String sEndDate = request.getParameter("enddate");
		
		if (sStartDate == null) {
			sStartDate = "";
		}
		
		if (sEndDate == null) {
			sEndDate = "";
		}
		
		sSQL = "SELECT RequestImportItem.RequestCode As RequestCode "
				+ ", RequestImportItem.RequestDate As RequestDate "
				+ ", RequestImportItem.ReceiveDate As ReceiveDate "
				+ ", RequestImportItem.ShippingNo As ShippingNo "
				+ ", RequestImportItemDetail.InvoiceNo As InvoiceNo "
				+ ", RequestImportItem.RequestType As RequestType "
				+ ", RequestImportItem.CountryName As CountryName "
				+ ", CompanyFreeZone.CompanyName As CompanyName "
				+ ", RequestImportItem.TaxImport As TaxImport "
				+ ", RequestImportItem.VatAmount As VatAmount "
				+ ", RequestImportItem.TaxExcise As TaxExcise "
				+ ", ItemMaster.ItemCode As ItemCode "
				+ ", ItemMaster.ItemName As ItemName "
				+ ", RequestImportItemDetail.QuantityReceiveFreeZone As Quantity "
				+ ", Unit.UnitName As UnitName "
				+ ", RequestImportItemDetail.Amount As Amount "
				+ ", RequestImportItemDetail.TotalAmount As TotalAmount "
				+ ", RequestImportItemDetail.Weight As Weight "
				+ ", RequestImportItemDetail.TotalWeight As TotalWeight "
				+ ", RequestImportItem.MoveItemDate As MoveItemDate "
				+ " FROM RequestImportItem, RequestImportItemDetail, CompanyFreeZone, ItemMaster, Unit "
				+ " WHERE RequestImportItem.RequestID = RequestImportItemDetail.RequestID "
				+ " AND RequestImportItem.CompanyID = CompanyFreeZone.CompanyID "
				+ " AND RequestImportItemDetail.ItemID = ItemMaster.ItemID "
				+ " AND RequestImportItemDetail.UnitID = Unit.UnitID "
				+ " AND RequestImportItem.MoveStatus = 'Y' ";
		if (!sStartDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.MoveItemDate >= '" + sStartDate + "' ";
		}
		if (!sEndDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.MoveItemDate <= '" + sEndDate + "' ";
		}
		sSQL	+= " ORDER BY RequestImportItem.RequestID ASC, RequestImportItemDetail.RequestDetailID ASC ";
		
		ReportPrint.printReport(request, response, sReport, "ReportTransferItem", sSQL, sRptType);
	}
	
	@RequestMapping(value = "/ReportMovementItem.isoftbiz")
	public ModelAndView reportMovementItem() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			Set<Country> countryList = new HashSet<Country>(countryService.findAll());
			mav.addObject("userLogin", userLogin);
			mav.addObject("countryList", countryList);
			mav.setViewName("ReportMovementItem");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReportMovementItemSearch.isoftbiz")
	public ModelAndView reportMovementItemSearch(HttpServletRequest request) {
		try {
			String sStartDate = request.getParameter("receiveDateFrom");
			String sEndDate = request.getParameter("receiveDateTo");
			String sRequestType = request.getParameter("requestType");
			String sCountryName = request.getParameter("countryName");
			String sImportType = request.getParameter("importType");
			String sIndustryType = request.getParameter("industryType");
			String sParameters = "";
			
			if (sStartDate == null) sStartDate = "";
			sParameters += "&receiveDateFrom=" + sStartDate;
			if (sEndDate == null) sEndDate = "";
			sParameters += "&receiveDateTo=" + sEndDate;
			if (sRequestType == null) sRequestType = "";
			sParameters += "&requestType=" + sRequestType;
			if (sCountryName == null) sCountryName = "";
			sParameters += "&countryName=" + sCountryName;
			if (sImportType == null) sImportType = "";
			sParameters += "&importType=" + sImportType;
			if (sIndustryType == null) sIndustryType = "";
			sParameters += "&industryType=" + sIndustryType;

			ModelAndView mav = new ModelAndView();
			Set<RequestImportItem> requestImportItemList = new HashSet<RequestImportItem>(requestImportItemService.searchReport(request));
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("receiveDateFrom", sStartDate);
			mav.addObject("receiveDateTo", sEndDate);
			mav.addObject("requestType", sRequestType);
			mav.addObject("countryName", sCountryName);
			mav.addObject("importType", sImportType);
			mav.addObject("industryType", sIndustryType);
			mav.addObject("parameters", sParameters);
			mav.addObject("requestMovementItemList", requestImportItemList);
			mav.setViewName("ReportMovementItemPrint");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/PrintReportMovementItem.isoftbiz", method = RequestMethod.GET)
	public void printReportMovementItem(HttpServletRequest request, HttpServletResponse response) throws SQLException, JRException, IOException, ServletException{
		String sSQL = "", sRptType = "", sReport = "";
		
		sRptType = request.getParameter("rpttype");
		sReport = request.getSession().getServletContext().getRealPath("/WEB-INF/jsp/freezone/report/ReportMovementItem.jasper");
		String sStartDate = request.getParameter("receiveDateFrom");
		String sEndDate = request.getParameter("receiveDateTo");
		String sRequestType = request.getParameter("requestType");
		String sCountryName = request.getParameter("countryName");
		String sImportType = request.getParameter("importType");
		String sIndustryType = request.getParameter("industryType");
		
		if (sStartDate == null) sStartDate = "";
		if (sEndDate == null) sEndDate = "";
		if (sRequestType == null) sRequestType = "";
		if (sCountryName == null) sCountryName = "";
		if (sImportType == null) sImportType = "";
		if (sIndustryType == null) sIndustryType = "";
		
		sSQL = "SELECT RequestImportItem.RequestCode As RequestCode "
				+ ", RequestImportItem.RequestDate As RequestDate "
				+ ", RequestImportItem.Barcode As Barcode "
				+ ", RequestImportItem.ReceiveNo As ReceiveNo "
				+ ", RequestImportItem.ReceiveDate As ReceiveDate "
				+ ", RequestImportItem.ShippingNo As ShippingNo "
				+ ", RequestImportItem.ShippingDate As ShippingDate "
				+ ", Company.CompanyName As ShippingBy "
				+ ", RequestImportItemDetail.InvoiceNo As InvoiceNo "
				+ ", RequestImportItem.RequestType As RequestType "
				+ ", RequestImportItem.CountryName As CountryName "
				+ ", CompanyFreeZone.CompanyName As CompanyName "
				+ ", RequestImportItem.TaxImport As TaxImport "
				+ ", RequestImportItem.VatAmount As VatAmount "
				+ ", RequestImportItem.TaxExcise As TaxExcise "
				+ ", ItemMaster.ItemCode As ItemCode "
				+ ", ItemMaster.ItemName As ItemName "
				+ ", RequestImportItemDetail.QuantityReceiveFreeZone As Quantity "
				+ ", RequestImportItemDetail.QuantityDamagedFreeZone As QuantityDamaged "
				+ ", Unit.UnitName As UnitName "
				+ ", RequestImportItemDetail.Amount As Amount "
				+ ", RequestImportItemDetail.Weight As Weight "
				+ ", RequestImportItem.ImportType As ImportType "
				+ ", RequestImportItem.IndustryType As IndustryType "
				+ ", RequestImportItem.MoveItemDate As MoveItemDate "
				+ ", RequestImportItemDetail.QuantityReceiveCompany As QuantityReceiveCompany "
				+ ", RequestImportItemDetail.QuantityDamagedCompany As QuantityDamagedCompany "
				+ " FROM {oj requestimportitem LEFT OUTER JOIN company ON requestimportitem.ShippingID = company.CompanyID} "
				+ " , RequestImportItemDetail, CompanyFreeZone, ItemMaster, Unit "
				+ " WHERE RequestImportItem.RequestID = RequestImportItemDetail.RequestID "
				+ " AND RequestImportItem.CompanyID = CompanyFreeZone.CompanyID "
				+ " AND RequestImportItemDetail.ItemID = ItemMaster.ItemID "
				+ " AND RequestImportItemDetail.UnitID = Unit.UnitID ";
		if (!sStartDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.ReceiveDate >= '" + sStartDate + "' ";
		}
		if (!sEndDate.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.ReceiveDate <= '" + sEndDate + "' ";
		}
		if (!sRequestType.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.RequestType = '" + sRequestType + "' ";
		}
		if (!sCountryName.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.CountryName = '" + sCountryName + "' ";
		}
		if (!sImportType.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.ImportType = '" + sImportType + "' ";
		}
		if (!sIndustryType.equalsIgnoreCase("")) {
			sSQL += " AND RequestImportItem.IndustryType = '" + sIndustryType + "' ";
		}
		sSQL	+= " ORDER BY RequestImportItem.RequestID ASC, RequestImportItemDetail.RequestDetailID ASC ";
		
		ReportPrint.printReport(request, response, sReport, "ReportMovementItem", sSQL, sRptType);
	}
}
