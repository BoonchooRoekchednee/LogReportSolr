package com.isoftbiz.freezone.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.isoftbiz.freezone.model.RequestExportItem;
import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "RequestExportItemDetail")
public class RequestExportItemDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RequestDetailID")
	private Long requestDetailID;
	
	@ManyToOne
	@JoinColumn(name = "RequestID", nullable = false)
	private RequestExportItem requestExportItem;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "LotNo", length = 32)
	private String lotNo;
	
	@Column(name = "MfgDate")
	@Type(type = "date")
	private Date mfgDate;
	
	@Column(name = "ExpDate")
	@Type(type = "date")
	private Date expDate;
	
	@Column(name = "TermOfUse")
	private Integer termOfUse;
	
	@Column(name = "RefNo", length = 32)
	private String refNo;
	
	@Column(name = "Quantity", columnDefinition = "Decimal(12,2)")
	private Double quantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;
	
	@Column(name = "Weight", columnDefinition = "Decimal(12,2)")
	private Double weight;
	
	@Column(name = "TotalWeight", columnDefinition = "Decimal(16,2)")
	private Double totalWeight;
	
	@Column(name = "GrossWeight", columnDefinition = "Decimal(16,2)")
	private Double grossWeight;
	
	@Column(name = "NetWeight", columnDefinition = "Decimal(16,2)")
	private Double netWeight;
	
	@Column(name = "AmountForeign", columnDefinition = "Decimal(12,2)")
	private Double amountForeign;
	
	@Column(name = "TotalAmountForeign", columnDefinition = "Decimal(16,2)")
	private Double totalAmountForeign;
	
	@Column(name = "CurrencyForeign", length = 32, nullable = true)
	private String currencyForeign;
	
	@Column(name = "CurrecyRate", columnDefinition = "Decimal(12,4)")
	private Double currencyRate;
	
	@Column(name = "Amount", columnDefinition = "Decimal(12,2)")
	private Double amount;
	
	@Column(name = "TotalAmount", columnDefinition = "Decimal(16,2)")
	private Double totalAmount;
	
	@Column(name = "InvoiceNo", length = 64)
	private String invoiceNo;
	
	@Column(name = "RefCode", length = 64)
	private String refCode;
	
	@Column(name = "ReceiveStatus", length = 32)
	private String receiveStatus;
	
	@Column(name = "Barcode", length = 32, nullable = true)
	private String barcode;
	
	@Column(name = "Barcode2", length = 32, nullable = true)
	private String barcode2;
	
	@Column(name = "Remark", length = 255)
	private String remark;
	
	@Column(name = "TaxExportRate", columnDefinition = "Decimal(4,2)")
	private Double taxExportRate;
	
	@Column(name = "TaxExport", columnDefinition = "Decimal(12,2)")
	private Double taxExport;
	
	@Column(name = "TaxExcise", columnDefinition = "Decimal(12,2)")
	private Double taxExcise;
	
	@Column(name = "TaxInterior", columnDefinition = "Decimal(12,2)")
	private Double taxInterior;
	
	@Column(name = "VatAmount", columnDefinition = "Decimal(12,2)")
	private Double VatAmount;
	
	@Column(name = "QuantityReceiveFreeZone", columnDefinition = "Decimal(12,2)")
	private Double quantityReceiveFreeZone;
	
	@Column(name = "QuantityDamagedFreeZone", columnDefinition = "Decimal(12,2)")
	private Double quantityDamagedFreeZone;
	
	@Column(name = "WeightReceiveFreeZone", columnDefinition = "Decimal(12,2)")
	private Double weightReceiveFreeZone;
	
	@Column(name = "WeightDamagedFreeZone", columnDefinition = "Decimal(12,2)")
	private Double WeightDamagedFreeZone;
	
	@Column(name = "DamagedRemarkFreeZone", length = 255)
	private String damagedRemarkFreeZone;
	
	@ManyToOne
	@JoinColumn(name = "WarehouseFreeZoneID", nullable = true)
	private Warehouse warehouseFreeZone;
	
	@Column(name = "QuantityReceiveCompany", columnDefinition = "Decimal(12,2)")
	private Double quantityReceiveCompany;
	
	@Column(name = "QuantityDamagedCompany", columnDefinition = "Decimal(12,2)")
	private Double quantityDamagedCompany;
	
	@Column(name = "WeightReceiveCompany", columnDefinition = "Decimal(12,2)")
	private Double weightReceiveCompany;
	
	@Column(name = "WeightDamagedCompany", columnDefinition = "Decimal(12,2)")
	private Double WeightDamagedCompany;
	
	@Column(name = "DamagedRemarkCompany", length = 255)
	private String damagedRemarkCompany;
	
	@ManyToOne
	@JoinColumn(name = "WarehouseCompanyID", nullable = true)
	private Warehouse warehouseCompany;

	public Long getRequestDetailID() {
		return requestDetailID;
	}

	public void setRequestDetailID(Long requestDetailID) {
		this.requestDetailID = requestDetailID;
	}

	public RequestExportItem getRequestExportItem() {
		return requestExportItem;
	}

	public void setRequestExportItem(RequestExportItem requestExportItem) {
		this.requestExportItem = requestExportItem;
	}

	public ItemMaster getItemMaster() {
		return itemMaster;
	}

	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}

	public String getLotNo() {
		return lotNo;
	}

	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}

	public Date getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public Integer getTermOfUse() {
		return termOfUse;
	}

	public void setTermOfUse(Integer termOfUse) {
		this.termOfUse = termOfUse;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(Double totalWeight) {
		this.totalWeight = totalWeight;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}

	public Double getAmountForeign() {
		return amountForeign;
	}

	public void setAmountForeign(Double amountForeign) {
		this.amountForeign = amountForeign;
	}

	public Double getTotalAmountForeign() {
		return totalAmountForeign;
	}

	public void setTotalAmountForeign(Double totalAmountForeign) {
		this.totalAmountForeign = totalAmountForeign;
	}

	public String getCurrencyForeign() {
		return currencyForeign;
	}

	public void setCurrencyForeign(String currencyForeign) {
		this.currencyForeign = currencyForeign;
	}

	public Double getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(Double currencyRate) {
		this.currencyRate = currencyRate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getRefCode() {
		return refCode;
	}

	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}

	public String getReceiveStatus() {
		return receiveStatus;
	}

	public void setReceiveStatus(String receiveStatus) {
		this.receiveStatus = receiveStatus;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getBarcode2() {
		return barcode2;
	}

	public void setBarcode2(String barcode2) {
		this.barcode2 = barcode2;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Double getTaxExportRate() {
		return taxExportRate;
	}

	public void setTaxExportRate(Double taxExportRate) {
		this.taxExportRate = taxExportRate;
	}

	public Double getTaxExport() {
		return taxExport;
	}

	public void setTaxExport(Double taxExport) {
		this.taxExport = taxExport;
	}

	public Double getTaxExcise() {
		return taxExcise;
	}

	public void setTaxExcise(Double taxExcise) {
		this.taxExcise = taxExcise;
	}

	public Double getTaxInterior() {
		return taxInterior;
	}

	public void setTaxInterior(Double taxInterior) {
		this.taxInterior = taxInterior;
	}

	public Double getVatAmount() {
		return VatAmount;
	}

	public void setVatAmount(Double vatAmount) {
		VatAmount = vatAmount;
	}

	public Double getQuantityReceiveFreeZone() {
		return quantityReceiveFreeZone;
	}

	public void setQuantityReceiveFreeZone(Double quantityReceiveFreeZone) {
		this.quantityReceiveFreeZone = quantityReceiveFreeZone;
	}

	public Double getQuantityDamagedFreeZone() {
		return quantityDamagedFreeZone;
	}

	public void setQuantityDamagedFreeZone(Double quantityDamagedFreeZone) {
		this.quantityDamagedFreeZone = quantityDamagedFreeZone;
	}

	public Double getWeightReceiveFreeZone() {
		return weightReceiveFreeZone;
	}

	public void setWeightReceiveFreeZone(Double weightReceiveFreeZone) {
		this.weightReceiveFreeZone = weightReceiveFreeZone;
	}

	public Double getWeightDamagedFreeZone() {
		return WeightDamagedFreeZone;
	}

	public void setWeightDamagedFreeZone(Double weightDamagedFreeZone) {
		WeightDamagedFreeZone = weightDamagedFreeZone;
	}

	public String getDamagedRemarkFreeZone() {
		return damagedRemarkFreeZone;
	}

	public void setDamagedRemarkFreeZone(String damagedRemarkFreeZone) {
		this.damagedRemarkFreeZone = damagedRemarkFreeZone;
	}

	public Warehouse getWarehouseFreeZone() {
		return warehouseFreeZone;
	}

	public void setWarehouseFreeZone(Warehouse warehouseFreeZone) {
		this.warehouseFreeZone = warehouseFreeZone;
	}

	public Double getQuantityReceiveCompany() {
		return quantityReceiveCompany;
	}

	public void setQuantityReceiveCompany(Double quantityReceiveCompany) {
		this.quantityReceiveCompany = quantityReceiveCompany;
	}

	public Double getQuantityDamagedCompany() {
		return quantityDamagedCompany;
	}

	public void setQuantityDamagedCompany(Double quantityDamagedCompany) {
		this.quantityDamagedCompany = quantityDamagedCompany;
	}

	public Double getWeightReceiveCompany() {
		return weightReceiveCompany;
	}

	public void setWeightReceiveCompany(Double weightReceiveCompany) {
		this.weightReceiveCompany = weightReceiveCompany;
	}

	public Double getWeightDamagedCompany() {
		return WeightDamagedCompany;
	}

	public void setWeightDamagedCompany(Double weightDamagedCompany) {
		WeightDamagedCompany = weightDamagedCompany;
	}

	public String getDamagedRemarkCompany() {
		return damagedRemarkCompany;
	}

	public void setDamagedRemarkCompany(String damagedRemarkCompany) {
		this.damagedRemarkCompany = damagedRemarkCompany;
	}

	public Warehouse getWarehouseCompany() {
		return warehouseCompany;
	}

	public void setWarehouseCompany(Warehouse warehouseCompany) {
		this.warehouseCompany = warehouseCompany;
	}
}
