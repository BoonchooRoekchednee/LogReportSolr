package com.isoftbiz.freezone.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;

@Entity
@Table(name = "ItemGroup", uniqueConstraints = @UniqueConstraint(columnNames = {"ItemGroupCode", "CompanyID"}))
public class ItemGroup {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ItemGroupID")
	private Long itemGroupID;
	
	@Column(name = "ItemGroupCode", length = 32, nullable = false)
	private String itemGroupCode;
	
	@Column(name = "ItemGroupName", length = 128, nullable = false)
	private String itemGroupName;
	
	@Column(name = "OwnerFreeZone", length = 1, nullable = false)
	private String ownerFreeZone;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getItemGroupID() {
		return itemGroupID;
	}

	public void setItemGroupID(Long itemGroupID) {
		this.itemGroupID = itemGroupID;
	}

	public String getItemGroupCode() {
		return itemGroupCode;
	}

	public void setItemGroupCode(String itemGroupCode) {
		this.itemGroupCode = itemGroupCode;
	}

	public String getItemGroupName() {
		return itemGroupName;
	}

	public void setItemGroupName(String itemGroupName) {
		this.itemGroupName = itemGroupName;
	}

	public String getOwnerFreeZone() {
		return ownerFreeZone;
	}

	public void setOwnerFreeZone(String ownerFreeZone) {
		this.ownerFreeZone = ownerFreeZone;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
