package com.isoftbiz.freezone.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;

@Entity
@Table(name = "Warehouse", uniqueConstraints = @UniqueConstraint(columnNames = {"WarehouseCode", "CompanyID"}))
public class Warehouse {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "WarehouseID")
	private Long warehouseID;
	
	@Column(name = "WarehouseCode", length = 32, nullable = false)
	private String warehouseCode;
	
	@Column(name = "WarehouseName", length = 128, nullable = false)
	private String warehouseName;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@Column(name = "WarehouseType", length = 8)
	private String warehouseType;
	
	@Column(name = "OwnerFreeZone", length = 1, nullable = false)
	private String ownerFreeZone;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getWarehouseID() {
		return warehouseID;
	}

	public void setWarehouseID(Long warehouseID) {
		this.warehouseID = warehouseID;
	}

	public String getWarehouseCode() {
		return warehouseCode;
	}

	public void setWarehouseCode(String warehouseCode) {
		this.warehouseCode = warehouseCode;
	}

	public String getWarehouseName() {
		return warehouseName;
	}

	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getWarehouseType() {
		return warehouseType;
	}

	public void setWarehouseType(String warehouseType) {
		this.warehouseType = warehouseType;
	}

	public String getOwnerFreeZone() {
		return ownerFreeZone;
	}

	public void setOwnerFreeZone(String ownerFreeZone) {
		this.ownerFreeZone = ownerFreeZone;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
