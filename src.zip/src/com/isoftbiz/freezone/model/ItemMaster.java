package com.isoftbiz.freezone.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;
import com.isoftbiz.freezone.model.ItemGroup;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "ItemMaster", uniqueConstraints = @UniqueConstraint(columnNames = {"ItemCode", "CompanyID"}))
public class ItemMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ItemID")
	private Long itemID;
	
	@Column(name = "ItemCode", length = 32, nullable = false)
	private String itemCode;
	
	@Column(name = "ItemCdoe1", length = 32, nullable = true)
	private String itemCode1;
	
	@Column(name = "ItemCdoe2", length = 32, nullable = true)
	private String itemCode2;
	
	@Column(name = "Barcode", length = 32, nullable = true)
	private String barcode;
	
	@Column(name = "Barcode2", length = 32, nullable = true)
	private String barcode2;
	
	@Column(name = "ItemName", length = 128, nullable = false)
	private String itemName;
	
	@Column(name = "MinQuantity", columnDefinition = "Decimal(14,4)")
	private Double minQuantity;
	
	@Column(name = "MaxQuantity", columnDefinition = "Decimal(14,4)")
	private Double maxQuantity;
	
	@Column(name = "OrderPointQuantity", columnDefinition = "Decimal(14,4)")
	private Double orderPointQuantity;
	
	@Column(name = "BalanceQuantity", columnDefinition = "Decimal(14,4)")
	private Double balanceQuantity;
	
	@Column(name = "DamagedQuantity", columnDefinition = "Decimal(14,4)")
	private Double damagedQuantity;
	
	@Column(name = "ItemName1", length = 128, nullable = true)
	private String itemName1;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@Column(name = "PartNo", length = 64)
	private String partNo;
	
	@Column(name = "SerialNo", length = 64)
	private String serialNo;
	
	@Column(name = "Brand", length = 64)
	private String brand;
	
	@Column(name = "Model", length = 64)
	private String model;
	
	@Column(name = "ModelType", length = 64)
	private String modelType;
	
	@Column(name = "Color", length = 64)
	private String color;
	
	@Column(name = "Size", length = 64)
	private String size;
	
	@ManyToOne
	@JoinColumn(name = "ItemTypeID", nullable = false)
	private ItemType itemType;
	
	@ManyToOne
	@JoinColumn(name = "ItemGroupID", nullable = true)
	private ItemGroup itemGroup;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = true)
	private Unit unit;
	
	@Column(name = "OwnerFreeZone", length = 1, nullable = false)
	private String ownerFreeZone;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getItemID() {
		return itemID;
	}

	public void setItemID(Long itemID) {
		this.itemID = itemID;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemCode1() {
		return itemCode1;
	}

	public void setItemCode1(String itemCode1) {
		this.itemCode1 = itemCode1;
	}

	public String getItemCode2() {
		return itemCode2;
	}

	public void setItemCode2(String itemCode2) {
		this.itemCode2 = itemCode2;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getBarcode2() {
		return barcode2;
	}

	public void setBarcode2(String barcode2) {
		this.barcode2 = barcode2;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Double getMinQuantity() {
		return minQuantity;
	}

	public void setMinQuantity(Double minQuantity) {
		this.minQuantity = minQuantity;
	}

	public Double getMaxQuantity() {
		return maxQuantity;
	}

	public void setMaxQuantity(Double maxQuantity) {
		this.maxQuantity = maxQuantity;
	}

	public Double getOrderPointQuantity() {
		return orderPointQuantity;
	}

	public void setOrderPointQuantity(Double orderPointQuantity) {
		this.orderPointQuantity = orderPointQuantity;
	}

	public Double getBalanceQuantity() {
		return balanceQuantity;
	}

	public void setBalanceQuantity(Double balanceQuantity) {
		this.balanceQuantity = balanceQuantity;
	}

	public Double getDamagedQuantity() {
		return damagedQuantity;
	}

	public void setDamagedQuantity(Double damagedQuantity) {
		this.damagedQuantity = damagedQuantity;
	}

	public String getItemName1() {
		return itemName1;
	}

	public void setItemName1(String itemName1) {
		this.itemName1 = itemName1;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getModelType() {
		return modelType;
	}

	public void setModelType(String modelType) {
		this.modelType = modelType;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public ItemType getItemType() {
		return itemType;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public ItemGroup getItemGroup() {
		return itemGroup;
	}

	public void setItemGroup(ItemGroup itemGroup) {
		this.itemGroup = itemGroup;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public String getOwnerFreeZone() {
		return ownerFreeZone;
	}

	public void setOwnerFreeZone(String ownerFreeZone) {
		this.ownerFreeZone = ownerFreeZone;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
