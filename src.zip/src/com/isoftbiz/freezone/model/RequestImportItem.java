package com.isoftbiz.freezone.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;
import com.isoftbiz.setupdata.model.Company;

@Entity
@Table(name = "RequestImportItem", uniqueConstraints = @UniqueConstraint(columnNames = {"RequestCode", "CompanyID"}))
public class RequestImportItem {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RequestID")
	private Long requestID;
	
	@Column(name = "RequestCode", length = 32, nullable = false)
	private String requestCode;
	
	@Column(name = "RefDoc", length = 32)
	private String refDoc;
	
	@Column(name = "RequestDate")
	@Type(type = "date")
	private Date requestDate;
	
	@Column(name = "OwnerFreeZone", length = 1, nullable = false)
	private String ownerFreeZone;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = false)
	private CompanyFreeZone company;
	
	@Column(name = "RequestType", length = 32)
	private String requestType;
	
	@Column(name = "ImportType", length = 32)
	private String importType;
	
	@Column(name = "IndustryType", length = 32)
	private String industryType;
	
	@Column(name = "CountryName", length = 128, nullable = true)
	private String countryName;
	
	@Column(name = "CurrencyForeign", length = 32, nullable = true)
	private String currencyForeign;
	
	@Column(name = "CurrecyRate", columnDefinition = "Decimal(12,4)")
	private Double currencyRate;
	
	@Column(name = "TotalAmount", columnDefinition = "Decimal(16,2)")
	private Double totalAmount;
	
	@Column(name = "TotalWeight", columnDefinition = "Decimal(16,2)")
	private Double totalWeight;
	
	@Column(name = "GrossWeight", columnDefinition = "Decimal(16,2)")
	private Double grossWeight;
	
	@Column(name = "NetWeight", columnDefinition = "Decimal(16,2)")
	private Double netWeight;
	
	@Column(name = "ReceiveStatus", length = 32)
	private String receiveStatus;
	
	@Column(name = "ReceiveStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date receiveStatusDate;
	
	@Column(name = "RecordStatus", length = 32)
	private String recordStatus;
	
	@Column(name = "RecordStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date recordStatusDate;
	
	@Column(name = "Barcode", length = 32, nullable = true)
	private String barcode;
	
	@Column(name = "Barcode2", length = 32, nullable = true)
	private String barcode2;
	
	@Column(name = "Remark", length = 255)
	private String remark;
	
	@Column(name = "ReceiveNo", length = 32, nullable = true)
	private String receiveNo;
	
	@Column(name = "ReceiveDate")
	@Type(type = "date")
	private Date receiveDate;
	
	@Column(name = "ReceiveBy", length = 128)
	private String receiveBy;
	
	@Column(name = "ShippingNo", length = 32, nullable = true)
	private String shippingNo;
	
	@Column(name = "ShippingDate")
	@Type(type = "date")
	private Date shippingDate;
	
	@ManyToOne
	@JoinColumn(name = "ShippingID", nullable = true)
	private Company companyShipping;
	
	@Column(name = "TransferNo", length = 32, nullable = true)
	private String transferNo;
	
	@Column(name = "TransferDate")
	@Type(type = "date")
	private Date transferDate;
	
	@Column(name = "DeliveryNo", length = 32, nullable = true)
	private String deliveryNo;
	
	@Column(name = "DeliveryDate")
	@Type(type = "date")
	private Date deliveryDate;
	
	@Column(name = "TaxImport", columnDefinition = "Decimal(12,2)")
	private Double taxImport;
	
	@Column(name = "TaxExcise", columnDefinition = "Decimal(12,2)")
	private Double taxExcise;
	
	@Column(name = "TaxInterior", columnDefinition = "Decimal(12,2)")
	private Double taxInterior;
	
	@Column(name = "VatAmount", columnDefinition = "Decimal(12,2)")
	private Double VatAmount;
	
	@Column(name = "CustomsCheckDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date customsCheckDate; 
	
	@Column(name = "DocumentTransfer", length = 32)
	private String documentTransfer;
	
	@Column(name = "DocumentTransferDate")
	@Type(type = "date")
	private Date documentTransferDate;
	
	@Column(name = "Vehicle", length = 128)
	private String vehicle;
	
	@Column(name = "InDate")
	@Type(type = "date")
	private Date inDate;
	
	@Column(name = "QuantityPack")
	private int quantityPack;
	
	@Column(name = "UnitQuantityPack", length = 32)
	private String unitQuantityPack;
	
	@Column(name = "PortName", length = 128)
	private String portName;
	
	@Column(name = "PortTerminal", length = 128)
	private String portTerminal;
	
	@Column(name = "MoveStatus", length = 1)
	private String moveStatus;
	
	@Column(name = "MoveItemDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date moveItemDate;
	
	@Column(name = "MoveItemBy", length = 128)
	private String moveItemBy;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getRequestCode() {
		return requestCode;
	}

	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}

	public String getRefDoc() {
		return refDoc;
	}

	public void setRefDoc(String refDoc) {
		this.refDoc = refDoc;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public String getOwnerFreeZone() {
		return ownerFreeZone;
	}

	public void setOwnerFreeZone(String ownerFreeZone) {
		this.ownerFreeZone = ownerFreeZone;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getImportType() {
		return importType;
	}

	public void setImportType(String importType) {
		this.importType = importType;
	}

	public String getIndustryType() {
		return industryType;
	}

	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCurrencyForeign() {
		return currencyForeign;
	}

	public void setCurrencyForeign(String currencyForeign) {
		this.currencyForeign = currencyForeign;
	}

	public Double getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(Double currencyRate) {
		this.currencyRate = currencyRate;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Double getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(Double totalWeight) {
		this.totalWeight = totalWeight;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}

	public String getReceiveStatus() {
		return receiveStatus;
	}

	public void setReceiveStatus(String receiveStatus) {
		this.receiveStatus = receiveStatus;
	}

	public Date getReceiveStatusDate() {
		return receiveStatusDate;
	}

	public void setReceiveStatusDate(Date receiveStatusDate) {
		this.receiveStatusDate = receiveStatusDate;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Date getRecordStatusDate() {
		return recordStatusDate;
	}

	public void setRecordStatusDate(Date recordStatusDate) {
		this.recordStatusDate = recordStatusDate;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getBarcode2() {
		return barcode2;
	}

	public void setBarcode2(String barcode2) {
		this.barcode2 = barcode2;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getReceiveNo() {
		return receiveNo;
	}

	public void setReceiveNo(String receiveNo) {
		this.receiveNo = receiveNo;
	}

	public Date getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(Date receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getReceiveBy() {
		return receiveBy;
	}

	public void setReceiveBy(String receiveBy) {
		this.receiveBy = receiveBy;
	}

	public String getShippingNo() {
		return shippingNo;
	}

	public void setShippingNo(String shippingNo) {
		this.shippingNo = shippingNo;
	}

	public Date getShippingDate() {
		return shippingDate;
	}

	public void setShippingDate(Date shippingDate) {
		this.shippingDate = shippingDate;
	}

	public Company getCompanyShipping() {
		return companyShipping;
	}

	public void setCompanyShipping(Company companyShipping) {
		this.companyShipping = companyShipping;
	}

	public String getTransferNo() {
		return transferNo;
	}

	public void setTransferNo(String transferNo) {
		this.transferNo = transferNo;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public String getDeliveryNo() {
		return deliveryNo;
	}

	public void setDeliveryNo(String deliveryNo) {
		this.deliveryNo = deliveryNo;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Double getTaxImport() {
		return taxImport;
	}

	public void setTaxImport(Double taxImport) {
		this.taxImport = taxImport;
	}

	public Double getTaxExcise() {
		return taxExcise;
	}

	public void setTaxExcise(Double taxExcise) {
		this.taxExcise = taxExcise;
	}

	public Double getTaxInterior() {
		return taxInterior;
	}

	public void setTaxInterior(Double taxInterior) {
		this.taxInterior = taxInterior;
	}

	public Double getVatAmount() {
		return VatAmount;
	}

	public void setVatAmount(Double vatAmount) {
		VatAmount = vatAmount;
	}

	public Date getCustomsCheckDate() {
		return customsCheckDate;
	}

	public void setCustomsCheckDate(Date customsCheckDate) {
		this.customsCheckDate = customsCheckDate;
	}

	public String getDocumentTransfer() {
		return documentTransfer;
	}

	public void setDocumentTransfer(String documentTransfer) {
		this.documentTransfer = documentTransfer;
	}

	public Date getDocumentTransferDate() {
		return documentTransferDate;
	}

	public void setDocumentTransferDate(Date documentTransferDate) {
		this.documentTransferDate = documentTransferDate;
	}

	public String getVehicle() {
		return vehicle;
	}

	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}

	public Date getInDate() {
		return inDate;
	}

	public void setInDate(Date inDate) {
		this.inDate = inDate;
	}

	public int getQuantityPack() {
		return quantityPack;
	}

	public void setQuantityPack(int quantityPack) {
		this.quantityPack = quantityPack;
	}

	public String getUnitQuantityPack() {
		return unitQuantityPack;
	}

	public void setUnitQuantityPack(String unitQuantityPack) {
		this.unitQuantityPack = unitQuantityPack;
	}

	public String getPortName() {
		return portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public String getPortTerminal() {
		return portTerminal;
	}

	public void setPortTerminal(String portTerminal) {
		this.portTerminal = portTerminal;
	}

	public String getMoveStatus() {
		return moveStatus;
	}

	public void setMoveStatus(String moveStatus) {
		this.moveStatus = moveStatus;
	}

	public Date getMoveItemDate() {
		return moveItemDate;
	}

	public void setMoveItemDate(Date moveItemDate) {
		this.moveItemDate = moveItemDate;
	}

	public String getMoveItemBy() {
		return moveItemBy;
	}

	public void setMoveItemBy(String moveItemBy) {
		this.moveItemBy = moveItemBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
