package com.isoftbiz.freezone.iservice;

import java.util.List;

import com.isoftbiz.freezone.model.Warehouse;

public interface IWarehouseService {
	public Warehouse findById(Long warehouseID) throws Exception;
	
	public Warehouse findByWarehouseCode(String warehouseCode) throws Exception;
	
	public Warehouse findByWarehouseCodeCompany(String warehouseCode, Long companyID) throws Exception;

	public List<Warehouse> findAll() throws Exception;
	
	public List<Warehouse> listOfFreeZone() throws Exception;
	
	public List<Warehouse> listOfCompany(Long companyID) throws Exception;

	public boolean save(Warehouse warehouse) throws Exception;

	public boolean update(Warehouse warehouse) throws Exception;

	public boolean delete(Warehouse warehouse) throws Exception;
}
