package com.isoftbiz.freezone.iservice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.isoftbiz.freezone.model.RequestExportItemDetail;

public interface IRequestExportItemDetailService {
	public RequestExportItemDetail findById(Long requestDetailID) throws Exception;
	
	public List<RequestExportItemDetail> findAll(Long requestID) throws Exception;

	public boolean save(RequestExportItemDetail requestExportItemDetail) throws Exception;

	public boolean update(RequestExportItemDetail requestExportItemDetail) throws Exception;

	public boolean delete(RequestExportItemDetail requestExportItemDetail) throws Exception;

	public int saveReceiveItemDetail(HttpServletRequest request) throws Exception;
	
	public int saveReceiveItemDetailByCompany(HttpServletRequest request) throws Exception;
}
