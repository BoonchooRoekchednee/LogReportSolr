package com.isoftbiz.freezone.iservice;

import java.util.List;

import com.isoftbiz.freezone.model.ItemMaster;

public interface IItemMasterService {
	public ItemMaster findById(Long itemID) throws Exception;

	public ItemMaster findByItemCode(String itemCode) throws Exception;
	
	public ItemMaster findByItemCodeCompany(String itemCode, Long companyID) throws Exception;

	public List<ItemMaster> findAll() throws Exception;
	
	public List<ItemMaster> listOfFreeZone() throws Exception;
	
	public List<ItemMaster> listOfCompany(Long companyID) throws Exception;

	public boolean save(ItemMaster itemMaster) throws Exception;

	public boolean update(ItemMaster itemMaster) throws Exception;

	public boolean delete(ItemMaster itemMaster) throws Exception;
}
