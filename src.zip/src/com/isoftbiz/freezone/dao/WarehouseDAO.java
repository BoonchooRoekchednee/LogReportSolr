package com.isoftbiz.freezone.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.Warehouse;
import com.isoftbiz.freezone.idao.IWarehouseDAO;

@Repository
public class WarehouseDAO extends HibernateDaoSupport implements IWarehouseDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Warehouse findById(Long warehouseID) throws Exception {
		Warehouse warehouse = this.getHibernateTemplate().get(Warehouse.class, warehouseID);
		return warehouse;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Warehouse findByWarehouseCode(String warehouseCode) throws Exception {
		List warehouse = this.getHibernateTemplate().find("from Warehouse where WarehouseCode=?", warehouseCode);
		if (warehouse.isEmpty()) {
			return null;
		} else {
			return (Warehouse)warehouse.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public Warehouse findByWarehouseCodeCompany(String warehouseCode, Long companyID) throws Exception {
		List warehouse = this.getHibernateTemplate().find("from Warehouse where WarehouseCode=? and CompanyID=?", warehouseCode, companyID);
		if (warehouse.isEmpty()) {
			return null;
		} else {
			return (Warehouse)warehouse.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Warehouse> findAll() throws Exception {
		List<Warehouse> warehouseList = session.createCriteria(Warehouse.class).list();
		session.flush();
		session.clear();
		return warehouseList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Warehouse> listOfFreeZone() throws Exception {
		List<Warehouse> warehouseList = this.getHibernateTemplate().find("from Warehouse where OwnerFreeZone = 'Y' order by WarehouseCode asc");
		return warehouseList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Warehouse> listOfCompany(Long companyID) throws Exception {
		List<Warehouse> warehouseList = this.getHibernateTemplate().find("from Warehouse where OwnerFreeZone = 'N' and CompanyID = " + companyID.toString() + " order by WarehouseCode asc");
		return warehouseList;
	}
	
	@Override
	public boolean save(Warehouse warehouse) throws Exception {
		this.getHibernateTemplate().save(warehouse);
		return true;
	}

	@Override
	public boolean update(Warehouse warehouse) throws Exception {
		this.getHibernateTemplate().update(warehouse);
		return true;
	}

	@Override
	public boolean delete(Warehouse warehouse) throws Exception {
		this.getHibernateTemplate().delete(warehouse);
		return true;
	}
}
