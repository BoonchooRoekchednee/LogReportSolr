package com.isoftbiz.freezone.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.ItemGroup;
import com.isoftbiz.freezone.idao.IItemGroupDAO;

@Repository
public class ItemGroupDAO extends HibernateDaoSupport implements IItemGroupDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public ItemGroup findById(Long itemGroupID) throws Exception {
		ItemGroup itemGroup = this.getHibernateTemplate().get(ItemGroup.class, itemGroupID);
		return itemGroup;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ItemGroup findByItemGroupCode(String itemGroupCode) throws Exception {
		List itemGroup = this.getHibernateTemplate().find("from ItemGroup where ItemGroupCode=?", itemGroupCode);
		if (itemGroup.isEmpty()) {
			return null;
		} else {
			return (ItemGroup)itemGroup.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public ItemGroup findByItemGroupCodeCompany(String itemGroupCode, Long companyID) throws Exception {
		List itemGroup = this.getHibernateTemplate().find("from ItemGroup where ItemGroupCode=? and CompanyID=?", itemGroupCode, companyID);
		if (itemGroup.isEmpty()) {
			return null;
		} else {
			return (ItemGroup)itemGroup.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemGroup> findAll() throws Exception {
		List<ItemGroup> itemGroupList = session.createCriteria(ItemGroup.class).list();
		session.flush();
		session.clear();
		return itemGroupList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemGroup> listOfFreeZone() throws Exception {
		List<ItemGroup> itemGroupList = this.getHibernateTemplate().find("from ItemGroup where OwnerFreeZone = 'Y' order by ItemGroupCode asc");
		return itemGroupList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemGroup> listOfCompany(Long companyID) throws Exception {
		List<ItemGroup> itemGroupList = this.getHibernateTemplate().find("from ItemGroup where OwnerFreeZone = 'N' and CompanyID = " + companyID.toString() + " order by ItemGroupCode asc");
		return itemGroupList;
	}
	
	@Override
	public boolean save(ItemGroup itemGroup) throws Exception {
		this.getHibernateTemplate().save(itemGroup);
		return true;
	}

	@Override
	public boolean update(ItemGroup itemGroup) throws Exception {
		this.getHibernateTemplate().update(itemGroup);
		return true;
	}

	@Override
	public boolean delete(ItemGroup itemGroup) throws Exception {
		this.getHibernateTemplate().delete(itemGroup);
		return true;
	}
}
