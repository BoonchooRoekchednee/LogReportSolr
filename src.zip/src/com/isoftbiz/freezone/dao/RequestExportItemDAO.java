package com.isoftbiz.freezone.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.RequestExportItem;
import com.isoftbiz.freezone.idao.IRequestExportItemDAO;

@Repository
public class RequestExportItemDAO extends HibernateDaoSupport implements IRequestExportItemDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public RequestExportItem findById(Long requestID) throws Exception {
		RequestExportItem requestExport = this.getHibernateTemplate().get(RequestExportItem.class, requestID);
		return requestExport;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public RequestExportItem findByRequestCode(String requestCode) throws Exception {
		List requestExport = this.getHibernateTemplate().find("from RequestExportItem where RequestCode=?", requestCode);
		if (requestExport.isEmpty()) {
			return null;
		} else {
			return (RequestExportItem)requestExport.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public RequestExportItem findByRequestCodeCompany(String requestCode, Long companyID) throws Exception {
		List requestExport = this.getHibernateTemplate().find("from RequestExportItem where RequestCode=? and CompanyID=?", requestCode, companyID);
		if (requestExport.isEmpty()) {
			return null;
		} else {
			return (RequestExportItem)requestExport.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItem> findAll() throws Exception {
		List<RequestExportItem> requestExportList = session.createCriteria(RequestExportItem.class).list();
		session.flush();
		session.clear();
		return requestExportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItem> listOfFreeZone() throws Exception {
		List<RequestExportItem> requestExportList = this.getHibernateTemplate().find("from RequestExportItem where OwnerFreeZone = 'Y' order by RequestID desc");
		return requestExportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItem> listOfCompany() throws Exception {
		List<RequestExportItem> requestExportList = this.getHibernateTemplate().find("from RequestExportItem where OwnerFreeZone = 'N' order by RequestID desc");
		return requestExportList;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItem> listOfCompany(Long companyID) throws Exception {
		List<RequestExportItem> requestExportList = this.getHibernateTemplate().find("from RequestExportItem where OwnerFreeZone = 'N' and CompanyID = " + companyID.toString() + " order by RequestID desc");
		return requestExportList;
	}
	
	@Override
	public boolean save(RequestExportItem requestExport) throws Exception {
		this.getHibernateTemplate().save(requestExport);
		RequestExportItem requestExportItem = this.findById(requestExport.getRequestID());
		String sBarcode;
		sBarcode = requestExportItem.getCompany().getCompanyCode() + "EXP" + requestExport.getRequestID().toString();
		Query query;
		String sSQL;
		sSQL = "update RequestExportItem set ";
		sSQL += " RequestCode = '" + sBarcode + "'";
		sSQL += ", Barcode = '" + sBarcode + "'";
		sSQL += " where RequestID = " + requestExport.getRequestID().toString();
		query = session.createQuery(sSQL);
		query.executeUpdate();
		return true;
	}

	@Override
	public boolean update(RequestExportItem requestExport) throws Exception {
		this.getHibernateTemplate().update(requestExport);
		return true;
	}

	@Override
	public boolean delete(RequestExportItem requestExport) throws Exception {
		this.getHibernateTemplate().delete(requestExport);
		return true;
	}
	
	@Override
	public int updateReceiveStatus(Long requestID, String status) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sSQL;
		sSQL = "update RequestExportItem set ";
		sSQL += " ReceiveStatus = '" + status + "' ";
		sSQL += ", ReceiveStatusDate = '" + sDate + "' ";
		sSQL += " where RequestID = " + requestID.toString();
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int updateRecordStatus(Long requestID, String status) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sSQL;
		sSQL = "update RequestExportItem set ";
		sSQL += " RecordStatus = '" + status + "' ";
		sSQL += ", RecordStatusDate = '" + sDate + "' ";
		sSQL += " where RequestID = " + requestID.toString();
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int saveReceiveItem(HttpServletRequest request) throws Exception {
		Query query;
		String sSQL;
		sSQL = "update RequestExportItem set ";
		sSQL += " ReceiveNo = '" + request.getParameter("receiveNo") + "'";
		sSQL += " , ReceiveDate = '" + request.getParameter("receiveDate") + "'";
		sSQL += " , ReceiveBy = '" + request.getParameter("receiveBy") + "'";
		sSQL += " , ShippingNo = '" + request.getParameter("shippingNo") + "'";
		sSQL += " , ShippingDate = '" + request.getParameter("shippingDate") + "'";
		sSQL += " , ShippingID = " + request.getParameter("shippingBy");
		sSQL += " , DocumentTransfer = '" + request.getParameter("documentTransfer") + "'";
		sSQL += " , DocumentTransferDate = '" + request.getParameter("documentTransferDate") + "'";
		sSQL += " , CustomsCheckDate = '" + request.getParameter("customsCheckDate") + "'";
		sSQL += " , TaxExport = " + request.getParameter("taxExport");
		sSQL += " , VatAmount = " + request.getParameter("vatAmount");
		sSQL += " , TaxExcise = " + request.getParameter("taxExcise");
		sSQL += " , Vehicle = '" + request.getParameter("vehicle") + "'";
		sSQL += " , OutDate = '" + request.getParameter("outDate") + "'";
		sSQL += " , QuantityPack = " + request.getParameter("quantityPack");
		sSQL += " , PortName = '" + request.getParameter("portName") + "'";
		sSQL += " , PortTerminal = '" + request.getParameter("portTerminal") + "'";
		sSQL += " where RequestID = " + request.getParameter("requestID");
		query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int transferItem(Long requestID) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sSQL;
		sSQL = "update RequestExportItem set ";
		sSQL += " MoveStatus = 'Y' ";
		sSQL += ", MoveItemDate = '" + sDate + "' ";
		sSQL += ", ReceiveStatus = 'Completed Check'";
		sSQL += ", RecordStatus = 'Completed'";
		sSQL += " where RequestID = " + requestID.toString();
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItem> searchByReceiveDate(String sStartDate, String sEndDate) throws Exception {
		List<RequestExportItem> requestExportList = this.getHibernateTemplate().find("from RequestExportItem where ReceiveDate >= '" + sStartDate + "' and ReceiveDate <= '" + sEndDate + "' order by ReceiveDate asc");
		return requestExportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItem> searchReport(HttpServletRequest request) throws Exception {
		String sStartDate = request.getParameter("receiveDateFrom");
		String sEndDate = request.getParameter("receiveDateTo");
		String sRequestType = request.getParameter("requestType");
		String sCountryName = request.getParameter("countryName");
		String sExportType = request.getParameter("exportType");
		String sIndustryType = request.getParameter("industryType");
		
		if (sStartDate == null) sStartDate = "";
		if (sEndDate == null) sEndDate = "";
		if (sRequestType == null) sRequestType = "";
		if (sCountryName == null) sCountryName = "";
		if (sExportType == null) sExportType = "";
		if (sIndustryType == null) sIndustryType = "";
		
		String sSQL;
		sSQL = "from RequestExportItem where ReceiveDate >= '" + sStartDate + "' and ReceiveDate <= '" + sEndDate + "'";
		if (!sRequestType.equalsIgnoreCase("")) {
			sSQL += " and RequestType = '" + sRequestType + "' ";
		}
		if (!sCountryName.equalsIgnoreCase("")) {
			sSQL += " and CountryName = '" + sCountryName + "' ";
		}
		if (!sExportType.equalsIgnoreCase("")) {
			sSQL += " and ExportType = '" + sExportType + "' ";
		}
		if (!sIndustryType.equalsIgnoreCase("")) {
			sSQL += " and IndustryType = '" + sIndustryType + "' ";
		}
		sSQL	+= " order by RequestID asc ";
		
		List<RequestExportItem> requestExportList = this.getHibernateTemplate().find(sSQL);
		return requestExportList;
	}
}
