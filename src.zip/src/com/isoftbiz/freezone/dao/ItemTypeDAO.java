package com.isoftbiz.freezone.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.ItemType;
import com.isoftbiz.freezone.idao.IItemTypeDAO;

@Repository
public class ItemTypeDAO extends HibernateDaoSupport implements IItemTypeDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public ItemType findById(Long itemTypeID) throws Exception {
		ItemType itemType = this.getHibernateTemplate().get(ItemType.class, itemTypeID);
		return itemType;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ItemType findByItemTypeCode(String itemTypeCode) throws Exception {
		List itemType = this.getHibernateTemplate().find("from ItemType where ItemTypeCode=?", itemTypeCode);
		return (ItemType)itemType.get(0);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemType> findAll() throws Exception {
		List<ItemType> itemTypeList = session.createCriteria(ItemType.class).list();
		session.flush();
		session.clear();
		return itemTypeList;
	}
	
	@Override
	public boolean save(ItemType itemType) throws Exception {
		this.getHibernateTemplate().save(itemType);
		return true;
	}

	@Override
	public boolean update(ItemType itemType) throws Exception {
		this.getHibernateTemplate().update(itemType);
		return true;
	}

	@Override
	public boolean delete(ItemType itemType) throws Exception {
		this.getHibernateTemplate().delete(itemType);
		return true;
	}
}
