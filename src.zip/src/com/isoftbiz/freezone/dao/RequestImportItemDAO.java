package com.isoftbiz.freezone.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.RequestImportItem;
import com.isoftbiz.freezone.idao.IRequestImportItemDAO;

@Repository
public class RequestImportItemDAO extends HibernateDaoSupport implements IRequestImportItemDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public RequestImportItem findById(Long requestID) throws Exception {
		RequestImportItem requestImport = this.getHibernateTemplate().get(RequestImportItem.class, requestID);
		return requestImport;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public RequestImportItem findByRequestCode(String requestCode) throws Exception {
		List requestImport = this.getHibernateTemplate().find("from RequestImportItem where RequestCode=?", requestCode);
		if (requestImport.isEmpty()) {
			return null;
		} else {
			return (RequestImportItem)requestImport.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public RequestImportItem findByRequestCodeCompany(String requestCode, Long companyID) throws Exception {
		List requestImport = this.getHibernateTemplate().find("from RequestImportItem where RequestCode=? and CompanyID=?", requestCode, companyID);
		if (requestImport.isEmpty()) {
			return null;
		} else {
			return (RequestImportItem)requestImport.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> findAll() throws Exception {
		List<RequestImportItem> requestImportList = session.createCriteria(RequestImportItem.class).list();
		session.flush();
		session.clear();
		return requestImportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> listOfFreeZone() throws Exception {
		List<RequestImportItem> requestImportList = this.getHibernateTemplate().find("from RequestImportItem where OwnerFreeZone = 'Y' order by RequestID desc");
		return requestImportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> listOfCompany() throws Exception {
		List<RequestImportItem> requestImportList = this.getHibernateTemplate().find("from RequestImportItem where OwnerFreeZone = 'N' order by RequestID desc");
		return requestImportList;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> listOfCompany(Long companyID) throws Exception {
		List<RequestImportItem> requestImportList = this.getHibernateTemplate().find("from RequestImportItem where OwnerFreeZone = 'N' and CompanyID = " + companyID.toString() + " order by RequestID desc");
		return requestImportList;
	}
	
	@Override
	public boolean save(RequestImportItem requestImport) throws Exception {
		this.getHibernateTemplate().save(requestImport);
		RequestImportItem requestImportItem = this.findById(requestImport.getRequestID());
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sBarcode;
		sBarcode = requestImportItem.getCompany().getCompanyCode() + "IMP" + requestImport.getRequestID().toString();
		Query query;
		String sSQL;
		sSQL = "update RequestImportItem set ";
		sSQL += " RequestCode = '" + sBarcode + "'";
		sSQL += ", Barcode = '" + sBarcode + "'";
		sSQL += ", CreatedDate = '" + sDate + "' ";
		sSQL += " where RequestID = " + requestImport.getRequestID().toString();
		query = session.createQuery(sSQL);
		query.executeUpdate();
		return true;
	}

	@Override
	public boolean update(RequestImportItem requestImport) throws Exception {
		this.getHibernateTemplate().update(requestImport);
		return true;
	}

	@Override
	public boolean delete(RequestImportItem requestImport) throws Exception {
		this.getHibernateTemplate().delete(requestImport);
		return true;
	}
	
	@Override
	public int updateReceiveStatus(Long requestID, String status) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sSQL;
		sSQL = "update RequestImportItem set ";
		sSQL += " ReceiveStatus = '" + status + "' ";
		sSQL += ", ReceiveStatusDate = '" + sDate + "' ";
		sSQL += ", ModifiedDate = '" + sDate + "' ";
		sSQL += " where RequestID = " + requestID.toString();
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int updateRecordStatus(Long requestID, String status) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sSQL;
		sSQL = "update RequestImportItem set ";
		sSQL += " RecordStatus = '" + status + "'";
		if (status.equalsIgnoreCase("Completed")) {
			sSQL += ", ReceiveStatus = 'Completed Receive' ";
			sSQL += ", ReceiveStatusDate = '" + sDate + "' ";
		}
		sSQL += ", RecordStatusDate = '" + sDate + "' ";
		sSQL += ", ModifiedDate = '" + sDate + "' ";
		sSQL += " where RequestID = " + requestID.toString();
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int saveReceiveItem(HttpServletRequest request) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		Query query;
		String sSQL;
		sSQL = "update RequestImportItem set ";
		sSQL += " ReceiveNo = '" + request.getParameter("receiveNo") + "'";
		sSQL += " , ReceiveDate = '" + request.getParameter("receiveDate") + "'";
		sSQL += " , ReceiveBy = '" + request.getParameter("receiveBy") + "'";
		sSQL += " , ShippingNo = '" + request.getParameter("shippingNo") + "'";
		sSQL += " , ShippingDate = '" + request.getParameter("shippingDate") + "'";
		sSQL += " , ShippingID = " + request.getParameter("shippingBy");
		sSQL += " , DocumentTransfer = '" + request.getParameter("documentTransfer") + "'";
		sSQL += " , DocumentTransferDate = '" + request.getParameter("documentTransferDate") + "'";
		sSQL += " , CustomsCheckDate = '" + request.getParameter("customsCheckDate") + "'";
		sSQL += " , TaxImport = " + request.getParameter("taxImport");
		sSQL += " , VatAmount = " + request.getParameter("vatAmount");
		sSQL += " , TaxExcise = " + request.getParameter("taxExcise");
		sSQL += " , Vehicle = '" + request.getParameter("vehicle") + "'";
		sSQL += " , InDate = '" + request.getParameter("inDate") + "'";
		sSQL += " , QuantityPack = " + request.getParameter("quantityPack");
		sSQL += " , PortName = '" + request.getParameter("portName") + "'";
		sSQL += " , PortTerminal = '" + request.getParameter("portTerminal") + "'";
		sSQL += ", ModifiedDate = '" + sDate + "' ";
		sSQL += " where RequestID = " + request.getParameter("requestID");
		query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int transferItem(Long requestID) throws Exception {
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sSQL;
		sSQL = "update RequestImportItem set ";
		sSQL += " MoveStatus = 'Y' ";
		sSQL += ", MoveItemDate = '" + sDate + "' ";
		sSQL += ", ReceiveStatus = 'Completed Receive By Free Zone'";
		sSQL += ", RecordStatus = 'Completed By Free Zone'";
		sSQL += " where RequestID = " + requestID.toString();
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> searchByReceiveDate(String sStartDate, String sEndDate) throws Exception {
		List<RequestImportItem> requestImportList = this.getHibernateTemplate().find("from RequestImportItem where ReceiveDate >= '" + sStartDate + "' and ReceiveDate <= '" + sEndDate + "' order by ReceiveDate asc");
		return requestImportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> searchByTransferDate(String sStartDate, String sEndDate) throws Exception {
		List<RequestImportItem> requestImportList = this.getHibernateTemplate().find("from RequestImportItem where MoveStatus = 'Y' and MoveItemDate >= '" + sStartDate + "' and MoveItemDate <= '" + sEndDate + "' order by MoveItemDate asc");
		return requestImportList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItem> searchReport(HttpServletRequest request) throws Exception {
		String sStartDate = request.getParameter("receiveDateFrom");
		String sEndDate = request.getParameter("receiveDateTo");
		String sRequestType = request.getParameter("requestType");
		String sCountryName = request.getParameter("countryName");
		String sImportType = request.getParameter("importType");
		String sIndustryType = request.getParameter("industryType");
		
		if (sStartDate == null) sStartDate = "";
		if (sEndDate == null) sEndDate = "";
		if (sRequestType == null) sRequestType = "";
		if (sCountryName == null) sCountryName = "";
		if (sImportType == null) sImportType = "";
		if (sIndustryType == null) sIndustryType = "";
		
		String sSQL;
		sSQL = "from RequestImportItem where ReceiveDate >= '" + sStartDate + "' and ReceiveDate <= '" + sEndDate + "'";
		if (!sRequestType.equalsIgnoreCase("")) {
			sSQL += " and RequestType = '" + sRequestType + "' ";
		}
		if (!sCountryName.equalsIgnoreCase("")) {
			sSQL += " and CountryName = '" + sCountryName + "' ";
		}
		if (!sImportType.equalsIgnoreCase("")) {
			sSQL += " and ImportType = '" + sImportType + "' ";
		}
		if (!sIndustryType.equalsIgnoreCase("")) {
			sSQL += " and IndustryType = '" + sIndustryType + "' ";
		}
		sSQL	+= " order by RequestID asc ";
		
		List<RequestImportItem> requestImportList = this.getHibernateTemplate().find(sSQL);
		return requestImportList;
	}
}
