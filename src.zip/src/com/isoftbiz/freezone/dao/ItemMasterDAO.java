package com.isoftbiz.freezone.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.freezone.idao.IItemMasterDAO;

@Repository
public class ItemMasterDAO extends HibernateDaoSupport implements IItemMasterDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public ItemMaster findById(Long itemID) throws Exception {
		ItemMaster itemMaster = this.getHibernateTemplate().get(ItemMaster.class, itemID);
		return itemMaster;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ItemMaster findByItemCode(String itemCode) throws Exception {
		List itemMaster = this.getHibernateTemplate().find("from ItemMaster where ItemCode=?", itemCode);
		if (itemMaster.isEmpty()) {
			return null;
		} else {
			return (ItemMaster)itemMaster.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public ItemMaster findByItemCodeCompany(String itemCode, Long companyID) throws Exception {
		List itemMaster = this.getHibernateTemplate().find("from ItemMaster where ItemCode=? and CompanyID=?", itemCode, companyID);
		if (itemMaster.isEmpty()) {
			return null;
		} else {
			return (ItemMaster)itemMaster.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemMaster> findAll() throws Exception {
		List<ItemMaster> itemMasterList = session.createCriteria(ItemMaster.class).list();
		session.flush();
		session.clear();
		return itemMasterList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemMaster> listOfFreeZone() throws Exception {
		List<ItemMaster> itemMasterList = this.getHibernateTemplate().find("from ItemMaster where OwnerFreeZone = 'Y' order by ItemCode asc");
		return itemMasterList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ItemMaster> listOfCompany(Long companyID) throws Exception {
		List<ItemMaster> itemMasterList = this.getHibernateTemplate().find("from ItemMaster where OwnerFreeZone = 'N' and CompanyID = " + companyID.toString() + " order by ItemCode asc");
		return itemMasterList;
	}
	
	@Override
	public boolean save(ItemMaster itemMaster) throws Exception {
		this.getHibernateTemplate().save(itemMaster);
		return true;
	}

	@Override
	public boolean update(ItemMaster itemMaster) throws Exception {
		this.getHibernateTemplate().update(itemMaster);
		return true;
	}

	@Override
	public boolean delete(ItemMaster itemMaster) throws Exception {
		this.getHibernateTemplate().delete(itemMaster);
		return true;
	}
}
