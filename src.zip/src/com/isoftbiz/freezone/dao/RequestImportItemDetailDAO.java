package com.isoftbiz.freezone.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.idao.IRequestImportItemDetailDAO;
import com.isoftbiz.freezone.model.RequestImportItemDetail;

@Repository
public class RequestImportItemDetailDAO extends HibernateDaoSupport implements IRequestImportItemDetailDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public RequestImportItemDetail findById(Long requestDetailID) throws Exception {
		RequestImportItemDetail requestImportItemDetail = this.getHibernateTemplate().get(RequestImportItemDetail.class, requestDetailID);
		return requestImportItemDetail;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestImportItemDetail> findAll(Long requestID) throws Exception {
		List<RequestImportItemDetail> requestImportItemDetailList = this.getHibernateTemplate().find("from RequestImportItemDetail where RequestID=? order by RequestDetailID asc", requestID);
		return requestImportItemDetailList;
	}

	@Override
	public boolean save(RequestImportItemDetail requestImportItemDetail) throws Exception {
		this.getHibernateTemplate().save(requestImportItemDetail);
		String sBarcode;
		sBarcode = requestImportItemDetail.getBarcode() + "-" + requestImportItemDetail.getRequestDetailID().toString();
		Query query;
		String sSQL;
		sSQL = "update RequestImportItemDetail set ";
		sSQL += " Barcode = '" + sBarcode + "'";
		sSQL += " where RequestDetailID = " + requestImportItemDetail.getRequestDetailID().toString();
		query = session.createQuery(sSQL);
		query.executeUpdate();
		return true;
	}

	@Override
	public boolean update(RequestImportItemDetail requestImportItemDetail) throws Exception {
		this.getHibernateTemplate().update(requestImportItemDetail);
		return true;
	}

	@Override
	public boolean delete(RequestImportItemDetail requestImportItemDetail) throws Exception {
		this.getHibernateTemplate().delete(requestImportItemDetail);
		return true;
	}
	
	@Override
	public int saveReceiveItemDetail(HttpServletRequest request) throws Exception {
		String sSQL;
		sSQL = "update RequestImportItemDetail set ";
		sSQL += " QuantityReceiveFreeZone = " + request.getParameter("quantityReceiveFreeZone");
		sSQL += " , QuantityDamagedFreeZone = " + request.getParameter("quantityDamagedFreeZone");
		sSQL += " , WarehouseFreeZoneID = " + request.getParameter("warehouseFreeZone");
		sSQL += " , DamagedRemarkFreeZone = '" + request.getParameter("damagedRemarkFreeZone") + "'";
		sSQL += " , ReceiveStatus = '" + request.getParameter("receiveStatus") + "'";
		sSQL += " where RequestDetailID = " + request.getParameter("requestDetailID");
		Query query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int saveReceiveItemDetailByCompany(HttpServletRequest request) throws Exception {
		Query query;
		String sSQL;
		sSQL = "update RequestImportItemDetail set ";
		sSQL += " QuantityReceiveCompany = " + request.getParameter("quantityReceiveCompany");
		sSQL += " , QuantityDamagedCompany = " + request.getParameter("quantityDamagedCompany");
		sSQL += " , WarehouseCompanyID = " + request.getParameter("warehouseCompany");
		sSQL += " , DamagedRemarkCompany = '" + request.getParameter("damagedRemarkCompany") + "'";
		sSQL += " , ReceiveStatus = '" + request.getParameter("receiveStatus") + "'";
		sSQL += " where RequestDetailID = " + request.getParameter("requestDetailID");
		query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
}
