package com.isoftbiz.freezone.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.idao.IRequestExportItemDetailDAO;
import com.isoftbiz.freezone.model.RequestExportItemDetail;

@Repository
public class RequestExportItemDetailDAO extends HibernateDaoSupport implements IRequestExportItemDetailDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public RequestExportItemDetail findById(Long requestDetailID) throws Exception {
		RequestExportItemDetail requestExportItemDetail = this.getHibernateTemplate().get(RequestExportItemDetail.class, requestDetailID);
		return requestExportItemDetail;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestExportItemDetail> findAll(Long requestID) throws Exception {
		List<RequestExportItemDetail> requestExportItemDetailList = this.getHibernateTemplate().find("from RequestExportItemDetail where RequestID=? order by RequestDetailID asc", requestID);
		return requestExportItemDetailList;
	}

	@Override
	public boolean save(RequestExportItemDetail requestExportItemDetail) throws Exception {
		this.getHibernateTemplate().save(requestExportItemDetail);
		String sBarcode;
		sBarcode = requestExportItemDetail.getBarcode() + "-" + requestExportItemDetail.getRequestDetailID().toString();
		Query query;
		String sSQL;
		sSQL = "update RequestExportItemDetail set ";
		sSQL += " Barcode = '" + sBarcode + "'";
		sSQL += " where RequestDetailID = " + requestExportItemDetail.getRequestDetailID().toString();
		query = session.createQuery(sSQL);
		query.executeUpdate();
		return true;
	}

	@Override
	public boolean update(RequestExportItemDetail requestExportItemDetail) throws Exception {
		this.getHibernateTemplate().update(requestExportItemDetail);
		return true;
	}

	@Override
	public boolean delete(RequestExportItemDetail requestExportItemDetail) throws Exception {
		this.getHibernateTemplate().delete(requestExportItemDetail);
		return true;
	}
	
	@Override
	public int saveReceiveItemDetail(HttpServletRequest request) throws Exception {
		Query query;
		String sSQL;
		sSQL = "update RequestExportItemDetail set ";
		sSQL += " QuantityReceiveFreeZone = " + request.getParameter("quantityReceiveFreeZone");
		sSQL += " , QuantityDamagedFreeZone = " + request.getParameter("quantityDamagedFreeZone");
		sSQL += " , WarehouseFreeZoneID = " + request.getParameter("warehouseFreeZone");
		sSQL += " , DamagedRemarkFreeZone = '" + request.getParameter("damagedRemarkFreeZone") + "'";
		sSQL += " , ReceiveStatus = '" + request.getParameter("receiveStatus") + "'";
		sSQL += " where RequestDetailID = " + request.getParameter("requestDetailID");
		query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
	
	@Override
	public int saveReceiveItemDetailByCompany(HttpServletRequest request) throws Exception {
		Query query;
		String sSQL;
		sSQL = "update RequestExportItemDetail set ";
		sSQL += " QuantityReceiveCompany = " + request.getParameter("quantityReceiveCompany");
		sSQL += " , QuantityDamagedCompany = " + request.getParameter("quantityDamagedCompany");
		sSQL += " , WarehouseCompanyID = " + request.getParameter("warehouseCompany");
		sSQL += " , DamagedRemarkCompany = '" + request.getParameter("damagedRemarkCompany") + "'";
		sSQL += " , ReceiveStatus = '" + request.getParameter("receiveStatus") + "'";
		sSQL += " where RequestDetailID = " + request.getParameter("requestDetailID");
		query = session.createQuery(sSQL);
		int result = query.executeUpdate();
		return result;
	}
}
