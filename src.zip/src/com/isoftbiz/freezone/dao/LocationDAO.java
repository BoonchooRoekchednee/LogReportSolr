package com.isoftbiz.freezone.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.freezone.model.Location;
import com.isoftbiz.freezone.idao.ILocationDAO;

@Repository
public class LocationDAO extends HibernateDaoSupport implements ILocationDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public Location findById(Long locationID) throws Exception {
		Location location = this.getHibernateTemplate().get(Location.class, locationID);
		return location;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Location findByLocationCode(String locationCode) throws Exception {
		List location = this.getHibernateTemplate().find("from Location where LocationCode=?", locationCode);
		if (location.isEmpty()) {
			return null;
		} else {
			return (Location)location.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public Location findByLocationCodeCompany(String locationCode, Long companyID) throws Exception {
		List location = this.getHibernateTemplate().find("from Location where LocationCode=? and CompanyID=?", locationCode, companyID);
		if (location.isEmpty()) {
			return null;
		} else {
			return (Location)location.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Location> findAll() throws Exception {
		List<Location> locationList = session.createCriteria(Location.class).list();
		session.flush();
		session.clear();
		return locationList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Location> listOfFreeZone() throws Exception {
		List<Location> locationList = this.getHibernateTemplate().find("from Location where OwnerFreeZone = 'Y' order by LocationCode asc");
		return locationList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Location> listOfCompany(Long companyID) throws Exception {
		List<Location> locationList = this.getHibernateTemplate().find("from Location where OwnerFreeZone = 'N' and CompanyID = " + companyID.toString() + " order by LocationCode asc");
		return locationList;
	}
	
	@Override
	public boolean save(Location location) throws Exception {
		this.getHibernateTemplate().save(location);
		return true;
	}

	@Override
	public boolean update(Location location) throws Exception {
		this.getHibernateTemplate().update(location);
		return true;
	}

	@Override
	public boolean delete(Location location) throws Exception {
		this.getHibernateTemplate().delete(location);
		return true;
	}
}
