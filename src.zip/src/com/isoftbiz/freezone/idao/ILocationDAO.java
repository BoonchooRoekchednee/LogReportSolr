package com.isoftbiz.freezone.idao;

import java.util.List;

import com.isoftbiz.freezone.model.Location;

public interface ILocationDAO {
	public Location findById(Long locationID) throws Exception;
	
	public Location findByLocationCode(String locationCode) throws Exception;
	
	public Location findByLocationCodeCompany(String locationCode, Long companyID) throws Exception;

	public List<Location> findAll() throws Exception;
	
	public List<Location> listOfFreeZone() throws Exception;
	
	public List<Location> listOfCompany(Long companyID) throws Exception;

	public boolean save(Location location) throws Exception;

	public boolean update(Location location) throws Exception;

	public boolean delete(Location location) throws Exception;
}
