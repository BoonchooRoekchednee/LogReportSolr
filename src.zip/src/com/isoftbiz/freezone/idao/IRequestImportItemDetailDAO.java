package com.isoftbiz.freezone.idao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.isoftbiz.freezone.model.RequestImportItemDetail;

public interface IRequestImportItemDetailDAO {
	public RequestImportItemDetail findById(Long requestDetailID) throws Exception;
	
	public List<RequestImportItemDetail> findAll(Long requestID) throws Exception;

	public boolean save(RequestImportItemDetail requestImportItemDetail) throws Exception;

	public boolean update(RequestImportItemDetail requestImportItemDetail) throws Exception;

	public boolean delete(RequestImportItemDetail requestImportItemDetail) throws Exception;
	
	public int saveReceiveItemDetail(HttpServletRequest request) throws Exception;
	
	public int saveReceiveItemDetailByCompany(HttpServletRequest request) throws Exception;
}
