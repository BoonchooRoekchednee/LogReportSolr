package com.isoftbiz.freezone.idao;

import java.util.List;

import com.isoftbiz.freezone.model.ItemMaster;

public interface IItemMasterDAO {
	public ItemMaster findById(Long itemMasterID) throws Exception;
	
	public ItemMaster findByItemCode(String itemMasterCode) throws Exception;
	
	public ItemMaster findByItemCodeCompany(String itemMasterCode, Long companyID) throws Exception;

	public List<ItemMaster> findAll() throws Exception;
	
	public List<ItemMaster> listOfFreeZone() throws Exception;
	
	public List<ItemMaster> listOfCompany(Long companyID) throws Exception;

	public boolean save(ItemMaster itemMaster) throws Exception;

	public boolean update(ItemMaster itemMaster) throws Exception;

	public boolean delete(ItemMaster itemMaster) throws Exception;
}
