package com.isoftbiz.freezone.idao;

import java.util.List;

import com.isoftbiz.freezone.model.ItemGroup;

public interface IItemGroupDAO {
	public ItemGroup findById(Long itemGroupID) throws Exception;
	
	public ItemGroup findByItemGroupCode(String itemGroupCode) throws Exception;
	
	public ItemGroup findByItemGroupCodeCompany(String itemGroupCode, Long companyID) throws Exception;

	public List<ItemGroup> findAll() throws Exception;
	
	public List<ItemGroup> listOfFreeZone() throws Exception;
	
	public List<ItemGroup> listOfCompany(Long companyID) throws Exception;

	public boolean save(ItemGroup itemGroup) throws Exception;

	public boolean update(ItemGroup itemGroup) throws Exception;

	public boolean delete(ItemGroup itemGroup) throws Exception;
}
