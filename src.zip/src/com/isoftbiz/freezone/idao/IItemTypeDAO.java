package com.isoftbiz.freezone.idao;

import java.util.List;

import com.isoftbiz.freezone.model.ItemType;

public interface IItemTypeDAO {
	public ItemType findById(Long itemTypeID) throws Exception;
	
	public ItemType findByItemTypeCode(String itemTypeCode) throws Exception;

	public List<ItemType> findAll() throws Exception;

	public boolean save(ItemType itemType) throws Exception;

	public boolean update(ItemType itemType) throws Exception;

	public boolean delete(ItemType itemType) throws Exception;
}
