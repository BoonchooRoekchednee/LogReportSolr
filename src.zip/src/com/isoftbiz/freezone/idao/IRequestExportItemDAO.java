package com.isoftbiz.freezone.idao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.isoftbiz.freezone.model.RequestExportItem;

public interface IRequestExportItemDAO {
	public RequestExportItem findById(Long requestID) throws Exception;
	
	public RequestExportItem findByRequestCode(String requestCode) throws Exception;
	
	public RequestExportItem findByRequestCodeCompany(String requestCode, Long companyID) throws Exception;

	public List<RequestExportItem> findAll() throws Exception;
	
	public List<RequestExportItem> listOfFreeZone() throws Exception;
	
	public List<RequestExportItem> listOfCompany() throws Exception;
	
	public List<RequestExportItem> listOfCompany(Long companyID) throws Exception;

	public boolean save(RequestExportItem requestExportItem) throws Exception;

	public boolean update(RequestExportItem requestExportItem) throws Exception;

	public boolean delete(RequestExportItem requestExportItem) throws Exception;
	
	public int updateReceiveStatus(Long requestID, String status) throws Exception;
	
	public int updateRecordStatus(Long requestID, String status) throws Exception;
	
	public int saveReceiveItem(HttpServletRequest request) throws Exception;
	
	public int transferItem(Long requestID) throws Exception;
	
	public List<RequestExportItem> searchByReceiveDate(String sStartDate, String sEndDate) throws Exception;
	
	public List<RequestExportItem> searchReport(HttpServletRequest request) throws Exception;
}
