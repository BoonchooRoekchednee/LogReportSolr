package com.isoftbiz.freezone.idao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.isoftbiz.freezone.model.RequestImportItem;

public interface IRequestImportItemDAO {
	public RequestImportItem findById(Long requestID) throws Exception;
	
	public RequestImportItem findByRequestCode(String requestCode) throws Exception;
	
	public RequestImportItem findByRequestCodeCompany(String requestCode, Long companyID) throws Exception;

	public List<RequestImportItem> findAll() throws Exception;
	
	public List<RequestImportItem> listOfFreeZone() throws Exception;
	
	public List<RequestImportItem> listOfCompany() throws Exception;
	
	public List<RequestImportItem> listOfCompany(Long companyID) throws Exception;

	public boolean save(RequestImportItem requestImportItem) throws Exception;

	public boolean update(RequestImportItem requestImportItem) throws Exception;

	public boolean delete(RequestImportItem requestImportItem) throws Exception;
	
	public int updateReceiveStatus(Long requestID, String status) throws Exception;
	
	public int updateRecordStatus(Long requestID, String status) throws Exception;
	
	public int saveReceiveItem(HttpServletRequest request) throws Exception;
	
	public int transferItem(Long requestID) throws Exception;
	
	public List<RequestImportItem> searchByReceiveDate(String sStartDate, String sEndDate) throws Exception;
	
	public List<RequestImportItem> searchByTransferDate(String sStartDate, String sEndDate) throws Exception;
	
	public List<RequestImportItem> searchReport(HttpServletRequest request) throws Exception;
}
