package com.isoftbiz.production.idao;

import java.util.List;

import com.isoftbiz.production.model.ReceiveMaterial;

public interface IReceiveMaterialDAO {
	public ReceiveMaterial findById(Long receiveID) throws Exception;
	
	public ReceiveMaterial findByReceiveCodeCompany(String receiveCode, Long companyID) throws Exception;

	public List<ReceiveMaterial> listOfCompany(Long companyID) throws Exception;

	public boolean save(ReceiveMaterial receiveMaterial) throws Exception;

	public boolean update(ReceiveMaterial receiveMaterial) throws Exception;

	public boolean delete(ReceiveMaterial receiveMaterial) throws Exception;
}
