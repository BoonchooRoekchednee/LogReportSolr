package com.isoftbiz.production.idao;

import java.util.List;

import com.isoftbiz.production.model.IssueCase;

public interface IIssueCaseDAO {
	public IssueCase findById(Long issueCaseID) throws Exception;
	
	public IssueCase findByIssueCaseCode(String issueCaseCode) throws Exception;
	
	public IssueCase findByIssueCaseCodeCompany(String issueCaseCode, Long companyID) throws Exception;

	public List<IssueCase> findAll() throws Exception;
	
	public List<IssueCase> listOfCompany(Long companyID) throws Exception;

	public boolean save(IssueCase issueCase) throws Exception;

	public boolean update(IssueCase issueCase) throws Exception;

	public boolean delete(IssueCase issueCase) throws Exception;
}
