package com.isoftbiz.production.idao;

import java.util.List;

import com.isoftbiz.production.model.ReceiveMaterialDetail;

public interface IReceiveMaterialDetailDAO {
	public ReceiveMaterialDetail findById(Long receiveDetailID) throws Exception;
	
	public List<ReceiveMaterialDetail> findAll(Long receiveID) throws Exception;

	public boolean save(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception;

	public boolean update(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception;

	public boolean delete(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception;
}
