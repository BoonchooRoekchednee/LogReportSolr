package com.isoftbiz.production.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.production.iservice.IIssueCaseService;
import com.isoftbiz.production.model.IssueCase;

@Controller
public class IssueCaseController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IIssueCaseService issueCaseService;
	
	@RequestMapping(value = "/IssueCase.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<IssueCase> issueCaseList = null;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				issueCaseList = new HashSet<IssueCase>(issueCaseService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Warning!");
				mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
				mav.setViewName("Info");
			} else {
				issueCaseList = new HashSet<IssueCase>(issueCaseService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("issueCaseList", issueCaseList);
			mav.setViewName("IssueCase");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/IssueCaseNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Warning!");
				mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
				mav.setViewName("Info");
			} else {
				mav.setViewName("IssueCaseNew");
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/IssueCaseEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			IssueCase issueCase = issueCaseService.findById(id);
			if (issueCase == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL")) 
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(issueCase.getCompany().getCompanyID())))) {
					mav.addObject("issueCase", issueCase);
					mav.setViewName("IssueCaseEdit");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/IssueCaseSave.isoftbiz", method = RequestMethod.POST)
	public String save(IssueCase issueCase, ModelMap model) {
		try {
			IssueCase issueCaseCheck = issueCaseService.findByIssueCaseCodeCompany(issueCase.getIssueCaseCode(), issueCase.getCompany().getCompanyID());
			if (issueCaseCheck == null) {
				issueCaseService.save(issueCase);
				return "redirect:/IssueCase.isoftbiz";
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/IssueCaseUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(IssueCase issueCase) {
		try {
			issueCaseService.update(issueCase);
			return "redirect:/IssueCase.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/IssueCaseDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			IssueCase issueCase = issueCaseService.findById(id);
			issueCaseService.delete(issueCase);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
