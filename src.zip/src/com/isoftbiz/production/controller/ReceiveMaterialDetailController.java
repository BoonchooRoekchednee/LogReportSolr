package com.isoftbiz.production.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.freezone.iservice.IItemMasterService;
import com.isoftbiz.freezone.iservice.ILocationService;
import com.isoftbiz.production.iservice.IReceiveMaterialDetailService;
import com.isoftbiz.production.iservice.IReceiveMaterialService;
import com.isoftbiz.setupdata.iservice.IUnitService;

@Controller
public class ReceiveMaterialDetailController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IReceiveMaterialService receiveMaterialService;
	
	@Autowired
	private IReceiveMaterialDetailService receiveMaterialDetailService;
	
	@Autowired
	private IItemMasterService itemMasterService;
	
	@Autowired
	private IUnitService unitService;
	
	@Autowired
	private ILocationService locationService;
	
}
