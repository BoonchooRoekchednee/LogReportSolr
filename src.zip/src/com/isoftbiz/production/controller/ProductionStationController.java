package com.isoftbiz.production.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.production.iservice.IProductionStationService;
import com.isoftbiz.production.model.ProductionStation;

@Controller
public class ProductionStationController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IProductionStationService productionStationService;
	
	@RequestMapping(value = "/ProductionStation.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<ProductionStation> productionStationList = null;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("ALL")) {
				productionStationList = new HashSet<ProductionStation>(productionStationService.findAll());
			} else if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Warning!");
				mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
				mav.setViewName("Info");
			} else {
				productionStationList = new HashSet<ProductionStation>(productionStationService.listOfCompany(userLogin.getCompany().getCompanyID()));
			}
			mav.addObject("userLogin", userLogin);
			mav.addObject("productionStationList", productionStationList);
			mav.setViewName("ProductionStation");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ProductionStationNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			if (userLogin.getRole().getRoleType().equalsIgnoreCase("184")) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Warning!");
				mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
				mav.setViewName("Info");
			} else {
				mav.setViewName("ProductionStationNew");
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ProductionStationEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			ProductionStation productionStation = productionStationService.findById(id);
			if (productionStation == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				String sRole = userLogin.getRole().getRoleType();
				if ((sRole.equalsIgnoreCase("ALL")) 
						|| (sRole.equalsIgnoreCase("185") && (userLogin.getCompany().getCompanyID().equals(productionStation.getCompany().getCompanyID())))) {
					mav.addObject("productionStation", productionStation);
					mav.setViewName("ProductionStationEdit");
				} else {
					mav.addObject("message", "Sorry <u>" + userName + "</u> You don't have privileges to access this program.");
					mav.setViewName("403");
				}
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ProductionStationSave.isoftbiz", method = RequestMethod.POST)
	public String save(ProductionStation productionStation, ModelMap model) {
		try {
			ProductionStation productionStationCheck = productionStationService.findByStationCodeCompany(productionStation.getStationCode(), productionStation.getCompany().getCompanyID());
			if (productionStationCheck == null) {
				productionStationService.save(productionStation);
				return "redirect:/ProductionStation.isoftbiz";
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				String userName = auth.getName();
				User userLogin = userService.findByUserCode(userName);
				model.addAttribute("userLogin", userLogin);
				model.addAttribute("message", "Duplicate data.");
				return "DuplicateData";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/ProductionStationUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(ProductionStation productionStation) {
		try {
			productionStationService.update(productionStation);
			return "redirect:/ProductionStation.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/ProductionStationDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			ProductionStation productionStation = productionStationService.findById(id);
			productionStationService.delete(productionStation);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
