package com.isoftbiz.production.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.production.iservice.IReceiveMaterialDetailService;
import com.isoftbiz.production.iservice.IReceiveMaterialService;
import com.isoftbiz.production.model.ReceiveMaterial;
import com.isoftbiz.production.model.ReceiveMaterialDetail;

@Controller
public class ReceiveMaterialController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IReceiveMaterialService receiveMaterialService;
	
	@Autowired
	private IReceiveMaterialDetailService receiveMaterialDetailService;
	
	@RequestMapping(value = "/ReceiveMaterial.isoftbiz")
	public ModelAndView index() {
		try {
			ModelAndView mav = new ModelAndView();
			Set<ReceiveMaterial> receiveMaterialList;
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			receiveMaterialList = new HashSet<ReceiveMaterial>(receiveMaterialService.listOfCompany(userLogin.getCompany().getCompanyID()));
			mav.addObject("userLogin", userLogin);
			mav.addObject("receiveMaterialList", receiveMaterialList);
			mav.addObject("titleShow", "Receive Material Of " + userLogin.getCompany().getCompanyName());
			mav.setViewName("ReceiveMaterial");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReceiveMaterialNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("ReceiveMaterialNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReceiveMaterialEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			ReceiveMaterial receiveMaterial = receiveMaterialService.findById(id);
			if (receiveMaterial == null) {
				mav.addObject("classValue", "alert-warning");
				mav.addObject("headerValue","Information!");
				mav.addObject("message", "Not found data.");
				mav.setViewName("Info");
			} else {
				mav.addObject("receiveMaterial", receiveMaterial);
				Set<ReceiveMaterialDetail> receiveMaterialDetailList = new HashSet<ReceiveMaterialDetail>(receiveMaterialDetailService.findAll(id));
				mav.addObject("receiveMaterialDetailList", receiveMaterialDetailList);
				mav.setViewName("ReceiveMaterialEdit");
			}
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/ReceiveMaterialSave.isoftbiz", method = RequestMethod.POST)
	public String save(ReceiveMaterial receiveMaterial) {
		try {
			receiveMaterialService.save(receiveMaterial);
			return "redirect:/ReceiveMaterial.isoftbiz";
			//return "redirect:/ReceiveMaterialEdit.isoftbiz?id=" + receiveMaterial.getRequestID();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		Locale lc = new java.util.Locale("en","EN");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", lc);
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
