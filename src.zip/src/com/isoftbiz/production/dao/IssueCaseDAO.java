package com.isoftbiz.production.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.production.model.IssueCase;
import com.isoftbiz.production.idao.IIssueCaseDAO;

@Repository
public class IssueCaseDAO extends HibernateDaoSupport implements IIssueCaseDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public IssueCase findById(Long issueCaseID) throws Exception {
		IssueCase issueCase = this.getHibernateTemplate().get(IssueCase.class, issueCaseID);
		return issueCase;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public IssueCase findByIssueCaseCode(String issueCaseCode) throws Exception {
		List issueCase = this.getHibernateTemplate().find("from IssueCase where IssueCaseCode=?", issueCaseCode);
		if (issueCase.isEmpty()) {
			return null;
		} else {
			return (IssueCase)issueCase.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public IssueCase findByIssueCaseCodeCompany(String issueCaseCode, Long companyID) throws Exception {
		List issueCase = this.getHibernateTemplate().find("from IssueCase where IssueCaseCode=? and CompanyID=?", issueCaseCode, companyID);
		if (issueCase.isEmpty()) {
			return null;
		} else {
			return (IssueCase)issueCase.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<IssueCase> findAll() throws Exception {
		List<IssueCase> issueCaseList = session.createCriteria(IssueCase.class).list();
		session.flush();
		session.clear();
		return issueCaseList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<IssueCase> listOfCompany(Long companyID) throws Exception {
		List<IssueCase> issueCaseList = this.getHibernateTemplate().find("from IssueCase where CompanyID = " + companyID.toString() + " order by IssueCaseCode asc");
		return issueCaseList;
	}
	
	@Override
	public boolean save(IssueCase issueCase) throws Exception {
		this.getHibernateTemplate().save(issueCase);
		return true;
	}

	@Override
	public boolean update(IssueCase issueCase) throws Exception {
		this.getHibernateTemplate().update(issueCase);
		return true;
	}

	@Override
	public boolean delete(IssueCase issueCase) throws Exception {
		this.getHibernateTemplate().delete(issueCase);
		return true;
	}
}
