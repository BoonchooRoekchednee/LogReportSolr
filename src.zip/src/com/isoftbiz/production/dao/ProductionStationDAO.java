package com.isoftbiz.production.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.production.model.ProductionStation;
import com.isoftbiz.production.idao.IProductionStationDAO;

@Repository
public class ProductionStationDAO extends HibernateDaoSupport implements IProductionStationDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public ProductionStation findById(Long stationID) throws Exception {
		ProductionStation productionStation = this.getHibernateTemplate().get(ProductionStation.class, stationID);
		return productionStation;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ProductionStation findByStationCode(String stationCode) throws Exception {
		List productionStation = this.getHibernateTemplate().find("from ProductionStation where StationCode=?", stationCode);
		if (productionStation.isEmpty()) {
			return null;
		} else {
			return (ProductionStation)productionStation.get(0);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public ProductionStation findByStationCodeCompany(String stationCode, Long companyID) throws Exception {
		List productionStation = this.getHibernateTemplate().find("from ProductionStation where StationCode=? and CompanyID=?", stationCode, companyID);
		if (productionStation.isEmpty()) {
			return null;
		} else {
			return (ProductionStation)productionStation.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductionStation> findAll() throws Exception {
		List<ProductionStation> productionStationList = session.createCriteria(ProductionStation.class).list();
		session.flush();
		session.clear();
		return productionStationList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ProductionStation> listOfCompany(Long companyID) throws Exception {
		List<ProductionStation> productionStationList = this.getHibernateTemplate().find("from ProductionStation where CompanyID = " + companyID.toString() + " order by StationCode asc");
		return productionStationList;
	}
	
	@Override
	public boolean save(ProductionStation productionStation) throws Exception {
		this.getHibernateTemplate().save(productionStation);
		return true;
	}

	@Override
	public boolean update(ProductionStation productionStation) throws Exception {
		this.getHibernateTemplate().update(productionStation);
		return true;
	}

	@Override
	public boolean delete(ProductionStation productionStation) throws Exception {
		this.getHibernateTemplate().delete(productionStation);
		return true;
	}
}
