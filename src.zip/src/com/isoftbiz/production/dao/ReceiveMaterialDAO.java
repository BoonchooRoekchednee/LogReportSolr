package com.isoftbiz.production.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.production.idao.IReceiveMaterialDAO;
import com.isoftbiz.production.model.ReceiveMaterial;

@Repository
public class ReceiveMaterialDAO extends HibernateDaoSupport implements IReceiveMaterialDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public ReceiveMaterial findById(Long requestID) throws Exception {
		ReceiveMaterial receiveMaterial = this.getHibernateTemplate().get(ReceiveMaterial.class, requestID);
		return receiveMaterial;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public ReceiveMaterial findByReceiveCodeCompany(String requestCode, Long companyID) throws Exception {
		List receiveMaterial = this.getHibernateTemplate().find("from ReceiveMaterial where ReceiveCode=? and CompanyID=?", requestCode, companyID);
		if (receiveMaterial.isEmpty()) {
			return null;
		} else {
			return (ReceiveMaterial)receiveMaterial.get(0);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ReceiveMaterial> listOfCompany(Long companyID) throws Exception {
		List<ReceiveMaterial> receiveMaterialList = this.getHibernateTemplate().find("from ReceiveMaterial where CompanyID = " + companyID.toString() + " order by ReceiveID desc");
		return receiveMaterialList;
	}
	
	@Override
	public boolean save(ReceiveMaterial receiveMaterial) throws Exception {
		this.getHibernateTemplate().save(receiveMaterial);
		ReceiveMaterial receiveMaterialItem = this.findById(receiveMaterial.getReceiveID());
		Locale lc = new java.util.Locale("en","EN");
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", lc);
		Date date = new Date();
		String sDate = dateFormat.format(date);
		String sBarcode;
		sBarcode = receiveMaterialItem.getCompany().getCompanyCode() + "-RCV-RM-" + receiveMaterial.getReceiveID().toString();
		Query query;
		String sSQL;
		sSQL = "update ReceiveMaterial set ";
		sSQL += " ReceiveCode = '" + sBarcode + "'";
		sSQL += ", Barcode = '" + sBarcode + "'";
		sSQL += ", CreatedDate = '" + sDate + "' ";
		sSQL += " where ReceiveID = " + receiveMaterial.getReceiveID().toString();
		query = session.createQuery(sSQL);
		query.executeUpdate();
		return true;
	}

	@Override
	public boolean update(ReceiveMaterial receiveMaterial) throws Exception {
		this.getHibernateTemplate().update(receiveMaterial);
		return true;
	}

	@Override
	public boolean delete(ReceiveMaterial receiveMaterial) throws Exception {
		this.getHibernateTemplate().delete(receiveMaterial);
		return true;
	}
}
