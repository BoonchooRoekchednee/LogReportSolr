package com.isoftbiz.production.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.production.idao.IReceiveMaterialDetailDAO;
import com.isoftbiz.production.model.ReceiveMaterialDetail;

@Repository
public class ReceiveMaterialDetailDAO extends HibernateDaoSupport implements IReceiveMaterialDetailDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public ReceiveMaterialDetail findById(Long receiveDetailID) throws Exception {
		ReceiveMaterialDetail receiveMaterialDetail = this.getHibernateTemplate().get(ReceiveMaterialDetail.class, receiveDetailID);
		return receiveMaterialDetail;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ReceiveMaterialDetail> findAll(Long receiveID) throws Exception {
		List<ReceiveMaterialDetail> ReceiveMaterialDetailList = this.getHibernateTemplate().find("from ReceiveMaterialDetail where ReceiveID=? order by receiveDetailID asc", receiveID);
		return ReceiveMaterialDetailList;
	}

	@Override
	public boolean save(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception {
		this.getHibernateTemplate().save(ReceiveMaterialDetail);
		return true;
	}

	@Override
	public boolean update(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception {
		this.getHibernateTemplate().update(ReceiveMaterialDetail);
		return true;
	}

	@Override
	public boolean delete(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception {
		this.getHibernateTemplate().delete(ReceiveMaterialDetail);
		return true;
	}
}
