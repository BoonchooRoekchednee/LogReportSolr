package com.isoftbiz.production.iservice;

import java.util.List;

import com.isoftbiz.production.model.ProductionStation;

public interface IProductionStationService {
	public ProductionStation findById(Long stationID) throws Exception;

	public ProductionStation findByStationCode(String stationCode) throws Exception;
	
	public ProductionStation findByStationCodeCompany(String stationCode, Long companyID) throws Exception;

	public List<ProductionStation> findAll() throws Exception;
	
	public List<ProductionStation> listOfCompany(Long companyID) throws Exception;

	public boolean save(ProductionStation productionStation) throws Exception;

	public boolean update(ProductionStation productionStation) throws Exception;

	public boolean delete(ProductionStation productionStation) throws Exception;
}
