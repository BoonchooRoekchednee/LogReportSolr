package com.isoftbiz.production.iservice;

import java.util.List;

import com.isoftbiz.production.model.ReceiveMaterialDetail;

public interface IReceiveMaterialDetailService {
	public ReceiveMaterialDetail findById(Long receiveDetailID) throws Exception;
	
	public List<ReceiveMaterialDetail> findAll(Long receiveID) throws Exception;

	public boolean save(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception;

	public boolean update(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception;

	public boolean delete(ReceiveMaterialDetail ReceiveMaterialDetail) throws Exception;
}
