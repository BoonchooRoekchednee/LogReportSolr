package com.isoftbiz.production.iservice;

import java.util.List;

import com.isoftbiz.production.model.ReceiveMaterial;

public interface IReceiveMaterialService {
	public ReceiveMaterial findById(Long receiveID) throws Exception;
	
	public ReceiveMaterial findByReceiveCodeCompany(String receiveCode, Long companyID) throws Exception;

	public List<ReceiveMaterial> listOfCompany(Long companyID) throws Exception;

	public boolean save(ReceiveMaterial receiveMaterial) throws Exception;

	public boolean update(ReceiveMaterial receiveMaterial) throws Exception;

	public boolean delete(ReceiveMaterial receiveMaterial) throws Exception;
}
