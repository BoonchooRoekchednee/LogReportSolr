package com.isoftbiz.production.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.production.idao.IIssueCaseDAO;
import com.isoftbiz.production.model.IssueCase;
import com.isoftbiz.production.iservice.IIssueCaseService;

@Service
@Transactional
public class IssueCaseService implements IIssueCaseService {
	@Autowired
	private IIssueCaseDAO issueCaseDAO;

	@Override
	public IssueCase findById(Long issueCaseID) throws Exception {
		return issueCaseDAO.findById(issueCaseID);
	}
	
	@Override
	public IssueCase findByIssueCaseCode(String issueCaseCode) throws Exception {
		return issueCaseDAO.findByIssueCaseCode(issueCaseCode);
	}
	
	@Override
	public IssueCase findByIssueCaseCodeCompany(String issueCaseCode, Long companyID) throws Exception {
		return issueCaseDAO.findByIssueCaseCodeCompany(issueCaseCode, companyID);
	}
	
	@Override
	public List<IssueCase> findAll() throws Exception {
		return issueCaseDAO.findAll();
	}
	
	@Override
	public List<IssueCase> listOfCompany(Long companyID) throws Exception {
		return issueCaseDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(IssueCase issueCase) throws Exception {
		return issueCaseDAO.save(issueCase);
	}

	@Override
	public boolean update(IssueCase issueCase) throws Exception {
		return issueCaseDAO.update(issueCase);
	}

	@Override
	public boolean delete(IssueCase issueCase) throws Exception {
		return issueCaseDAO.delete(issueCase);
	}
}
