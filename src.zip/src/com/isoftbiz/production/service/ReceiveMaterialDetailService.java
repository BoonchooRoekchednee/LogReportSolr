package com.isoftbiz.production.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.production.idao.IReceiveMaterialDetailDAO;
import com.isoftbiz.production.iservice.IReceiveMaterialDetailService;
import com.isoftbiz.production.model.ReceiveMaterialDetail;

@Service
@Transactional
public class ReceiveMaterialDetailService implements  IReceiveMaterialDetailService {
	@Autowired
	private IReceiveMaterialDetailDAO receiveMaterialDetailDAO;
	
	@Override
	public ReceiveMaterialDetail findById(Long receiveDetailID) throws Exception {
		return receiveMaterialDetailDAO.findById(receiveDetailID);
	}

	@Override
	public List<ReceiveMaterialDetail> findAll(Long receiveID) throws Exception {
		return receiveMaterialDetailDAO.findAll(receiveID);
	}

	@Override
	public boolean save(ReceiveMaterialDetail receiveMaterialDetail) throws Exception {
		return receiveMaterialDetailDAO.save(receiveMaterialDetail);
	}

	@Override
	public boolean update(ReceiveMaterialDetail receiveMaterialDetail) throws Exception {
		return receiveMaterialDetailDAO.update(receiveMaterialDetail);
	}

	@Override
	public boolean delete(ReceiveMaterialDetail receiveMaterialDetail) throws Exception {
		return receiveMaterialDetailDAO.delete(receiveMaterialDetail);
	}
}
