package com.isoftbiz.production.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.production.idao.IReceiveMaterialDAO;
import com.isoftbiz.production.iservice.IReceiveMaterialService;
import com.isoftbiz.production.model.ReceiveMaterial;

@Service
@Transactional
public class ReceiveMaterialService implements IReceiveMaterialService {
	@Autowired
	private IReceiveMaterialDAO receiveMaterialDAO;

	@Override
	public ReceiveMaterial findById(Long receiveID) throws Exception {
		return receiveMaterialDAO.findById(receiveID);
	}
	
	@Override
	public ReceiveMaterial findByReceiveCodeCompany(String receiveCode, Long companyID) throws Exception {
		return receiveMaterialDAO.findByReceiveCodeCompany(receiveCode, companyID);
	}
	
	@Override
	public List<ReceiveMaterial> listOfCompany(Long companyID) throws Exception {
		return receiveMaterialDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(ReceiveMaterial receiveMaterial) throws Exception {
		return receiveMaterialDAO.save(receiveMaterial);
	}

	@Override
	public boolean update(ReceiveMaterial receiveMaterial) throws Exception {
		return receiveMaterialDAO.update(receiveMaterial);
	}

	@Override
	public boolean delete(ReceiveMaterial receiveMaterial) throws Exception {
		return receiveMaterialDAO.delete(receiveMaterial);
	}
}
