package com.isoftbiz.production.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.production.idao.IProductionStationDAO;
import com.isoftbiz.production.model.ProductionStation;
import com.isoftbiz.production.iservice.IProductionStationService;

@Service
@Transactional
public class ProductionStationService implements IProductionStationService {
	@Autowired
	private IProductionStationDAO productionStationDAO;

	@Override
	public ProductionStation findById(Long stationID) throws Exception {
		return productionStationDAO.findById(stationID);
	}
	
	@Override
	public ProductionStation findByStationCode(String stationCode) throws Exception {
		return productionStationDAO.findByStationCode(stationCode);
	}
	
	@Override
	public ProductionStation findByStationCodeCompany(String stationCode, Long companyID) throws Exception {
		return productionStationDAO.findByStationCodeCompany(stationCode, companyID);
	}
	
	@Override
	public List<ProductionStation> findAll() throws Exception {
		return productionStationDAO.findAll();
	}
	
	@Override
	public List<ProductionStation> listOfCompany(Long companyID) throws Exception {
		return productionStationDAO.listOfCompany(companyID);
	}
	
	@Override
	public boolean save(ProductionStation productionStation) throws Exception {
		return productionStationDAO.save(productionStation);
	}

	@Override
	public boolean update(ProductionStation productionStation) throws Exception {
		return productionStationDAO.update(productionStation);
	}

	@Override
	public boolean delete(ProductionStation productionStation) throws Exception {
		return productionStationDAO.delete(productionStation);
	}
}
