package com.isoftbiz.production.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RoutingDetail")
public class RoutingDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RoutingDetailID")
	private Long routingDetailID;
	
	@ManyToOne
	@JoinColumn(name = "RoutingID", nullable = false)
	private Routing routing;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "StationID", nullable = true)
	private ProductionStation productionStation;

	public Long getRoutingDetailID() {
		return routingDetailID;
	}

	public void setRoutingDetailID(Long routingDetailID) {
		this.routingDetailID = routingDetailID;
	}

	public Routing getRouting() {
		return routing;
	}

	public void setRouting(Routing routing) {
		this.routing = routing;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ProductionStation getProductionStation() {
		return productionStation;
	}

	public void setProductionStation(ProductionStation productionStation) {
		this.productionStation = productionStation;
	}
}
