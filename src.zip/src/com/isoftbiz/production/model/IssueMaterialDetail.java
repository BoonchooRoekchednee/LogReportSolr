package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.freezone.model.Location;
import com.isoftbiz.production.model.IssueMaterial;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "IssueMaterialDetail")
public class IssueMaterialDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IssueDetailID")
	private Long issueDetailID;
	
	@ManyToOne
	@JoinColumn(name = "IssueID", nullable = false)
	private IssueMaterial issueMaterial;
	
	@ManyToOne
	@JoinColumn(name = "StockID", nullable = true)
	private MaterialStockMovement materialStockMovement;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "LotNo", length = 32)
	private String lotNo;
	
	@Column(name = "MfgDate")
	@Type(type = "date")
	private Date mfgDate;
	
	@Column(name = "ExpDate")
	@Type(type = "date")
	private Date expDate;
	
	@Column(name = "IssueQuantity", columnDefinition = "Decimal(14,4)")
	private Double issueQuantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;
	
	@Column(name = "UnitPrice", columnDefinition = "Decimal(14,4)")
	private Double unitPrice;
	
	@Column(name = "IssueStatus", length = 32)
	private String issueStatus;
	
	@ManyToOne
	@JoinColumn(name = "LocationID", nullable = true)
	private Location location;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	public Long getIssueDetailID() {
		return issueDetailID;
	}

	public void setIssueDetailID(Long issueDetailID) {
		this.issueDetailID = issueDetailID;
	}

	public IssueMaterial getIssueMaterial() {
		return issueMaterial;
	}

	public void setIssueMaterial(IssueMaterial issueMaterial) {
		this.issueMaterial = issueMaterial;
	}

	public MaterialStockMovement getMaterialStockMovement() {
		return materialStockMovement;
	}

	public void setMaterialStockMovement(MaterialStockMovement materialStockMovement) {
		this.materialStockMovement = materialStockMovement;
	}

	public ItemMaster getItemMaster() {
		return itemMaster;
	}

	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}

	public String getLotNo() {
		return lotNo;
	}

	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}

	public Date getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	
	public Double getIssueQuantity() {
		return issueQuantity;
	}

	public void setIssueQuantity(Double issueQuantity) {
		this.issueQuantity = issueQuantity;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getIssueStatus() {
		return issueStatus;
	}

	public void setIssueStatus(String issueStatus) {
		this.issueStatus = issueStatus;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
