package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "ProductionDetail")
public class ProductionDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProductionDetailID")
	private Long productionDetailID;
	
	@Column(name = "ProductionDetailCode", length = 32, nullable = true)
	private String productionDetailCode;
	
	@Column(name = "TrackingNo", length = 32, nullable = true)
	private String trackingNo;
	
	@Column(name = "RefNo", length = 32, nullable = true)
	private String refNo;
	
	@Column(name = "VinNo", length = 32, nullable = true)
	private String vinNo;
	
	@Column(name = "EngineNo", length = 32, nullable = true)
	private String engineNo;
	
	@Column(name = "BodyNo", length = 32, nullable = true)
	private String bodyNo;
	
	@ManyToOne
	@JoinColumn(name = "ProductionID", nullable = false)
	private Production production;
	
	@ManyToOne
	@JoinColumn(name = "StationID", nullable = true)
	private ProductionStation productionStation;
	
	@Column(name = "StartDate")
	@Type(type = "date")
	private Date startDate;
	
	@Column(name = "EndDate")
	@Type(type = "date")
	private Date endDate;
	
	@Column(name = "ProductionStatus", length = 32)
	private String productionStatus;
	
	@Column(name = "productionStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date productionStatusDate;

	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	
	public Long getProductionDetailID() {
		return productionDetailID;
	}

	public void setProductionDetailID(Long productionDetailID) {
		this.productionDetailID = productionDetailID;
	}

	public String getProductionDetailCode() {
		return productionDetailCode;
	}

	public void setProductionDetailCode(String productionDetailCode) {
		this.productionDetailCode = productionDetailCode;
	}

	public String getTrackingNo() {
		return trackingNo;
	}

	public void setTrackingNo(String trackingNo) {
		this.trackingNo = trackingNo;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getVinNo() {
		return vinNo;
	}

	public void setVinNo(String vinNo) {
		this.vinNo = vinNo;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getBodyNo() {
		return bodyNo;
	}

	public void setBodyNo(String bodyNo) {
		this.bodyNo = bodyNo;
	}

	public Production getProduction() {
		return production;
	}

	public void setProduction(Production production) {
		this.production = production;
	}

	public ProductionStation getProductionStation() {
		return productionStation;
	}

	public void setProductionStation(ProductionStation productionStation) {
		this.productionStation = productionStation;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getProductionStatus() {
		return productionStatus;
	}

	public void setProductionStatus(String productionStatus) {
		this.productionStatus = productionStatus;
	}

	public Date getProductionStatusDate() {
		return productionStatusDate;
	}

	public void setProductionStatusDate(Date productionStatusDate) {
		this.productionStatusDate = productionStatusDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
