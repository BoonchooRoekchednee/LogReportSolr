package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;
import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "Production", uniqueConstraints = @UniqueConstraint(columnNames = {"ProductionCode", "CompanyID"}))
public class Production {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProductionID")
	private Long productionID;
	
	@Column(name = "ProductionCode", length = 32, nullable = false)
	private String productionCode;
	
	@Column(name = "ProductionDate")
	@Type(type = "date")
	private Date productionDate;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@Column(name = "LotNo", length = 32)
	private String lotNo;
	
	@Column(name = "ProductionQuantity", columnDefinition = "Decimal(14,4)")
	private Double productionQuantity;
	
	@Column(name = "FinishedQuantity", columnDefinition = "Decimal(14,4)")
	private Double finishedQuantity;
	
	@Column(name = "DamagedQuantity", columnDefinition = "Decimal(14,4)")
	private Double damagedQuantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;
	
	@ManyToOne
	@JoinColumn(name = "BOMID", nullable = false)
	private BillOfMaterial billOfMaterial;
	
	@ManyToOne
	@JoinColumn(name = "RoutingID", nullable = false)
	private Routing routing;
	
	@Column(name = "StartDate")
	@Type(type = "date")
	private Date startDate;
	
	@Column(name = "EndDate")
	@Type(type = "date")
	private Date endDate;
	
	@Column(name = "RefDoc", length = 32)
	private String refDoc;
	
	@Column(name = "RefDocDate")
	@Type(type = "date")
	private Date refDocDate;
	
	@Column(name = "Barcode", length = 32, nullable = true)
	private String barcode;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "ProductionStatus", length = 32)
	private String productionStatus;
	
	@Column(name = "productionStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date productionStatusDate;
	
	@Column(name = "RecordStatus", length = 32)
	private String recordStatus;
	
	@Column(name = "RecordStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date recordStatusDate;
	
	@Column(name = "GenerateDetail", length = 1)
	private String generateDetail;
	
	@Column(name = "remark", length = 255)
	private String remark;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getProductionID() {
		return productionID;
	}

	public void setProductionID(Long productionID) {
		this.productionID = productionID;
	}

	public String getProductionCode() {
		return productionCode;
	}

	public void setProductionCode(String productionCode) {
		this.productionCode = productionCode;
	}

	public Date getProductionDate() {
		return productionDate;
	}

	public void setProductionDate(Date productionDate) {
		this.productionDate = productionDate;
	}

	public ItemMaster getItemMaster() {
		return itemMaster;
	}

	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLotNo() {
		return lotNo;
	}

	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}

	public Double getProductionQuantity() {
		return productionQuantity;
	}

	public void setProductionQuantity(Double productionQuantity) {
		this.productionQuantity = productionQuantity;
	}

	public Double getFinishedQuantity() {
		return finishedQuantity;
	}

	public void setFinishedQuantity(Double finishedQuantity) {
		this.finishedQuantity = finishedQuantity;
	}

	public Double getDamagedQuantity() {
		return damagedQuantity;
	}

	public void setDamagedQuantity(Double damagedQuantity) {
		this.damagedQuantity = damagedQuantity;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public BillOfMaterial getBillOfMaterial() {
		return billOfMaterial;
	}

	public void setBillOfMaterial(BillOfMaterial billOfMaterial) {
		this.billOfMaterial = billOfMaterial;
	}

	public Routing getRouting() {
		return routing;
	}

	public void setRouting(Routing routing) {
		this.routing = routing;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getRefDoc() {
		return refDoc;
	}

	public void setRefDoc(String refDoc) {
		this.refDoc = refDoc;
	}

	public Date getRefDocDate() {
		return refDocDate;
	}

	public void setRefDocDate(Date refDocDate) {
		this.refDocDate = refDocDate;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getProductionStatus() {
		return productionStatus;
	}

	public void setProductionStatus(String productionStatus) {
		this.productionStatus = productionStatus;
	}

	public Date getProductionStatusDate() {
		return productionStatusDate;
	}

	public void setProductionStatusDate(Date productionStatusDate) {
		this.productionStatusDate = productionStatusDate;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Date getRecordStatusDate() {
		return recordStatusDate;
	}

	public void setRecordStatusDate(Date recordStatusDate) {
		this.recordStatusDate = recordStatusDate;
	}

	public String getGenerateDetail() {
		return generateDetail;
	}

	public void setGenerateDetail(String generateDetail) {
		this.generateDetail = generateDetail;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
