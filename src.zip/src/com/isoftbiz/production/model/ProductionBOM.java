package com.isoftbiz.production.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "ProductionBOM")
public class ProductionBOM {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProductionBOMID")
	private Long productionBOMID;
	
	@ManyToOne
	@JoinColumn(name = "ProductionID", nullable = false)
	private Production production;
	
	@ManyToOne
	@JoinColumn(name = "BOMDetailID", nullable = false)
	private BillOfMaterialDetail billOfMaterialDetail;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "Quantity", columnDefinition = "Decimal(14,4)")
	private Double quantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;
}
