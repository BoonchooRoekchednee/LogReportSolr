package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;

@Entity
@Table(name = "ReceiveMaterial", uniqueConstraints = @UniqueConstraint(columnNames = {"ReceiveCode", "CompanyID"}))
public class ReceiveMaterial {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReceiveID")
	private Long receiveID;
	
	@Column(name = "ReceiveCode", length = 32, nullable = false)
	private String receiveCode;
	
	@Column(name = "ReceiveNo", length = 32, nullable = true)
	private String receiveNo;
	
	@Column(name = "ReceiveDate")
	@Type(type = "date")
	private Date receiveDate;
	
	@Column(name = "RefDoc", length = 32)
	private String refDoc;
	
	@Column(name = "RefDocDate")
	@Type(type = "date")
	private Date refDocDate;
	
	@Column(name = "Barcode", length = 32, nullable = true)
	private String barcode;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = false)
	private CompanyFreeZone company;
	
	@Column(name = "ReceiveBy", length = 128)
	private String receiveBy;
	
	@Column(name = "ReceiveStatus", length = 32)
	private String receiveStatus;
	
	@Column(name = "ReceiveStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date receiveStatusDate;
	
	@Column(name = "RecordStatus", length = 32)
	private String recordStatus;
	
	@Column(name = "RecordStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date recordStatusDate;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	
	public Long getReceiveID() {
		return receiveID;
	}

	public void setReceiveID(Long receiveID) {
		this.receiveID = receiveID;
	}

	public String getReceiveCode() {
		return receiveCode;
	}

	public void setReceiveCode(String receiveCode) {
		this.receiveCode = receiveCode;
	}

	public String getReceiveNo() {
		return receiveNo;
	}

	public void setReceiveNo(String receiveNo) {
		this.receiveNo = receiveNo;
	}

	public Date getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(Date receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getRefDoc() {
		return refDoc;
	}

	public void setRefDoc(String refDoc) {
		this.refDoc = refDoc;
	}

	public Date getRefDocDate() {
		return refDocDate;
	}

	public void setRefDocDate(Date refDocDate) {
		this.refDocDate = refDocDate;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getReceiveBy() {
		return receiveBy;
	}

	public void setReceiveBy(String receiveBy) {
		this.receiveBy = receiveBy;
	}

	public String getReceiveStatus() {
		return receiveStatus;
	}

	public void setReceiveStatus(String receiveStatus) {
		this.receiveStatus = receiveStatus;
	}

	public Date getReceiveStatusDate() {
		return receiveStatusDate;
	}

	public void setReceiveStatusDate(Date receiveStatusDate) {
		this.receiveStatusDate = receiveStatusDate;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Date getRecordStatusDate() {
		return recordStatusDate;
	}

	public void setRecordStatusDate(Date recordStatusDate) {
		this.recordStatusDate = recordStatusDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
