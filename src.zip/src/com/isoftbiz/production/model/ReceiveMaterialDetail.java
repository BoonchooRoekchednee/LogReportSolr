package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.freezone.model.Location;
import com.isoftbiz.production.model.ReceiveMaterial;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "ReceiveMaterialDetail", uniqueConstraints = @UniqueConstraint(columnNames = {"ReceiveID", "ItemID", "LocationID"}))
public class ReceiveMaterialDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReceiveDetailID")
	private Long receiveDetailID;
	
	@ManyToOne
	@JoinColumn(name = "ReceiveID", nullable = false)
	private ReceiveMaterial receiveMaterial;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "LotNo", length = 32)
	private String lotNo;
	
	@Column(name = "MfgDate")
	@Type(type = "date")
	private Date mfgDate;
	
	@Column(name = "ExpDate")
	@Type(type = "date")
	private Date expDate;
	
	@Column(name = "ReceiveQuantity", columnDefinition = "Decimal(14,4)")
	private Double receiveQuantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;
	
	@Column(name = "UnitPrice", columnDefinition = "Decimal(14,4)")
	private Double unitPrice;
	
	@Column(name = "ReceiveStatus", length = 32)
	private String receiveStatus;
	
	@ManyToOne
	@JoinColumn(name = "LocationID", nullable = true)
	private Location location;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	public Long getReceiveDetailID() {
		return receiveDetailID;
	}

	public void setReceiveDetailID(Long receiveDetailID) {
		this.receiveDetailID = receiveDetailID;
	}

	public ReceiveMaterial getReceiveMaterial() {
		return receiveMaterial;
	}

	public void setReceiveMaterial(ReceiveMaterial receiveMaterial) {
		this.receiveMaterial = receiveMaterial;
	}

	public ItemMaster getItemMaster() {
		return itemMaster;
	}

	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}

	public String getLotNo() {
		return lotNo;
	}

	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}

	public Date getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public Double getReceiveQuantity() {
		return receiveQuantity;
	}

	public void setReceiveQuantity(Double receiveQuantity) {
		this.receiveQuantity = receiveQuantity;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getReceiveStatus() {
		return receiveStatus;
	}

	public void setReceiveStatus(String receiveStatus) {
		this.receiveStatus = receiveStatus;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
