package com.isoftbiz.production.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.isoftbiz.config.model.CompanyFreeZone;

@Entity
@Table(name = "Routing", uniqueConstraints = @UniqueConstraint(columnNames = {"RoutingCode", "CompanyID"}))
public class Routing {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RoutingID")
	private Long routingID;
	
	@Column(name = "RoutingCode", length = 32, nullable = false)
	private String routingCode;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "remark", length = 255)
	private String remark;

	public Long getBomID() {
		return routingID;
	}

	public void setBomID(Long routingID) {
		this.routingID = routingID;
	}

	public String getBomCode() {
		return routingCode;
	}

	public void setBomCode(String routingCode) {
		this.routingCode = routingCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
