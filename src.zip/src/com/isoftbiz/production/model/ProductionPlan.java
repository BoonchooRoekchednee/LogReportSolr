package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "ProductionPlan", uniqueConstraints = @UniqueConstraint(columnNames = {"ProductionCode", "CompanyID"}))
public class ProductionPlan {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProductionID")
	private Long productionID;
	
	@Column(name = "ProductionCode", length = 32, nullable = false)
	private String productionCode;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@Column(name = "ProductionQuantity", columnDefinition = "Decimal(14,4)")
	private Double productionQuantity;
	
	@Column(name = "FinishedQuantity", columnDefinition = "Decimal(14,4)")
	private Double finishedQuantity;
	
	@Column(name = "DamagedQuantity", columnDefinition = "Decimal(14,4)")
	private Double damagedQuantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;
	
	@ManyToOne
	@JoinColumn(name = "BOMID", nullable = false)
	private BillOfMaterial billOfMaterial;
	
	@Column(name = "RefDoc", length = 32)
	private String refDoc;
	
	@Column(name = "RefDocDate")
	@Type(type = "date")
	private Date refDocDate;
	
	@Column(name = "Barcode", length = 32, nullable = true)
	private String barcode;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "ProductionStatus", length = 32)
	private String productionStatus;
	
	@Column(name = "productionStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date productionStatusDate;
	
	@Column(name = "RecordStatus", length = 32)
	private String recordStatus;
	
	@Column(name = "RecordStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date recordStatusDate;
	
	@Column(name = "remark", length = 255)
	private String remark;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
}
