package com.isoftbiz.production.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.isoftbiz.config.model.CompanyFreeZone;

@Entity
@Table(name = "BillOfMaterial", uniqueConstraints = @UniqueConstraint(columnNames = {"BOMCode", "CompanyID"}))
public class BillOfMaterial {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BOMID")
	private Long bomID;
	
	@Column(name = "BOMCode", length = 32, nullable = false)
	private String bomCode;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = true)
	private CompanyFreeZone company;
	
	@Column(name = "remark", length = 255)
	private String remark;

	public Long getBomID() {
		return bomID;
	}

	public void setBomID(Long bomID) {
		this.bomID = bomID;
	}

	public String getBomCode() {
		return bomCode;
	}

	public void setBomCode(String bomCode) {
		this.bomCode = bomCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
