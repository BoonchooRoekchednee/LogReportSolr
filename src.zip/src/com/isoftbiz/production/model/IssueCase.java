package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;

@Entity
@Table(name = "IssueCase", uniqueConstraints = @UniqueConstraint(columnNames = {"IssueCaseCode", "CompanyID"}))
public class IssueCase {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IssueCaseID")
	private Long issueCaseID;
	
	@Column(name = "IssueCaseCode", length = 32, nullable = false)
	private String issueCaseCode;
	
	@Column(name = "IssueCaseName", length = 128, nullable = false)
	private String issueCaseName;
	
	@Column(name = "Description", length = 255)
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = false)
	private CompanyFreeZone company;

	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getIssueCaseID() {
		return issueCaseID;
	}

	public void setIssueCaseID(Long issueCaseID) {
		this.issueCaseID = issueCaseID;
	}

	public String getIssueCaseCode() {
		return issueCaseCode;
	}

	public void setIssueCaseCode(String issueCaseCode) {
		this.issueCaseCode = issueCaseCode;
	}

	public String getIssueCaseName() {
		return issueCaseName;
	}

	public void setIssueCaseName(String issueCaseName) {
		this.issueCaseName = issueCaseName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
