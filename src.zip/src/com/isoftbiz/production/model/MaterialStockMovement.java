package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.isoftbiz.config.model.CompanyFreeZone;
import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.freezone.model.Location;

@Entity
@Table(name = "MaterialStockMovement")
public class MaterialStockMovement {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "StockID")
	private Long stockID;
	
	@Column(name = "StockDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date stockDate;
	
	@Column(name = "StockType", length = 16, nullable = false)
	private String stockType;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "LotNo", length = 32)
	private String lotNo;
	
	@Column(name = "MfgDate")
	@Type(type = "date")
	private Date mfgDate;
	
	@Column(name = "ExpDate")
	@Type(type = "date")
	private Date expDate;
	
	@Column(name = "ReceiveQuantity", columnDefinition = "Decimal(14,4)")
	private Double receiveQuantity;
	
	@Column(name = "IssueQuantity", columnDefinition = "Decimal(14,4)")
	private Double issueQuantity;
	
	@Column(name = "BalanceQuantity", columnDefinition = "Decimal(14,4)")
	private Double balanceQuantity;
	
	@Column(name = "UnitPrice", columnDefinition = "Decimal(14,4)")
	private Double unitPrice;
	
	@ManyToOne
	@JoinColumn(name = "CompanyID", nullable = false)
	private CompanyFreeZone company;
	
	@ManyToOne
	@JoinColumn(name = "LocationID", nullable = true)
	private Location location;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	public Long getStockID() {
		return stockID;
	}

	public void setStockID(Long stockID) {
		this.stockID = stockID;
	}

	public Date getStockDate() {
		return stockDate;
	}

	public void setStockDate(Date stockDate) {
		this.stockDate = stockDate;
	}

	public String getStockType() {
		return stockType;
	}

	public void setStockType(String stockType) {
		this.stockType = stockType;
	}

	public ItemMaster getItemMaster() {
		return itemMaster;
	}

	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}

	public String getLotNo() {
		return lotNo;
	}

	public void setLotNo(String lotNo) {
		this.lotNo = lotNo;
	}

	public Date getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public Double getReceiveQuantity() {
		return receiveQuantity;
	}

	public void setReceiveQuantity(Double receiveQuantity) {
		this.receiveQuantity = receiveQuantity;
	}

	public Double getIssueQuantity() {
		return issueQuantity;
	}

	public void setIssueQuantity(Double issueQuantity) {
		this.issueQuantity = issueQuantity;
	}

	public Double getBalanceQuantity() {
		return balanceQuantity;
	}

	public void setBalanceQuantity(Double balanceQuantity) {
		this.balanceQuantity = balanceQuantity;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public CompanyFreeZone getCompany() {
		return company;
	}

	public void setCompany(CompanyFreeZone company) {
		this.company = company;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
