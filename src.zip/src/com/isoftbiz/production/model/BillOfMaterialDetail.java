package com.isoftbiz.production.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.isoftbiz.freezone.model.ItemMaster;
import com.isoftbiz.setupdata.model.Unit;

@Entity
@Table(name = "BillOfMaterialDetail")
public class BillOfMaterialDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BOMDetailID")
	private Long bomDetailID;
	
	@ManyToOne
	@JoinColumn(name = "BOMID", nullable = false)
	private BillOfMaterial billOfMaterial;
	
	@ManyToOne
	@JoinColumn(name = "ItemID", nullable = false)
	private  ItemMaster itemMaster;
	
	@Column(name = "Quantity", columnDefinition = "Decimal(14,4)")
	private Double quantity;
	
	@ManyToOne
	@JoinColumn(name = "UnitID", nullable = false)
	private Unit unit;

	public Long getBomDetailID() {
		return bomDetailID;
	}

	public void setBomDetailID(Long bomDetailID) {
		this.bomDetailID = bomDetailID;
	}

	public BillOfMaterial getBillOfMaterial() {
		return billOfMaterial;
	}

	public void setBillOfMaterial(BillOfMaterial billOfMaterial) {
		this.billOfMaterial = billOfMaterial;
	}

	public ItemMaster getItemMaster() {
		return itemMaster;
	}

	public void setItemMaster(ItemMaster itemMaster) {
		this.itemMaster = itemMaster;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}
}
