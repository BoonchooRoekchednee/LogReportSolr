package com.isoftbiz.production.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "ProductionDetailStatus")
public class ProductionDetailStatus {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProductionDetailStatusID")
	private Long productionDetailStatusID;
	
	@ManyToOne
	@JoinColumn(name = "ProductionDetailID", nullable = false)
	private ProductionDetail productionDetail;
	
	@ManyToOne
	@JoinColumn(name = "StationID", nullable = true)
	private ProductionStation productionStation;
	
	@Column(name = "StartDate")
	@Type(type = "date")
	private Date startDate;
	
	@Column(name = "EndDate")
	@Type(type = "date")
	private Date endDate;
	
	@Column(name = "ProductionStatus", length = 32)
	private String productionStatus;
	
	@Column(name = "productionStatusDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date productionStatusDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getProductionDetailStatusID() {
		return productionDetailStatusID;
	}

	public void setProductionDetailStatusID(Long productionDetailStatusID) {
		this.productionDetailStatusID = productionDetailStatusID;
	}

	public ProductionDetail getProductionDetail() {
		return productionDetail;
	}

	public void setProductionDetail(ProductionDetail productionDetail) {
		this.productionDetail = productionDetail;
	}

	public ProductionStation getProductionStation() {
		return productionStation;
	}

	public void setProductionStation(ProductionStation productionStation) {
		this.productionStation = productionStation;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getProductionStatus() {
		return productionStatus;
	}

	public void setProductionStatus(String productionStatus) {
		this.productionStatus = productionStatus;
	}

	public Date getProductionStatusDate() {
		return productionStatusDate;
	}

	public void setProductionStatusDate(Date productionStatusDate) {
		this.productionStatusDate = productionStatusDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
