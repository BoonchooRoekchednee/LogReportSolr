package com.isoftbiz.config.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.config.idao.IFreeZoneInfoDAO;
import com.isoftbiz.config.iservice.IFreeZoneInfoService;
import com.isoftbiz.config.model.FreeZoneInfo;

@Service
@Transactional
public class FreeZoneInfoService implements IFreeZoneInfoService {
	@Autowired
	private IFreeZoneInfoDAO freeZoneInfoDAO;

	@Override
	public FreeZoneInfo findById(Long fzID) throws Exception {
		return freeZoneInfoDAO.findById(fzID);
	}

	@Override
	public boolean update(FreeZoneInfo freeZoneInfo) throws Exception {
		return freeZoneInfoDAO.update(freeZoneInfo);
	}
}
