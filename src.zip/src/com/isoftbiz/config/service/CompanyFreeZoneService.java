package com.isoftbiz.config.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftbiz.config.idao.ICompanyFreeZoneDAO;
import com.isoftbiz.config.iservice.ICompanyFreeZoneService;
import com.isoftbiz.config.model.CompanyFreeZone;

@Service
@Transactional
public class CompanyFreeZoneService implements ICompanyFreeZoneService {
	@Autowired
	private ICompanyFreeZoneDAO companyDAO;

	@Override
	public CompanyFreeZone findById(Long companyID) throws Exception {
		return companyDAO.findById(companyID);
	}
	
	@Override
	public List<CompanyFreeZone> findAll() throws Exception {
		return companyDAO.findAll();
	}

	@Override
	public boolean save(CompanyFreeZone company) throws Exception {
		return companyDAO.save(company);
	}

	@Override
	public boolean update(CompanyFreeZone company) throws Exception {
		return companyDAO.update(company);
	}

	@Override
	public boolean delete(CompanyFreeZone company) throws Exception {
		return companyDAO.delete(company);
	}
	
	@Override
	public List<CompanyFreeZone> searchCompanyFreeZone(String sCompanyCode, String sCompanyName,String sActiveFlag) throws Exception {
		return companyDAO.searchCompanyFreeZone(sCompanyCode, sCompanyName, sActiveFlag);
	}
}
