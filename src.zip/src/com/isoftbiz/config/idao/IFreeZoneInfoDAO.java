package com.isoftbiz.config.idao;

import com.isoftbiz.config.model.FreeZoneInfo;

public interface IFreeZoneInfoDAO {
	public FreeZoneInfo findById(Long fzID) throws Exception;

	public boolean update(FreeZoneInfo freeZoneInfo) throws Exception;
}
