package com.isoftbiz.config.idao;

import java.util.List;

import com.isoftbiz.config.model.CompanyFreeZone;

public interface ICompanyFreeZoneDAO {
	public CompanyFreeZone findById(Long companyID) throws Exception;

	public List<CompanyFreeZone> findAll() throws Exception;

	public boolean save(CompanyFreeZone company) throws Exception;

	public boolean update(CompanyFreeZone company) throws Exception;

	public boolean delete(CompanyFreeZone company) throws Exception;
	
	public List<CompanyFreeZone> searchCompanyFreeZone(String sCompanyCode, String sCompanyName,String sActiveFlag) throws Exception;
}
