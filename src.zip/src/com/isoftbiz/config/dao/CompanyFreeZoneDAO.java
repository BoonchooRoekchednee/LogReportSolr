package com.isoftbiz.config.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.config.idao.ICompanyFreeZoneDAO;
import com.isoftbiz.config.model.CompanyFreeZone;

@Repository
public class CompanyFreeZoneDAO extends HibernateDaoSupport implements ICompanyFreeZoneDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public CompanyFreeZone findById(Long companyID) throws Exception {
		CompanyFreeZone company = this.getHibernateTemplate().get(CompanyFreeZone.class, companyID);
		return company;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CompanyFreeZone> findAll() throws Exception {
		List<CompanyFreeZone> companyList = session.createCriteria(CompanyFreeZone.class).addOrder(Order.asc("companyName")).list();
		session.flush();
		session.clear();
		return companyList;
	}

	@Override
	public boolean save(CompanyFreeZone company) throws Exception {
		this.getHibernateTemplate().save(company);
		return true;
	}

	@Override
	public boolean update(CompanyFreeZone company) throws Exception {
		this.getHibernateTemplate().update(company);
		return true;
	}

	@Override
	public boolean delete(CompanyFreeZone company) throws Exception {
		this.getHibernateTemplate().delete(company);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CompanyFreeZone> searchCompanyFreeZone(String sCompanyCode, String sCompanyName,String sActiveFlag) throws Exception {
		StringBuilder sQuery = new StringBuilder();
		sQuery.append("from CompanyFreeZone where CompanyID is not null ");
		if (sCompanyCode != null && !sCompanyCode.isEmpty()) {
			sQuery.append(" and CompanyCode like '%" + sCompanyCode + "%' ");
		}
		if (sCompanyName != null && !sCompanyName.isEmpty()) {
			sQuery.append(" and CompanyName like '%" + sCompanyName + "%' ");
		}
		if (sActiveFlag != null && !sActiveFlag.isEmpty() && !sActiveFlag.equalsIgnoreCase("A")) {
			sQuery.append(" and ActiveFlag = '" + sActiveFlag + "' ");
		}
		List<CompanyFreeZone> companyList = this.getHibernateTemplate().find(sQuery.toString());
		return companyList;
	}
}
