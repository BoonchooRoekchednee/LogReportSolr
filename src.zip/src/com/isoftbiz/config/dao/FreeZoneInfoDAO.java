package com.isoftbiz.config.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.isoftbiz.config.idao.IFreeZoneInfoDAO;
import com.isoftbiz.config.model.FreeZoneInfo;

@Repository
public class FreeZoneInfoDAO extends HibernateDaoSupport implements IFreeZoneInfoDAO {
	protected Session session;
	@Autowired
	public void setDummySessionFactory(SessionFactory sessionFactory) {
		setSessionFactory(sessionFactory);
		session = this.getHibernateTemplate().getSessionFactory().openSession();
	}
	
	@Override
	public FreeZoneInfo findById(Long fzID) throws Exception {
		FreeZoneInfo freeZoneInfo = this.getHibernateTemplate().get(FreeZoneInfo.class, fzID);
		return freeZoneInfo;
	}

	@Override
	public boolean update(FreeZoneInfo freeZoneInfo) throws Exception {
		this.getHibernateTemplate().update(freeZoneInfo);
		return true;
	}
}
