package com.isoftbiz.config.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.config.iservice.IFreeZoneInfoService;
import com.isoftbiz.config.model.FreeZoneInfo;

@Controller
public class FreeZoneInfoController {
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IFreeZoneInfoService freeZoneInfoService;
	
	@RequestMapping(value = "/FreeZoneInfo.isoftbiz")
	public ModelAndView freeZoneInfo() {
		try {
			ModelAndView mav = new ModelAndView();
			FreeZoneInfo freeZoneInfo = freeZoneInfoService.findById((long) 1);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("freeZoneInfo", freeZoneInfo);
			mav.setViewName("FreeZoneInfo");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/FreeZoneInfoUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(FreeZoneInfo freeZoneInfo) {
		try {
			freeZoneInfoService.update(freeZoneInfo);
			return "redirect:/FreeZoneInfo.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		Locale lc = new java.util.Locale("en","EN");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", lc);
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
}
