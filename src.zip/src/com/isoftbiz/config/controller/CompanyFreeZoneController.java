package com.isoftbiz.config.controller;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.isoftbiz.admin.iservice.IUserService;
import com.isoftbiz.admin.model.User;
import com.isoftbiz.config.iservice.ICompanyFreeZoneService;
import com.isoftbiz.config.model.CompanyFreeZone;

@Controller
public class CompanyFreeZoneController {
	@Autowired
	private ICompanyFreeZoneService companyService;
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/CompanyFreeZone.isoftbiz")
	public ModelAndView index() {
		try {
			Set<CompanyFreeZone> companyList = new HashSet<CompanyFreeZone>(companyService.findAll());
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("companyList", companyList);
			mav.setViewName("CompanyFreeZone");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CompanyFreeZoneNew.isoftbiz")
	public ModelAndView create() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("CompanyFreeZoneNew");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CompanyFreeZoneEdit.isoftbiz", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam(value = "id") Long id) {
		try {
			ModelAndView mav = new ModelAndView();
			CompanyFreeZone company = companyService.findById(id);
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("company", company);
			mav.setViewName("CompanyFreeZoneEdit");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/CompanyFreeZoneSave.isoftbiz", method = RequestMethod.POST)
	public String save(CompanyFreeZone company) {
		try {
			companyService.save(company);
			return "redirect:/CompanyFreeZone.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@RequestMapping(value = "/CompanyFreeZoneUpdate.isoftbiz", method = RequestMethod.POST)
	public String update(CompanyFreeZone company) {
		try {
			companyService.update(company);
			return "redirect:/CompanyFreeZone.isoftbiz";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@ResponseBody
	@RequestMapping(value = "/CompanyFreeZoneDelete.isoftbiz", method = RequestMethod.POST)
	public String delete(@RequestParam(value = "id") Long id) {
		try {
			CompanyFreeZone company = companyService.findById(id);
			companyService.delete(company);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
	
	@RequestMapping(value = "/CompanyFreeZoneSearch.isoftbiz")
	public ModelAndView searchForm() {
		try {
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.setViewName("CompanyFreeZoneSearch");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/SearchCompanyFreeZone.isoftbiz", method = RequestMethod.POST)
	public ModelAndView searchCompanyFreeZone(HttpServletRequest request) {
		try {
			String sCompanyCode = request.getParameter("companyCode");
			String sCompanyName = request.getParameter("companyName");
			String sActiveFlag = request.getParameter("activeFlag");
			
			Set<CompanyFreeZone> companyList = new HashSet<CompanyFreeZone>(companyService.searchCompanyFreeZone(sCompanyCode, sCompanyName, sActiveFlag));
			ModelAndView mav = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = auth.getName();
			User userLogin = userService.findByUserCode(userName);
			mav.addObject("userLogin", userLogin);
			mav.addObject("companyList", companyList);
			mav.setViewName("CompanyFreeZone");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
