package com.isoftbiz.config.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.isoftbiz.setupdata.model.Country;
import com.isoftbiz.setupdata.model.District;
import com.isoftbiz.setupdata.model.Province;

@Entity
@Table(name = "CompanyFreeZone")
public class CompanyFreeZone {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CompanyID")
	private Long companyID;
	
	@Column(name = "CompanyCode", length = 32, unique = true, nullable = false)
	private String companyCode;
	
	@Column(name = "CompanyName", length = 128, unique = true, nullable = false)
	private String companyName;
	
	@Column(name = "CompanyNameEN", length = 128)
	private String companyNameEN;
	
	@Column(name = "OwnerFreeZone", length = 1, nullable = false)
	private String ownerFreeZone;
	
	@Column(name = "Address", length = 255)
	private String address;
	
	@Column(name = "AddressNo", length = 64)
	private String addressNo;
	
	@Column(name = "AddressRoad", length = 64)
	private String addressRoad;
	
	@Column(name = "AddressSubRoad", length = 64)
	private String addressSubRoad;
	
	@Column(name = "AddressSubDistrict", length = 64)
	private String addressSubDistrict;
	
	@ManyToOne
	@JoinColumn(name = "CountryID", nullable = true)
	private Country country;
	
	@ManyToOne
	@JoinColumn(name = "ProvinceID", nullable = true)
	private Province province;
	
	@ManyToOne
	@JoinColumn(name = "DistrictID", nullable = true)
	private District district;
	
	@Column(name = "Zip", length = 10)
	private String zip;
	
	@Column(name = "TaxNo", length = 32)
	private String taxNo;
	
	@Column(name = "Email", length = 128)
	private String email;
	
	@Column(name = "PhoneNumber", length = 64)
	private String phoneNumber;
	
	@Column(name = "MobileNumber", length = 32)
	private String mobileNumber;
	
	@Column(name = "FaxNumber", length = 32)
	private String faxNumber;
	
	@Column(name = "Remark", length = 255)
	private String remark;

	@Column(name = "ActiveFlag", length = 1)
	private String activeFlag;
	
	@ManyToOne
	@JoinColumn(name = "FZID", nullable = true)
	private FreeZoneInfo freeZoneInfo;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getCompanyID() {
		return companyID;
	}

	public void setCompanyID(Long companyID) {
		this.companyID = companyID;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyNameEN() {
		return companyNameEN;
	}

	public void setCompanyNameEN(String companyNameEN) {
		this.companyNameEN = companyNameEN;
	}

	public String getOwnerFreeZone() {
		return ownerFreeZone;
	}

	public void setOwnerFreeZone(String ownerFreeZone) {
		this.ownerFreeZone = ownerFreeZone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressNo() {
		return addressNo;
	}

	public void setAddressNo(String addressNo) {
		this.addressNo = addressNo;
	}

	public String getAddressRoad() {
		return addressRoad;
	}

	public void setAddressRoad(String addressRoad) {
		this.addressRoad = addressRoad;
	}

	public String getAddressSubRoad() {
		return addressSubRoad;
	}

	public void setAddressSubRoad(String addressSubRoad) {
		this.addressSubRoad = addressSubRoad;
	}

	public String getAddressSubDistrict() {
		return addressSubDistrict;
	}

	public void setAddressSubDistrict(String addressSubDistrict) {
		this.addressSubDistrict = addressSubDistrict;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Province getProvince() {
		return province;
	}

	public void setProvince(Province province) {
		this.province = province;
	}

	public District getDistrict() {
		return district;
	}

	public void setDistrict(District district) {
		this.district = district;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public FreeZoneInfo getFreeZoneInfo() {
		return freeZoneInfo;
	}

	public void setFreeZoneInfo(FreeZoneInfo freeZoneInfo) {
		this.freeZoneInfo = freeZoneInfo;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
