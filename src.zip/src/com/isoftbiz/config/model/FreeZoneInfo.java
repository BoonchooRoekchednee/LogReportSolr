package com.isoftbiz.config.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.isoftbiz.setupdata.model.Country;
import com.isoftbiz.setupdata.model.District;
import com.isoftbiz.setupdata.model.Province;

@Entity
@Table(name = "FreeZoneInfo")
public class FreeZoneInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FZID")
	private Long fzID;

	@Column(name = "FZCode", length = 64, unique = true, nullable = false)
	private String fzCode;

	@Column(name = "FZName", length = 128, nullable = false)
	private String fzName;

	@Column(name = "FZNameTH", length = 128)
	private String fzNameTH;
	
	@Column(name = "FZNameEN", length = 128)
	private String fzNameEN;
	
	@Column(name = "RegisterNo", length = 64)
	private String registerNo;
	
	@Column(name = "RegisterDate")
	@Type(type = "date")
	private Date registerDate;
	
	@Column(name = "RefNo", length = 64)
	private String refNo;
	
	@Column(name = "RefDate")
	@Type(type = "date")
	private Date refDate;
	
	@Column(name = "Address", length = 255)
	private String address;
	
	@Column(name = "AddressNo", length = 64)
	private String addressNo;
	
	@Column(name = "AddressRoad", length = 64)
	private String addressRoad;
	
	@Column(name = "AddressSubRoad", length = 64)
	private String addressSubRoad;
	
	@Column(name = "AddressSubDistrict", length = 64)
	private String addressSubDistrict;
	
	@ManyToOne
	@JoinColumn(name = "CountryID", nullable = true)
	private Country country;
	
	@ManyToOne
	@JoinColumn(name = "ProvinceID", nullable = true)
	private Province province;
	
	@ManyToOne
	@JoinColumn(name = "DistrictID", nullable = true)
	private District district;
	
	@Column(name = "Zip", length = 10)
	private String zip;
	
	@Column(name = "TaxNo", length = 32)
	private String taxNo;
	
	@Column(name = "Email", length = 128)
	private String email;
	
	@Column(name = "PhoneNumber", length = 64)
	private String phoneNumber;
	
	@Column(name = "MobileNumber", length = 32)
	private String mobileNumber;
	
	@Column(name = "FaxNumber", length = 32)
	private String faxNumber;
	
	@Column(name = "Remark", length = 255)
	private String remark;
	
	@Column(name = "CreatedBy", length = 64)
	private String createdBy;
	
	@Column(name = "CreatedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@Column(name = "ModifiedBy", length = 64)
	private String modifiedBy;
	
	@Column(name = "ModifiedDate")
	@Type(type = "timestamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	public Long getFzID() {
		return fzID;
	}

	public void setFzID(Long fzID) {
		this.fzID = fzID;
	}

	public String getFzCode() {
		return fzCode;
	}

	public void setFzCode(String fzCode) {
		this.fzCode = fzCode;
	}

	public String getFzName() {
		return fzName;
	}

	public void setFzName(String fzName) {
		this.fzName = fzName;
	}

	public String getFzNameTH() {
		return fzNameTH;
	}

	public void setFzNameTH(String fzNameTH) {
		this.fzNameTH = fzNameTH;
	}

	public String getFzNameEN() {
		return fzNameEN;
	}

	public void setFzNameEN(String fzNameEN) {
		this.fzNameEN = fzNameEN;
	}

	public String getRegisterNo() {
		return registerNo;
	}

	public void setRegisterNo(String registerNo) {
		this.registerNo = registerNo;
	}

	public Date getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Date getRefDate() {
		return refDate;
	}

	public void setRefDate(Date refDate) {
		this.refDate = refDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressNo() {
		return addressNo;
	}

	public void setAddressNo(String addressNo) {
		this.addressNo = addressNo;
	}

	public String getAddressRoad() {
		return addressRoad;
	}

	public void setAddressRoad(String addressRoad) {
		this.addressRoad = addressRoad;
	}

	public String getAddressSubRoad() {
		return addressSubRoad;
	}

	public void setAddressSubRoad(String addressSubRoad) {
		this.addressSubRoad = addressSubRoad;
	}

	public String getAddressSubDistrict() {
		return addressSubDistrict;
	}

	public void setAddressSubDistrict(String addressSubDistrict) {
		this.addressSubDistrict = addressSubDistrict;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Province getProvince() {
		return province;
	}

	public void setProvince(Province province) {
		this.province = province;
	}

	public District getDistrict() {
		return district;
	}

	public void setDistrict(District district) {
		this.district = district;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
